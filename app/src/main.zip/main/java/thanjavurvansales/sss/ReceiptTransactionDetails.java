package thanjavurvansales.sss;

class ReceiptTransactionDetails {
    String[] TransactionNo;
    public String[] getTransactionNo(){ return TransactionNo;}
    public ReceiptTransactionDetails(String[] TransactionNo) {
        super();
        this.TransactionNo = TransactionNo;
    }
}
