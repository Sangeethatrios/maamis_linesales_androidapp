package thanjavurvansales.sss;

class CustomerDatas {
    String[] CustomerCode;
    public String[] getCustomerCode(){ return CustomerCode;}
    public CustomerDatas(String[] CustomerCode) {
        super();
        this.CustomerCode = CustomerCode;
    }
}
