package thanjavurvansales.sss;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MenuActivity extends AppCompatActivity {
    LinearLayout salesLL,ReportstLL,receiptLL,ExpensetLL,
            CustomertLL,VanStocktLL,SalesChildLL,ReportsChildLL,ScheduleLL,
            SalesOrderLL,Cash_Report_LL,Sales_Return_ReporsLL,Cash_Close_LL,ReportLayout;
    public Context context;
    boolean clicksales=true,clickreports=true;
    ImageButton menulogout,menusyncall;
    TextView SalesHead,ReportsHead,Sales,salesitemwise,
            cashreport,expensereport,salesbillwise,SalesReturn,
            PriceListHead,OrderForm,salesreturnitemwise,cashsummaryreport,salesreturnbillwise,salesorderbillwise,salesorderitemwise;
    boolean networkstate;
    static public String getschedulecode="",getroutecode="",getroutename="",gettripadvance="",
        getroutenametamil="",getcapacity="",getcashclosecount="0",getsalesclosecount="0",getwishmsg="";
    static double  getdenominationcount = 0;
    public static final String UPLOAD_URL = RestAPI.urlString+"syncimage.php";
    String lunch_start_time = "",lunch_end_time="";
    View cashcloseview;
    LinearLayout Sales_Layout,ReportsOrderChildLL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        context = this;

        //LinearLayout declaration
        salesLL = (LinearLayout) findViewById(R.id.salesLL);
        SalesChildLL = (LinearLayout)findViewById(R.id.SalesChildLL);
        SalesHead = (TextView)findViewById(R.id.SalesHead);
        ReportsChildLL = (LinearLayout)findViewById(R.id.ReportsChildLL);
        ScheduleLL = (LinearLayout)findViewById(R.id.ScheduleLL);
        ReportstLL = (LinearLayout)findViewById(R.id.ReportstLL);
        receiptLL=(LinearLayout)findViewById(R.id.ReceiptLL);
        ReportsHead = (TextView)findViewById(R.id.ReportsHead);
        Sales = (TextView)findViewById(R.id.Sales);
        ExpensetLL = (LinearLayout) findViewById(R.id.ExpensetLL);
        salesitemwise=(TextView)findViewById(R.id.salesitemwise);
        VanStocktLL = (LinearLayout) findViewById(R.id.VanStocktLL);
        cashreport = (TextView)findViewById(R.id.cashreport);
        expensereport = (TextView)findViewById(R.id.expensereport);
        salesbillwise = (TextView)findViewById(R.id.salesbillwise);
        CustomertLL = (LinearLayout)findViewById(R.id.CustomertLL);
        SalesReturn = (TextView)findViewById(R.id.SalesReturn);
        menulogout = (ImageButton)findViewById(R.id.menulogout);
        menusyncall = (ImageButton)findViewById(R.id.menusyncall);
        PriceListHead=(TextView)findViewById(R.id.PriceListHead);
        OrderForm = (TextView)findViewById(R.id.OrderForm);
        salesreturnitemwise = (TextView)findViewById(R.id.salesreturnitemwise);
        cashsummaryreport = (TextView)findViewById(R.id.cashsummaryreport);
        salesreturnbillwise = (TextView)findViewById(R.id.salesreturnbillwise);
        cashcloseview = (View)findViewById(R.id.cashcloseview);
        SalesOrderLL = (LinearLayout)findViewById(R.id.SalesOrderLL);
        Cash_Report_LL = (LinearLayout)findViewById(R.id.Cash_Report_LL);
        Sales_Return_ReporsLL = (LinearLayout)findViewById(R.id.Sales_Return_ReporsLL);
        Cash_Close_LL = (LinearLayout)findViewById(R.id.Cash_Close_LL);
        ReportLayout = (LinearLayout)findViewById(R.id.ReportLayout);
        Sales_Layout = (LinearLayout)findViewById(R.id.Sales_Layout);
        salesorderbillwise = (TextView)findViewById(R.id.salesorderbillwise);
        salesorderitemwise = (TextView)findViewById(R.id.salesorderitemwise);
        ReportsOrderChildLL =(LinearLayout)findViewById(R.id.ReportsOrderChildLL);


        LoginActivity.iscash =false;
        getschedulecode="";getwishmsg="";

        OrderForm.setVisibility(View.GONE);
        cashcloseview.setVisibility(View.GONE);
        menusyncall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                networkstate = isNetworkAvailable();
                if (networkstate == true) {
                    new AsyncServer().execute();
                }else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Please check internet connection", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                    //Toast.makeText(getApplicationContext(),"Please check internet connection",Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Get Current date
        DataBaseAdapter objdatabaseadapter1 = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter1 = new DataBaseAdapter(context);
            objdatabaseadapter1.open();
            LoginActivity.getformatdate = objdatabaseadapter1.GenCreatedDate();
            LoginActivity.getcurrentdatetime = objdatabaseadapter1.GenCurrentCreatedDate();
            Cur = objdatabaseadapter1.GetScheduleListDB(LoginActivity.getformatdate );
            if(Cur.getCount()>0) {
                for (int i = 0; i < Cur.getCount(); i++) {
                     lunch_start_time = Cur.getString(11);
                     lunch_end_time = Cur.getString(12);
                }
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (objdatabaseadapter1 != null)
                objdatabaseadapter1.close();
            if(Cur != null)
                Cur.close();
        }



       //Open Sales List
        Sales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesListActivity.class);
                startActivity(i);
            }
        });
        //Open Sales Item Wise Report
        salesitemwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesItemWiseReportActivity.class);
                startActivity(i);
            }
        });
        //sales order form
        SalesOrderLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")
                        && !lunch_start_time.equals("1900-01-01 00:00:00") && (lunch_end_time.equals("") ||
                        lunch_end_time.equals(" ")  || lunch_end_time.equals("null") || lunch_end_time.equals("1900-01-01 00:00:00") ) ){
                    Toast toast = Toast.makeText(getApplicationContext(),  getString(R.string.lunchstarted), Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }else {
                    Intent i = new Intent(context, SalesOrderListActivity.class);
                    startActivity(i);
                }
            }
        });
        //Open Receipt List
        receiptLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")
                        && !lunch_start_time.equals("1900-01-01 00:00:00") && ( lunch_end_time.equals("") ||
                        lunch_end_time.equals(" ")  || lunch_end_time.equals("null") || lunch_end_time.equals("1900-01-01 00:00:00") ) ){
                    Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.lunchstarted), Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }else {
                    Intent i = new Intent(context, ReceiptActivity.class);
                    startActivity(i);
                }
            }
        });
        //Open Van Stock List
        VanStocktLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, VanStockActivity.class);
                startActivity(i);
            }
        });
        //Open Cash Report
        cashreport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, CashReportActivity.class);
                startActivity(i);
            }
        });
        //Open Cash Report
        Cash_Close_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")
                        && !lunch_start_time.equals("1900-01-01 00:00:00") && (lunch_end_time.equals("") ||
                        lunch_end_time.equals(" ")  || lunch_end_time.equals("null") || lunch_end_time.equals("1900-01-01 00:00:00") ) ){
                    Toast toast = Toast.makeText(getApplicationContext(),  getString(R.string.lunchstarted), Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }else {
                    Intent i = new Intent(context, CashReportActivity.class);
                    startActivity(i);
                }
            }
        });
        //Open Sales Return List
        SalesReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesReturnListActivity.class);
                startActivity(i);
            }
        });
        //Open Expense Report
        expensereport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ExpenseReportActivity.class);
                startActivity(i);
            }
        });
        //Open Sales Bill wise Report
        salesbillwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesBillWiseReportActivity.class);
                startActivity(i);
            }
        });
        //Open Customer List
        CustomertLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, CustomerActivity.class);
                startActivity(i);
            }
        });
        //Open Price List
        PriceListHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, PriceListActivity.class);
                startActivity(i);
            }
        });
        //Open sales return bill wise
        salesreturnbillwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesReturnBillwiseReportActivity.class);
                startActivity(i);
            }
        });
        //Open Order form
        OrderForm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get Current date
                DataBaseAdapter objdatabaseadapter1 = null;
                try{
                    objdatabaseadapter1 = new DataBaseAdapter(context);
                    objdatabaseadapter1.open();
                    String  getorderschedulecode = objdatabaseadapter1.GetScheduleCode();
                    String getordercount = objdatabaseadapter1.GetOrderFormCount(getorderschedulecode);
                    if(!getordercount.equals("") && !getordercount.equals("0") && !getordercount.equals("null")){
                        if(Double.parseDouble(getordercount) >0) {
                            Intent i = new Intent(context, OrderFormCartActivity.class);
                            startActivity(i);
                        }else{
                            Intent i = new Intent(context, OrderFormActivity.class);
                            startActivity(i);
                        }
                    }else{
                        Intent i = new Intent(context, OrderFormActivity.class);
                        startActivity(i);
                    }
                }catch (Exception e){
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }finally {
                    // this gets called even if there is an exception somewhere above
                    if (objdatabaseadapter1 != null)
                        objdatabaseadapter1.close();
                }


            }
        });
        //Open Order form
        salesreturnitemwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesReturnItemWiseReportActivity.class);
                startActivity(i);
            }
        });
        //Open Order form
        salesorderbillwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesOrderBillwiseReportActivity.class);
                startActivity(i);
            }
        });
        //Open Order form
        salesorderitemwise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, SalesOrderItemWiseActivity.class);
                startActivity(i);
            }
        });
        //Open myschedule
        ScheduleLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, MyScheduleActivity.class);
                startActivity(i);
            }
        });

        //Open cash summary
        cashsummaryreport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, CashSummaryActivity.class);
                startActivity(i);
            }
        });

        final Animation aniFade = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
        //Open Sales Child Menus
        salesLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")
                    && !lunch_start_time.equals("1900-01-01 00:00:00") && (lunch_end_time.equals("") ||
                        lunch_end_time.equals(" ")  || lunch_end_time.equals("null") || lunch_end_time.equals("1900-01-01 00:00:00") ) ){
                Toast toast = Toast.makeText(getApplicationContext(),  getString(R.string.lunchstarted), Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return;
            }else {
                if (!clickreports) {
                    ReportsChildLL.setVisibility(View.GONE);
                    clickreports = true;
                    ReportsHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_reports, 0, R.drawable.ic_keyboard_arrow_down, 0);
                }
                if (clicksales) {
                    SalesChildLL.setVisibility(View.VISIBLE);
                    clicksales = false;
                    SalesChildLL.startAnimation(aniFade);
                    SalesHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sale, 0, R.drawable.ic_keyboard_arrow_up, 0);
                } else {
                    SalesChildLL.setVisibility(View.GONE);
                    clicksales = true;
                    SalesHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sale, 0, R.drawable.ic_keyboard_arrow_down, 0);
                }
            }

            }
        });

        //Open Reports Child Menus
        ReportstLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!clicksales){
                    SalesChildLL.setVisibility(View.GONE);
                    clicksales=true;
                    SalesHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_sale, 0,  R.drawable.ic_keyboard_arrow_down, 0);
                }
                if(clickreports){
                    ReportsChildLL.setVisibility(View.VISIBLE);
                    clickreports=false;
                    ReportsChildLL.startAnimation(aniFade);
                    ReportsHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_reports, 0, R.drawable.ic_keyboard_arrow_up, 0);
                }else{
                    ReportsChildLL.setVisibility(View.GONE);
                    clickreports=true;
                    ReportsHead.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_reports, 0,  R.drawable.ic_keyboard_arrow_down, 0);
                }
            }
        });

        //Open Expenses List
        ExpensetLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent i = new Intent(context, ExpensesActivity.class);
            startActivity(i);
            }
        });

        //Logout process
        menulogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HomeActivity.logoutprocess = "True";
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });



        /***** SCHEDULE DETAILES************/
        DataBaseAdapter objdatabaseadapter = null;
        Cursor getschedulelist = null;
        try {
            //Get Schdule
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            getschedulelist = objdatabaseadapter.GetScheduleDB();
            if(getschedulelist.getCount() >0){
                for(int i=0;i<getschedulelist.getCount();i++){
                    getschedulecode = getschedulelist.getString(0);
                    getroutecode = getschedulelist.getString(1);
                    getroutename = getschedulelist.getString(4);
                    gettripadvance =  getschedulelist.getString(3);
                    getroutenametamil =  getschedulelist.getString(4);
                    getcapacity = getschedulelist.getString(5);
                }
                //Get Cash close Count
                getcashclosecount = objdatabaseadapter.GetCashClose(getschedulecode);
                //Get sales close Count
                getsalesclosecount = objdatabaseadapter.GetSalesClose(getschedulecode);
                getdenominationcount = objdatabaseadapter.GetDenominationCount(getschedulecode);
                //GetWish messsgae
                getwishmsg = objdatabaseadapter.GetWishmsg();

                if(!MenuActivity. getsalesclosecount.equals("0") && !MenuActivity. getsalesclosecount.equals("null") &&
                        !MenuActivity. getsalesclosecount.equals("") && !MenuActivity. getsalesclosecount.equals(null)){
                   /* String  getorderschedulecode = objdatabaseadapter.GetScheduleCode();
                    String getordercount = objdatabaseadapter.GetOrderFormCount(getorderschedulecode);
                    if(getordercount.equals("") || getordercount.equals("0") || getordercount.equals("null")){*/
                        OrderForm.setVisibility(View.VISIBLE);
                    cashcloseview.setVisibility(View.VISIBLE);
                   /* }else{
                        OrderForm.setVisibility(View.GONE);
                    }*/
                }else{
                    OrderForm.setVisibility(View.GONE);
                    cashcloseview.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        } finally {
            if(objdatabaseadapter!=null)
                objdatabaseadapter.close();
            if (getschedulelist != null)
                getschedulelist.close();
        }

        if(!LoginActivity.ismenuopen) {
            networkstate = isNetworkAvailable();
            if (networkstate == true) {
                new AsyncServer().execute();
            } else {
                /*Toast toast = Toast.makeText(getApplicationContext(), "Please check internet connection", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return;*/
                //Toast.makeText(getApplicationContext(),"Please check internet connection",Toast.LENGTH_SHORT).show();
            }
        }


        //Menu handling by Business_type
        if(LoginActivity.getbusiness_type.equals("2")){
            VanStocktLL.setVisibility(View.GONE);
            Cash_Report_LL.setVisibility(View.VISIBLE);
            Sales_Return_ReporsLL.setVisibility(View.GONE);
            Cash_Close_LL.setVisibility(View.VISIBLE);
            Sales_Layout.setVisibility(View.GONE);
            ReportsOrderChildLL.setVisibility(View.VISIBLE);
            SalesOrderLL.setVisibility(View.VISIBLE);
        }else   if(LoginActivity.getbusiness_type.equals("1")){
            Cash_Close_LL.setVisibility(View.GONE);
            SalesOrderLL.setVisibility(View.GONE);
            ReportsOrderChildLL.setVisibility(View.GONE);
        }else{
            SalesOrderLL.setVisibility(View.VISIBLE);
            Cash_Close_LL.setVisibility(View.GONE);
            ReportsOrderChildLL.setVisibility(View.VISIBLE);
        }



    }



    //Checking internet connection
    //sdfdfg
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }

    public void goBack(View v) {
        DataBaseAdapter objdatabaseadapter = null;
        String getschedulecount = "0";
        String getschedulestatus ="no";
        try {
            //Save Schdule Functionality
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            getschedulecount = objdatabaseadapter.GetScheduleCountDB();
            //Get General settings
             getschedulestatus = objdatabaseadapter.GetScheduleStatusDB();

        } catch (Exception e) {
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        } finally {
            objdatabaseadapter.close();
        }
        if(getschedulestatus.equals("yes")) {
            if (getschedulecount.equals("0")) {
                Intent i = new Intent(context, ScheduleActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(i);
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        }else {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Confirmation");
            builder.setMessage("Are you sure you want to logout?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent i = new Intent(context, LoginActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(i);
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();

                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();

        }


    }

    protected class AsyncServer extends
            AsyncTask<String, JSONObject,String> {
        JSONObject jsonObj = null;
        ProgressDialog loading;
        int code;
        @Override
        protected String doInBackground(String... params) {

            String result = "";
            try {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                URL siteURL = new URL(RestAPI.urlString);
                HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10*3000);
                connection.connect();
                code = connection.getResponseCode();
                if (code == 200) {
                    result="success";
                }
                connection.disconnect();

            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSync", e.getMessage());
                result="";

            }
            return result;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        protected void onPostExecute(final String result) {
            try {
                loading.dismiss();
                if(result.equals("success"))
                {
                   new AsyncCheckIMEI().execute();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Server not reachable", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception e) {
                Log.d("servererror",e.getMessage());
            }

        }


    }

    //check IMEI as valid
    protected class AsyncCheckIMEI extends
            AsyncTask<String, JSONObject,String> {
        JSONObject jsonObj = null;
        ProgressDialog loading;
        int code;
        @Override
        protected String doInBackground(String... params) {

            String result = "";
            try {
                RestAPI api = new RestAPI();
                networkstate = isNetworkAvailable();
                if (networkstate == true) {
                    jsonObj = api.CheckIMEI(LoginActivity.deviceid,"check_imei.php");
                }
                else{
                    result = "";
                }
                if(jsonObj!=null) {
                    if(jsonObj.has("success")) {
                        result = jsonObj.getString("success");
                    }
                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSync", e.getMessage());
                result="";

            }
            return result;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        protected void onPostExecute(final String result) {
            try {
                loading.dismiss();
                if(result.equals("1"))
                {
                    new AsyncSyncAllDetails().execute();
                }
                else if(result.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Server not reachable", Toast.LENGTH_SHORT).show();
                    return;
                }
                else
                {
                    DeleteIMEIDetails();
                    Toast toast = Toast.makeText(getApplicationContext(),"You are not authorized to use this application", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }
            } catch (Exception e) {
                Log.d("servererror",e.getMessage());
            }

        }


    }

    //Delete IMEI details
    public  String  DeleteIMEIDetails(){
        //Get phone imei number
        DataBaseAdapter objdatabaseadapter = null;
        String getcount="0";
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            objdatabaseadapter.deletevanmaster();
        }  catch (Exception e){
            Log.i("DeleteIMEIDetails", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();

        }
        return getcount;
    }
    //Sync all  datas
    protected  class AsyncSyncAllDetails extends
            AsyncTask<String, JSONObject, String> {
        String List = "Success";
        JSONObject jsonObj = null;
        ProgressDialog loading;

        @Override
        protected  String doInBackground(String... params) {

            RestAPI api = new RestAPI();
            String result = "";
            DataBaseAdapter dataBaseAdapter =null;
             String deviceid = LoginActivity.deviceid;
            try {
                dataBaseAdapter = new DataBaseAdapter(context);
                dataBaseAdapter.open();
                networkstate = isNetworkAvailable();
                if (networkstate == true) {
                    //Get Van Master
                    jsonObj = api.GetAllDetails(deviceid, "syncvanmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncvanmaster(jsonObj);
                        api.udfnSyncDetails(deviceid, "vanmaster", "0", "");
                    }
                    //General settings
                    jsonObj = api.GetAllDetails(deviceid,"syncgeneralsettings.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncgeneralsettings(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid,"generalsettings",LoginActivity.getvancode,"");
                    }
                    networkstate = isNetworkAvailable();
                    if (networkstate == true) {
                        try{
                            AsyncScheduleDetails();
                            AsyncCashReportDetails();
                            AsyncCloseCashDetails();
                            AsyncCustomerDetails();
                            AsyncExpenseDetails();
                            AsyncCancelExpenseDetails();
                            AsyncOrderDetails();
                            AsyncSalesDetails();
                            AsyncUpdateSalesReceiptDetails();
                            AsyncCloseSalesDetails();
                            AsyncSalesCancelDetails();
                            AsyncSalesReturnDetails();
                            AsyncSalesReturnCancelDetails();
                            AsyncReceiptDetails();
                            AsyncCancelReceiptDetails();
                            AsyncNilStockDetails();
                            AsyncSalesOrderDetails();
                            AsyncSalesOrderCancelDetails();

                        }catch (Exception e) {
                            // TODO Auto-generated catch block
                            Log.d("AsyncSync", e.getMessage());
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        }
                    }

                    /**************DELETE LAST DAY TRANSACTIONS IN SQL LITE***********/
                    dataBaseAdapter.open();

                    dataBaseAdapter.DeleteExpensesDays();
                    dataBaseAdapter.DeleteorderDetails();
                    dataBaseAdapter.DeleteReceiptDays();
                    dataBaseAdapter.DeleteSalesDays();
                    dataBaseAdapter.DeleteSalesItemDetailsDays();
                    dataBaseAdapter.DeleteSalesReturnDays();
                    dataBaseAdapter.DeleteSalesReturnItemDetailsDays();
                    dataBaseAdapter.DeleteSalesSchedule();
                    dataBaseAdapter.DeleteErrorLogDays();

                    /**************END DELETE LAST DAY TRANSACTIONS IN SQL LITE***********/


                    //Get General settings
                    String getschedulestatus = dataBaseAdapter.GetScheduleStatusDB();
                    if(getschedulestatus.equals("yes")){
                        //Sales Schedule
                        jsonObj = api.GetAllDetails(deviceid,"syncsalesschedulemobile.php");
                        if (isSuccessful(jsonObj)) {
                            dataBaseAdapter.syncsalesschedulemobile(jsonObj);
                            api.udfnSyncDetails(LoginActivity.deviceid,"salesschedule",LoginActivity.getvancode,"");
                        }
                    }else{
                        //Sales Schedule portal
                        jsonObj = api.GetAllDetails(deviceid,"syncsalesschedule.php");
                        if (isSuccessful(jsonObj)) {
                            dataBaseAdapter.syncsalesschedule(jsonObj);
                            api.udfnSyncDetails(LoginActivity.deviceid,"salesscheduleportal",LoginActivity.getvancode,"");
                        }
                    }

                    /*****SYNCH ALL MASTER************/
                    //company master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synccompanymaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccompanymaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "companymaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //area master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncareamaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncareamaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "areamaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //brand master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncbrandmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncbrandmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "brandmaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //currency
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synccurrency.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccurrency(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "currency", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //Receipt remarks
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncreceiptremarks.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncreceiptremarks(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "receiptremarks", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //tax
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synctax.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synctax(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "tax", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //Bill type
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncbilltype.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncbilltype(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "billtype", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //city
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synccitymaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccitymaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "citymaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //employee catergory
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncemployeecategory.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncemployeecategory(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "employeecategory", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //employee master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncemployeemaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncemployeemaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "employeemaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    Cursor getschedulelist = dataBaseAdapter.GetScheduleDB();
                    if(getschedulelist.getCount() >0){
                        for(int i=0;i<getschedulelist.getCount();i++) {
                            MenuActivity.getroutecode = getschedulelist.getString(1);
                        }
                    }
                    // customer
                    jsonObj = api.GetCustomerDetails(LoginActivity.deviceid,MenuActivity.getroutecode,"synccustomer.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccustomer(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "customer", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    // customer
                    jsonObj = api.GetCashNotPaidDetails(LoginActivity.deviceid,LoginActivity.getvancode,MenuActivity.getroutecode,"synccashnotpaiddetails.php");
                    dataBaseAdapter.DeleteCashNotPaid();
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccashnotpaiddetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "cashnotpaiddetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }



                    //expenses head
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncexpenseshead.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncexpenseshead(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "expenseshead", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //financial year
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncfinancialyear.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncfinancialyear(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "financialyear", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //general settings
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncgeneralsettings.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncgeneralsettings(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "generalsettings", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //itemgroup master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncitemgroupmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncitemgroupmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "itemgroupmaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //item master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncitemmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncitemmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "itemmaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //itemn price list transaction
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncitempricelisttransaction.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncitempricelisttransaction(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "itempricelisttransaction", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }


                    //item subgroup master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncitemsubgroupmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncitemsubgroupmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "itemsubgroupmaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //route
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncroute.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncroute(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "route", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //route details
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncroutedetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncroutedetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "routedetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //transport mode
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synctransportmode.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synctransportmode(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "transportmode", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //transport
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synctransport.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synctransport(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "transport", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //transportareamapping
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synctransportcitymapping.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synctransportareamapping(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "transportcitymapping", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //scheme
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncscheme.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncscheme(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "scheme", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //scheme item details
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncschemeitemdetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncschemeitemdetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "schemeitemdetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //scheme rate details
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncschemeratedetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncschemeratedetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "schemeratedetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //unit master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncunitmaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncunitmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "unitmaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //van stock
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncvanstock.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncvanstocktransaction(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "vanstock", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //vehicle master
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncvehiclemaster.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncvehiclemaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "vehiclemaster", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //voucher settings
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncvouchersettings.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncvouchersettings(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "vouchersettings", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //expenses
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncexpenses.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncexpensesmaster(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "expenses", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //cashclose
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synccashclose.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccashclose(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "cashclose", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //cashclose
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesclose.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesclose(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesclose", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //cashreport
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"synccashreport.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.synccashreport(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "cashreport", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //denomination
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncdenomination.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncdenomination(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "denomination", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //receipt
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncreceipt.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncreceipt(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "receipt", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //order details
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncorderdetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncorderdetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "orderdetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //Sales
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsales.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsales(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "sales", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //Salesitemdetails
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesitemdetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesitemdetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesitemdetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //Sales order
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesorder.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesorder(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesorder", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    //Sales order itemdetails
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesorderitemdetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesorderitemdetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesorderitemdetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //Salesreturn
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesreturn.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesreturn(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesreturn", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }


                    //Salesretrunitemdetails
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncsalesreturnitemdetails.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncsalesreturnitemdetails(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "salesreturnitemdetails", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //nilstock
                    jsonObj = api.GetAllDetails(LoginActivity.deviceid,"syncnilstock.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncnilstock(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "nilstock", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }

                    //maxrefno
                    LoginActivity.getfinanceyrcode = dataBaseAdapter.GetFinancialYrCode();
                    jsonObj = api.GetMaxCode(LoginActivity.deviceid,LoginActivity.getfinanceyrcode,"syncmaxrefno.php");
                    if (isSuccessful(jsonObj)) {
                        dataBaseAdapter.syncmaxrefno(jsonObj);
                        api.udfnSyncDetails(LoginActivity.deviceid, "maxrefno", LoginActivity.getvancode, ScheduleActivity.getsalesschedulecode);
                    }
                    new UploadImage().execute();
                }


            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSync", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            finally {
                dataBaseAdapter.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Synching Data", "Please wait...", true, true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            try {
                loading.dismiss();
                //Backupdb
                DataBaseAdapter mDbHelper1 = new DataBaseAdapter(context);
                mDbHelper1.open();
                String filepath = mDbHelper1.udfnBackupdb(context);
                mDbHelper1.close();

                DataBaseAdapter objdatabaseadapter = null;
                String getschedulecount = "0";
                String getschedulestatus = "";
                try {
                    //Save Schdule Functionality
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    LoginActivity.getfinanceyrcode = objdatabaseadapter.GetFinancialYrCode();
                    Cursor getschedulelist = objdatabaseadapter.GetScheduleDB();
                    if(getschedulelist.getCount() >0){
                        for(int i=0;i<getschedulelist.getCount();i++){
                            getschedulecode = getschedulelist.getString(0);
                            getroutecode = getschedulelist.getString(1);
                            getroutename = getschedulelist.getString(4);
                            gettripadvance =  getschedulelist.getString(3);
                            getroutenametamil =  getschedulelist.getString(4);
                            getcapacity = getschedulelist.getString(5);
                        }
                        //Get cash close Count
                        getcashclosecount = objdatabaseadapter.GetCashClose(getschedulecode);
                        //Get sales close Count
                        getdenominationcount = objdatabaseadapter.GetDenominationCount(getschedulecode);
                        getsalesclosecount = objdatabaseadapter.GetSalesClose(getschedulecode);
                        //GetWish messsgae
                        getwishmsg = objdatabaseadapter.GetWishmsg();
                    }
                    Cursor Cur = objdatabaseadapter.GetVanNameForIMEIDB(LoginActivity.deviceid);
                    if (Cur.getCount() > 0) {
                        LoginActivity.getvancode = Cur.getString(0);
                        LoginActivity.getbusiness_type = Cur.getString(4);
                        LoginActivity.getorderprint = Cur.getString(5);
                        LoginActivity.getvanname = Cur.getString(1);
                    }
                } catch (Exception e) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    objdatabaseadapter.close();
                }
                if(!MenuActivity. getsalesclosecount.equals("0") && !MenuActivity. getsalesclosecount.equals("null") &&
                        !MenuActivity. getsalesclosecount.equals("") && !MenuActivity. getsalesclosecount.equals(null)){
                    OrderForm.setVisibility(View.VISIBLE);
                }else{
                    OrderForm.setVisibility(View.GONE);
                }

            }catch (Exception e) {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }

        }
    }
    public  class UploadImage extends AsyncTask<String, JSONObject, String> {

        ProgressDialog loading;
        RequestHandler rh = new RequestHandler();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {

        }

        @Override
        protected String doInBackground(String... params) {
            String result="";
            try{
            // Bitmap bitmap = params[0];
            DataBaseAdapter objcustomerAdaptor = new DataBaseAdapter(context);
            objcustomerAdaptor.open();
            Cursor mCur = objcustomerAdaptor.GetSalesImageDetails();
            String uploadImage;

            for (int i=0;i<mCur.getCount();i++){
                if(mCur.getString(1) == null){
                    uploadImage="";
                }else {
                    uploadImage = mCur.getString(1);
                }
                HashMap<String, String> data = new HashMap<>();
                data.put("paraimage", uploadImage);
                data.put("paratransno", mCur.getString(0));
                data.put("parafinacialyearcode", mCur.getString(2));
                data.put("paraimagecode", mCur.getString(3));

                result = rh.sendPostRequest(UPLOAD_URL, data);
                if(result.equals("Success")) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    mDbErrHelper.SalesImageSetFlag(mCur.getString(0),mCur.getString(2));
                    mDbErrHelper.close();
                }
                mCur.moveToNext();
            }
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }


            return result;
        }
    }

    //CASH REPORT
    public void AsyncCashReportDetails(){
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            JSONObject js_obj1 = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCashReportDatasDB();
                Cursor mCur3 = dbadapter.GetDenominationDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("schedulecode", mCur2.getString(1));
                    obj.put("vancode", mCur2.getString(2));
                    obj.put("sales", mCur2.getDouble(3));
                    obj.put("salesreturn", mCur2.getDouble(4));
                    obj.put("advance", mCur2.getDouble(5));
                    obj.put("receipt", mCur2.getDouble(6));
                    obj.put("expenses", mCur2.getDouble(7));
                    obj.put("cash", mCur2.getDouble(8));
                    obj.put("denominationcash", mCur2.getDouble(9));
                    obj.put("makerid", mCur2.getString(10));
                    obj.put("createddate", mCur2.getString(11));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                JSONArray js_array3 = new JSONArray();
                for (int i = 0; i < mCur3.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur3.getString(0));
                    obj.put("vancode", mCur3.getString(1));
                    obj.put("schedulecode", mCur3.getString(2));
                    obj.put("currencycode", mCur3.getString(3));
                    obj.put("qty", mCur3.getDouble(4));
                    obj.put("amount", mCur3.getDouble(5));
                    obj.put("makerid", mCur3.getString(6));
                    obj.put("createddate", mCur3.getString(7));
                    js_array3.put(obj);
                    mCur3.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);
                js_obj1.put("JSonObject", js_array3);
                jsonObj =  api.CashReportDetails(js_obj.toString(),js_obj1.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseCashReport(jsonObj);
                dbadapter.close();

                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCashDetailsFlag(List.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }

    }
    //Cash close Details
    public void AsyncCloseCashDetails(){
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            JSONObject js_obj1 = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCloseSalesDatasDB();
                Cursor mCur3 = dbadapter.GetEndingKmScheduleDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("closedate", mCur2.getString(1));
                    obj.put("vancode", mCur2.getString(2));
                    obj.put("schedulecode", mCur2.getString(3));
                    obj.put("makerid", mCur2.getString(4));
                    obj.put("createddate", mCur2.getString(5));
                    obj.put("paidparties", mCur2.getString(6));
                    obj.put("expenseentries", mCur2.getString(7));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                JSONArray js_array3 = new JSONArray();
                for (int i = 0; i < mCur3.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("endingkm", mCur3.getString(0));
                    obj.put("schedulecode", mCur3.getString(1));
                    js_array3.put(obj);
                    mCur3.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);
                js_obj1.put("JSonObject", js_array3);
                jsonObj =  api.CashCloseDetails(js_obj.toString(),js_obj1.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseCashReport(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCashCloseFlag(List.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /********CUSTOMER DETAILS***********/
    public void AsyncCustomerDetails(){
        ArrayList<CustomerDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCustomerDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("customercode", mCur2.getString(1));
                    obj.put("refno", mCur2.getString(2));
                    obj.put("customername", mCur2.getString(3));
                    obj.put("customernametamil", mCur2.getString(4));
                    obj.put("address", mCur2.getString(5));
                    obj.put("areacode", mCur2.getString(6));
                    obj.put("emailid", mCur2.getString(7));
                    obj.put("mobileno", mCur2.getString(8));
                    obj.put("telephoneno", mCur2.getString(9));
                    obj.put("aadharno", mCur2.getString(10));
                    obj.put("gstin", mCur2.getString(11));
                    obj.put("status", mCur2.getString(12));
                    obj.put("makerid", mCur2.getString(13));
                    obj.put("createddate", mCur2.getString(14));
                    obj.put("updateddate", mCur2.getString(15));
                    obj.put("latitude", mCur2.getString(16));
                    obj.put("longitude", mCur2.getString(17));
                    obj.put("flag", mCur2.getString(18));
                    obj.put("schemeapplicable", mCur2.getString(19));
                    obj.put("uploaddocument", mCur2.getString(20));
                    obj.put("business_type", mCur2.getString(23));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.CustomerDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseCustomerDataList(jsonObj);
                dbadapter.close();

                if (List.size() >= 1) {
                    if(List.get(0).CustomerCode.length>0){
                        for(int j=0;j<List.get(0).CustomerCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCustomerFlag(List.get(0).CustomerCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("Customer", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /**********EXPENSE ACTIVITY*********/
    public void  AsyncExpenseDetails(){
        ArrayList<ExpenseDetails> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetExpensesDetailsDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("transactionno", mCur2.getString(1));
                    obj.put("transactiondate", mCur2.getString(2));
                    obj.put("expensesheadcode", mCur2.getString(3));
                    obj.put("amount", mCur2.getString(4));
                    obj.put("remarks", mCur2.getString(5));
                    obj.put("makerid", mCur2.getString(6));
                    obj.put("createdate", mCur2.getString(7));
                    obj.put("schedulecode", mCur2.getString(8));
                    obj.put("financialyearcode", mCur2.getString(9));
                    obj.put("vancode", mCur2.getString(10));
                    obj.put("flag", mCur2.getString(11));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.ExpenseDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseExpenseDataList(jsonObj);
                dbadapter.close();

                if (List.size() >= 1) {
                    if(List.get(0).TransactionNo.length>0){
                        for(int j=0;j<List.get(0).TransactionNo.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateExpenseDetailsFlag(List.get(0).TransactionNo[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Expebse cancel details
    public void  AsyncCancelExpenseDetails(){
        ArrayList<ExpenseDetails> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCancelExpensesDetailsDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("transactionno", mCur2.getString(1));
                    obj.put("transactiondate", mCur2.getString(2));
                    obj.put("expensesheadcode", mCur2.getString(3));
                    obj.put("amount", mCur2.getString(4));
                    obj.put("remarks", mCur2.getString(5));
                    obj.put("makerid", mCur2.getString(6));
                    obj.put("createdate", mCur2.getString(7));
                    obj.put("schedulecode", mCur2.getString(8));
                    obj.put("financialyearcode", mCur2.getString(9));
                    obj.put("vancode", mCur2.getString(10));
                    obj.put("flag", mCur2.getString(11));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.DeleteExpenseDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseExpenseDataList(jsonObj);
                dbadapter.close();

                if (List.size() >= 1) {
                    if(List.get(0).TransactionNo.length>0){
                        for(int j=0;j<List.get(0).TransactionNo.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.DeleteExpenseDetailsFlag(List.get(0).TransactionNo[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /************next day requirement details*******/
    public  void AsyncOrderDetails(){
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetOrderDetailsDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("vancode", mCur2.getString(1));
                    obj.put("schedulecode", mCur2.getString(2));
                    obj.put("itemcode", mCur2.getString(3));
                    obj.put("qty", mCur2.getString(4));
                    obj.put("makerid", mCur2.getString(5));
                    obj.put("createddate", mCur2.getString(6));
                    obj.put("orderdate", mCur2.getString(7));
                    obj.put("flag", mCur2.getString(8));
                    obj.put("status", mCur2.getString(9));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.OrderDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseOrderDataList(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateOrderDetailsFlag(List.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }

    }
    /***************** SALES DETAILS *********************************/
    public void  AsyncSalesDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_salesitemobj = new JSONObject();
            JSONObject js_stockobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCustomerDatasDB();
                Cursor mCursales = dbadapter.GetSalesDatasDB();
                Cursor mCursalesitems = dbadapter.GetSalesItemDatasDB();
                Cursor mCurStock = dbadapter.GetSalesStockTransactionDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_array3 = new JSONArray();
                JSONArray js_stockarray = new JSONArray();
                JSONArray js_array4 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("customercode", mCur2.getString(1));
                    obj.put("refno", mCur2.getString(2));
                    obj.put("customername", mCur2.getString(3));
                    obj.put("customernametamil", mCur2.getString(4));
                    obj.put("address", mCur2.getString(5));
                    obj.put("areacode", mCur2.getString(6));
                    obj.put("emailid", mCur2.getString(7));
                    obj.put("mobileno", mCur2.getString(8));
                    obj.put("telephoneno", mCur2.getString(9));
                    obj.put("aadharno", mCur2.getString(10));
                    obj.put("gstin", mCur2.getString(11));
                    obj.put("status", mCur2.getString(12));
                    obj.put("makerid", mCur2.getString(13));
                    obj.put("createddate", mCur2.getString(14));
                    obj.put("updateddate", mCur2.getString(15));
                    obj.put("latitude", mCur2.getString(16));
                    obj.put("longitude", mCur2.getString(17));
                    obj.put("flag", mCur2.getString(18));
                    obj.put("schemeapplicable", mCur2.getString(19));
                    obj.put("uploaddocument", mCur2.getString(20));

                    js_array4.put(obj);
                    mCur2.moveToNext();
                }
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));
                    obj.put("salestime", mCursales.getString(29));
                    obj.put("beforeroundoff", mCursales.getString(30));

                    js_array2.put(obj);
                    mCursales.moveToNext();
                }
                for (int i = 0; i < mCursalesitems.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursalesitems.getString(0));
                    obj.put("transactionno", mCursalesitems.getString(1));
                    obj.put("companycode", mCursalesitems.getString(2));
                    obj.put("itemcode", mCursalesitems.getString(3));
                    obj.put("qty", mCursalesitems.getString(4));
                    obj.put("weight", mCursalesitems.getString(5));
                    obj.put("price", mCursalesitems.getString(6));
                    obj.put("discount", mCursalesitems.getDouble(7));
                    obj.put("amount", mCursalesitems.getDouble(8));
                    obj.put("cgst", mCursalesitems.getDouble(9));
                    obj.put("sgst", mCursalesitems.getDouble(10));
                    obj.put("igst", mCursalesitems.getDouble(11));
                    obj.put("cgstamt", mCursalesitems.getDouble(12));
                    obj.put("sgstamt", mCursalesitems.getDouble(13));
                    obj.put("igstamt", mCursalesitems.getDouble(14));
                    obj.put("freeitemstatus", mCursalesitems.getString(15));
                    obj.put("makerid", mCursalesitems.getString(16));
                    obj.put("createddate", mCursalesitems.getString(17));
                    obj.put("updateddate", mCursalesitems.getString(18));
                    obj.put("bookingno", mCursalesitems.getString(19));
                    obj.put("financialyearcode", mCursalesitems.getString(20));
                    obj.put("vancode", mCursalesitems.getString(21));
                    obj.put("flag", mCursalesitems.getString(22));

                    js_array3.put(obj);
                    mCursalesitems.moveToNext();
                }

                for (int i = 0; i < mCurStock.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("transactionno", mCurStock.getString(0));
                    obj.put("transactiondate", mCurStock.getString(1));
                    obj.put("vancode", mCurStock.getString(2));
                    obj.put("itemcode", mCurStock.getString(3));
                    obj.put("inward", mCurStock.getString(4));
                    obj.put("outward", mCurStock.getString(5));
                    obj.put("type", mCurStock.getString(6));
                    obj.put("refno", mCurStock.getString(7));
                    obj.put("createddate", mCurStock.getString(8));
                    obj.put("flag", mCurStock.getString(9));
                    obj.put("companycode", mCurStock.getString(10));
                    obj.put("financialyearcode", mCurStock.getString(11));
                    obj.put("autonum", mCurStock.getString(12));

                    js_stockarray.put(obj);
                    mCurStock.moveToNext();
                }
                js_obj.put("JSonObject", js_array4);
                js_salesobj.put("JSonObject", js_array2);
                js_salesitemobj.put("JSonObject", js_array3);
                js_stockobj.put("JSonObject",js_stockarray);

                jsonObj =  api.SalesDetails(js_salesobj.toString(),js_salesitemobj.toString(),js_stockobj.toString(),js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesDataList(jsonObj);
                dbadapter.close();

                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                        if (List.get(0).SalesItemTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).SalesItemTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesItemFlag(List.get(0).SalesItemTransactionNo[j]);
                            }
                        }
                        if (List.get(0).StockTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                                String[] getArr = List.get(0).StockTransactionNo[j].split("~");
                                objdatabaseadapter.UpdateSalesStockTransactionFlag(getArr[0],getArr[1]);
                            }
                        }
                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Sales  update receipt and bill wise
    public void  AsyncUpdateSalesReceiptDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_salesobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCursales = dbadapter.GetSalesReceiptDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));

                    js_array2.put(obj);
                    mCursales.moveToNext();
                }

                js_salesobj.put("JSonObject", js_array2);

                jsonObj =  api.SalesReceiptDetails(js_salesobj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesReceiptDataList(jsonObj);
                dbadapter.close();
                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                // objdatabaseadapter.UpdateSalesRecieptFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Sales Close
    public void AsyncCloseSalesDetails(){
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCloseSalesitemDatasDB();

                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("closedate", mCur2.getString(1));
                    obj.put("vancode", mCur2.getString(2));
                    obj.put("schedulecode", mCur2.getString(3));
                    obj.put("makerid", mCur2.getString(4));
                    obj.put("createddate", mCur2.getString(5));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }

                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.SalesCloseDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseCashReport(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateSalesCloseFlag(List.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Sales Cancel
    public void AsyncSalesCancelDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_salesitemobj = new JSONObject();
            JSONObject js_stockobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCursales = dbadapter.GetSalesCancelDatasDB();
                Cursor mCursalesitems = dbadapter.GetSalesCancelItemDatasDB();
                Cursor mCurStock = dbadapter.GetCancelStockTransactionDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_array3 = new JSONArray();
                JSONArray js_stockarray = new JSONArray();
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));

                    js_array2.put(obj);
                    mCursales.moveToNext();
                }

                for (int i = 0; i < mCursalesitems.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursalesitems.getString(0));
                    obj.put("transactionno", mCursalesitems.getString(1));
                    obj.put("companycode", mCursalesitems.getString(2));
                    obj.put("itemcode", mCursalesitems.getString(3));
                    obj.put("qty", mCursalesitems.getString(4));
                    obj.put("weight", mCursalesitems.getString(5));
                    obj.put("price", mCursalesitems.getString(6));
                    obj.put("discount", mCursalesitems.getDouble(7));
                    obj.put("amount", mCursalesitems.getDouble(8));
                    obj.put("cgst", mCursalesitems.getDouble(9));
                    obj.put("sgst", mCursalesitems.getDouble(10));
                    obj.put("igst", mCursalesitems.getDouble(11));
                    obj.put("cgstamt", mCursalesitems.getDouble(12));
                    obj.put("sgstamt", mCursalesitems.getDouble(13));
                    obj.put("igstamt", mCursalesitems.getDouble(14));
                    obj.put("freeitemstatus", mCursalesitems.getString(15));
                    obj.put("makerid", mCursalesitems.getString(16));
                    obj.put("createddate", mCursalesitems.getString(17));
                    obj.put("updateddate", mCursalesitems.getString(18));
                    obj.put("bookingno", mCursalesitems.getString(19));
                    obj.put("financialyearcode", mCursalesitems.getString(20));
                    obj.put("vancode", mCursalesitems.getString(21));
                    obj.put("flag", mCursalesitems.getString(22));

                    js_array3.put(obj);
                    mCursalesitems.moveToNext();
                }

                for (int i = 0; i < mCurStock.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("transactionno", mCurStock.getString(0));
                    obj.put("transactiondate", mCurStock.getString(1));
                    obj.put("vancode", mCurStock.getString(2));
                    obj.put("itemcode", mCurStock.getString(3));
                    obj.put("inward", mCurStock.getString(4));
                    obj.put("outward", mCurStock.getString(5));
                    obj.put("type", mCurStock.getString(6));
                    obj.put("refno", mCurStock.getString(7));
                    obj.put("createddate", mCurStock.getString(8));
                    obj.put("flag", mCurStock.getString(9));
                    obj.put("companycode", mCurStock.getString(10));
                    obj.put("financialyearcode", mCurStock.getString(12));
                    obj.put("autonum", mCurStock.getString(13));
                    js_stockarray.put(obj);
                    mCurStock.moveToNext();
                }
                js_salesobj.put("JSonObject", js_array2);
                js_salesitemobj.put("JSonObject", js_array3);
                js_stockobj.put("JSonObject",js_stockarray);

                jsonObj =  api.SalesCancelDetails(js_salesobj.toString(), js_salesitemobj.toString(), js_stockobj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesCancelDataList(jsonObj);
                dbadapter.close();
                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateCancelSalesFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                        if (List.get(0).StockTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateCancelSalesStockTransactionFlag(List.get(0).StockTransactionNo[j]);
                            }
                        }
                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    /***************** Sales Return DETAILS *********************************/
    public void AsyncSalesReturnDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_salesitemobj = new JSONObject();
            JSONObject js_stockobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCursales = dbadapter.GetSalesReturnDatasDB();
                Cursor mCursalesitems = dbadapter.GetSalesReturnItemDatasDB();
                Cursor mCurStock = dbadapter.GetStockTransactionDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_array3 = new JSONArray();
                JSONArray js_stockarray = new JSONArray();
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));
                    obj.put("salestime", mCursales.getString(28));
                    obj.put("beforeroundoff", mCursales.getString(29));
                    js_array2.put(obj);
                    mCursales.moveToNext();
                }
                for (int i = 0; i < mCursalesitems.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursalesitems.getString(0));
                    obj.put("transactionno", mCursalesitems.getString(1));
                    obj.put("companycode", mCursalesitems.getString(2));
                    obj.put("itemcode", mCursalesitems.getString(3));
                    obj.put("qty", mCursalesitems.getString(4));
                    obj.put("weight", mCursalesitems.getString(5));
                    obj.put("price", mCursalesitems.getString(6));
                    obj.put("discount", mCursalesitems.getDouble(7));
                    obj.put("amount", mCursalesitems.getDouble(8));
                    obj.put("cgst", mCursalesitems.getDouble(9));
                    obj.put("sgst", mCursalesitems.getDouble(10));
                    obj.put("igst", mCursalesitems.getDouble(11));
                    obj.put("cgstamt", mCursalesitems.getDouble(12));
                    obj.put("sgstamt", mCursalesitems.getDouble(13));
                    obj.put("igstamt", mCursalesitems.getDouble(14));
                    obj.put("freeitemstatus", mCursalesitems.getString(15));
                    obj.put("makerid", mCursalesitems.getString(16));
                    obj.put("createddate", mCursalesitems.getString(17));
                    obj.put("updateddate", mCursalesitems.getString(18));
                    obj.put("bookingno", mCursalesitems.getString(19));
                    obj.put("financialyearcode", mCursalesitems.getString(20));
                    obj.put("vancode", mCursalesitems.getString(21));
                    obj.put("flag", mCursalesitems.getString(22));

                    js_array3.put(obj);
                    mCursalesitems.moveToNext();
                }

                for (int i = 0; i < mCurStock.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("transactionno", mCurStock.getString(0));
                    obj.put("transactiondate", mCurStock.getString(1));
                    obj.put("vancode", mCurStock.getString(2));
                    obj.put("itemcode", mCurStock.getString(3));
                    obj.put("inward", mCurStock.getString(4));
                    obj.put("outward", mCurStock.getString(5));
                    obj.put("type", mCurStock.getString(6));
                    obj.put("refno", mCurStock.getString(7));
                    obj.put("createddate", mCurStock.getString(8));
                    obj.put("flag", mCurStock.getString(9));
                    obj.put("companycode", mCurStock.getString(10));
                    obj.put("financialyearcode", mCurStock.getString(11));
                    obj.put("autonum", mCurStock.getString(12));
                    js_stockarray.put(obj);
                    mCurStock.moveToNext();
                }
                js_salesobj.put("JSonObject", js_array2);
                js_salesitemobj.put("JSonObject", js_array3);
                js_stockobj.put("JSonObject",js_stockarray);

                jsonObj =  api.SalesReturnDetails(js_salesobj.toString(),js_salesitemobj.toString(),js_stockobj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesDataList(jsonObj);
                dbadapter.close();
                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesReturnFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                        if (List.get(0).SalesItemTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).SalesItemTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesReturnItemFlag(List.get(0).SalesItemTransactionNo[j]);
                            }
                        }
                        if (List.get(0).StockTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateStockTransactionFlag(List.get(0).StockTransactionNo[j]);
                            }
                        }
                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesreturnDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Cancel sales return
    public void AsyncSalesReturnCancelDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_stockobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCursales = dbadapter.GetSalesReturnCancelDatasDB();
                Cursor mCurStock = dbadapter.GetCancelReturnStockTransactionDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_stockarray = new JSONArray();
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));

                    js_array2.put(obj);
                    mCursales.moveToNext();
                }

                for (int i = 0; i < mCurStock.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("transactionno", mCurStock.getString(0));
                    obj.put("transactiondate", mCurStock.getString(1));
                    obj.put("vancode", mCurStock.getString(2));
                    obj.put("itemcode", mCurStock.getString(3));
                    obj.put("inward", mCurStock.getString(4));
                    obj.put("outward", mCurStock.getString(5));
                    obj.put("type", mCurStock.getString(6));
                    obj.put("refno", mCurStock.getString(7));
                    obj.put("createddate", mCurStock.getString(8));
                    obj.put("flag", mCurStock.getString(9));
                    obj.put("companycode", mCurStock.getString(10));
                    obj.put("financialyearcode", mCurStock.getString(11));
                    obj.put("autonum", mCurStock.getString(12));
                    js_stockarray.put(obj);
                    mCurStock.moveToNext();
                }
                js_salesobj.put("JSonObject", js_array2);
                js_stockobj.put("JSonObject",js_stockarray);

                jsonObj =  api.SalesReturnCancelDetails(js_salesobj.toString(),js_stockobj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesCancelDataList(jsonObj);
                dbadapter.close();
                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateCancelSalesReturnFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                        if (List.get(0).StockTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateCancelSalesReturnStockTransactionFlag(List.get(0).StockTransactionNo[j]);
                            }
                        }
                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /***************Receipt detils********/
    public void AsyncReceiptDetails(){
        ArrayList<ReceiptTransactionDetails> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetReceiptDetailsDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("transactionno", mCur2.getString(1));
                    obj.put("receiptdate", mCur2.getString(2));
                    obj.put("prefix", mCur2.getString(3));
                    obj.put("suffix", mCur2.getString(4));
                    obj.put("voucherno", mCur2.getString(5));
                    obj.put("refno", mCur2.getString(6));
                    obj.put("companycode", mCur2.getString(7));
                    obj.put("vancode", mCur2.getString(8));
                    obj.put("customercode", mCur2.getString(9));
                    obj.put("schedulecode", mCur2.getString(10));
                    obj.put("receiptremarkscode", mCur2.getString(11));
                    obj.put("receiptmode", mCur2.getString(12));
                    obj.put("chequerefno", mCur2.getString(13));
                    obj.put("amount", mCur2.getDouble(14));
                    obj.put("makerid", mCur2.getString(15));
                    obj.put("createddate", mCur2.getString(16));
                    obj.put("financialyearcode", mCur2.getString(17));
                    obj.put("flag", mCur2.getString(18));
                    obj.put("note", mCur2.getString(19));
                    obj.put("receipttime", mCur2.getString(21));

                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.ReceiptDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseReceiptDataList(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).TransactionNo.length>0){
                        for(int j=0;j<List.get(0).TransactionNo.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateReceiptDetailsFlag(List.get(0).TransactionNo[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Receipt cancel details
    public  void  AsyncCancelReceiptDetails(){
        ArrayList<ReceiptTransactionDetails> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCancelReceiptDetailsDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("transactionno", mCur2.getString(1));
                    obj.put("receiptdate", mCur2.getString(2));
                    obj.put("prefix", mCur2.getString(3));
                    obj.put("suffix", mCur2.getString(4));
                    obj.put("voucherno", mCur2.getString(5));
                    obj.put("refno", mCur2.getString(6));
                    obj.put("companycode", mCur2.getString(7));
                    obj.put("vancode", mCur2.getString(8));
                    obj.put("customercode", mCur2.getString(9));
                    obj.put("schedulecode", mCur2.getString(10));
                    obj.put("receiptremarkscode", mCur2.getString(11));
                    obj.put("receiptmode", mCur2.getString(12));
                    obj.put("chequerefno", mCur2.getString(13));
                    obj.put("amount", mCur2.getDouble(14));
                    obj.put("makerid", mCur2.getString(15));
                    obj.put("createddate", mCur2.getString(16));
                    obj.put("financialyearcode", mCur2.getString(17));
                    obj.put("flag", mCur2.getString(18));
                    obj.put("note", mCur2.getString(19));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.CancelREciptDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseReceiptDataList(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).TransactionNo.length>0){
                        for(int j=0;j<List.get(0).TransactionNo.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCancelReceiptFlag(List.get(0).TransactionNo[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    public void AsyncNilStockDetails(){
        RestAPI api = new RestAPI();
        try {
            JSONObject js_obj = new JSONObject();
            ArrayList<ScheduleDatas> List = null;
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetNilStockDetailsDB();

                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("vancode", mCur2.getString(1));
                    obj.put("schedulecode", mCur2.getString(2));
                    obj.put("salestransactionno", mCur2.getString(3));
                    obj.put("salesbookingno", mCur2.getString(4));
                    obj.put("salesfinacialyearcode", mCur2.getString(5));
                    obj.put("salescustomercode", mCur2.getString(6));
                    obj.put("salesitemcode", mCur2.getString(7));
                    obj.put("createddate", mCur2.getString(8));
                    obj.put("flag", mCur2.getString(9));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }

                js_obj.put("JSonObject", js_array2);

                JSONObject jsonObj =  api.NilStockDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                 List = parser.parseNilStockReport(jsonObj);
                dbadapter.close();

                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            if(List.get(0).ScheduleCode[j] != "" && !List.get(0).ScheduleCode[j].equals("")){
                                String getsplitval[] = List.get(0).ScheduleCode[j].split("~");
                                dataBaseAdapter.UpdateNilStockFlag(getsplitval[0],getsplitval[1]);
                            }
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    public void AsyncSalesOrderDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        String result = "";
        try {
            JSONObject js_obj = new JSONObject();
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_salesitemobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetCustomerDatasDB();
                Cursor mCursales = dbadapter.GetSalesOrderDatasDB();
                Cursor mCursalesitems = dbadapter.GetSalesOrderItemDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_array3 = new JSONArray();
                JSONArray js_array4 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("customercode", mCur2.getString(1));
                    obj.put("refno", mCur2.getString(2));
                    obj.put("customername", mCur2.getString(3));
                    obj.put("customernametamil", mCur2.getString(4));
                    obj.put("address", mCur2.getString(5));
                    obj.put("areacode", mCur2.getString(6));
                    obj.put("emailid", mCur2.getString(7));
                    obj.put("mobileno", mCur2.getString(8));
                    obj.put("telephoneno", mCur2.getString(9));
                    obj.put("aadharno", mCur2.getString(10));
                    obj.put("gstin", mCur2.getString(11));
                    obj.put("status", mCur2.getString(12));
                    obj.put("makerid", mCur2.getString(13));
                    obj.put("createddate", mCur2.getString(14));
                    obj.put("updateddate", mCur2.getString(15));
                    obj.put("latitude", mCur2.getString(16));
                    obj.put("longitude", mCur2.getString(17));
                    obj.put("flag", mCur2.getString(18));
                    obj.put("schemeapplicable", mCur2.getString(19));
                    obj.put("uploaddocument", mCur2.getString(20));

                    js_array4.put(obj);
                    mCur2.moveToNext();
                }
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getDouble(13));
                    obj.put("discount", mCursales.getDouble(14));
                    obj.put("totaltaxamount", mCursales.getDouble(15));
                    obj.put("grandtotal", mCursales.getDouble(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));
                    obj.put("salestime", mCursales.getString(29));
                    obj.put("beforeroundoff", mCursales.getString(30));
                    obj.put("transportid", mCursales.getString(31));
                    js_array2.put(obj);
                    mCursales.moveToNext();
                }
                for (int i = 0; i < mCursalesitems.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursalesitems.getString(0));
                    obj.put("transactionno", mCursalesitems.getString(1));
                    obj.put("companycode", mCursalesitems.getString(2));
                    obj.put("itemcode", mCursalesitems.getString(3));
                    obj.put("qty", mCursalesitems.getString(4));
                    obj.put("weight", mCursalesitems.getString(5));
                    obj.put("price", mCursalesitems.getString(6));
                    obj.put("discount", mCursalesitems.getDouble(7));
                    obj.put("amount", mCursalesitems.getDouble(8));
                    obj.put("cgst", mCursalesitems.getDouble(9));
                    obj.put("sgst", mCursalesitems.getDouble(10));
                    obj.put("igst", mCursalesitems.getDouble(11));
                    obj.put("cgstamt", mCursalesitems.getDouble(12));
                    obj.put("sgstamt", mCursalesitems.getDouble(13));
                    obj.put("igstamt", mCursalesitems.getDouble(14));
                    obj.put("freeitemstatus", mCursalesitems.getString(15));
                    obj.put("makerid", mCursalesitems.getString(16));
                    obj.put("createddate", mCursalesitems.getString(17));
                    obj.put("updateddate", mCursalesitems.getString(18));
                    obj.put("bookingno", mCursalesitems.getString(19));
                    obj.put("financialyearcode", mCursalesitems.getString(20));
                    obj.put("vancode", mCursalesitems.getString(21));
                    obj.put("flag", mCursalesitems.getString(22));

                    js_array3.put(obj);
                    mCursalesitems.moveToNext();
                }


                js_obj.put("JSonObject", js_array4);
                js_salesobj.put("JSonObject", js_array2);
                js_salesitemobj.put("JSonObject", js_array3);

                jsonObj =  api.SalesOrderDetails(js_salesobj.toString(),js_salesitemobj.toString(),js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesDataList(jsonObj);
                dbadapter.close();

                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesOrderFlag(List.get(0).TransactionNo[j]);
                            }
                        }
                        if (List.get(0).SalesItemTransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).SalesItemTransactionNo.length; j++) {
                                objdatabaseadapter.UpdateSalesOrderItemFlag(List.get(0).SalesItemTransactionNo[j]);
                            }
                        }

                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    //Async sales ordercancel
    public void AsyncSalesOrderCancelDetails(){
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        try {
            JSONObject js_salesobj = new JSONObject();
            JSONObject js_salesitemobj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCursales = dbadapter.GetSalesOrderCancelDatasDB();
                Cursor mCursalesitems = dbadapter.GetSalesOrderCancelItemDatasDB();
                JSONArray js_array2 = new JSONArray();
                JSONArray js_array3 = new JSONArray();
                for (int i = 0; i < mCursales.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursales.getString(0));
                    obj.put("companycode", mCursales.getString(1));
                    obj.put("vancode", mCursales.getString(2));
                    obj.put("transactionno", mCursales.getString(3));
                    obj.put("billno", mCursales.getString(4));
                    obj.put("refno", mCursales.getString(5));
                    obj.put("prefix", mCursales.getString(6));
                    obj.put("suffix", mCursales.getString(7));
                    obj.put("billdate", mCursales.getString(8));
                    obj.put("customercode", mCursales.getString(9));
                    obj.put("billtypecode", mCursales.getString(10));
                    obj.put("gstin", mCursales.getString(11));
                    obj.put("schedulecode", mCursales.getString(12));
                    obj.put("subtotal", mCursales.getString(13));
                    obj.put("discount", mCursales.getString(14));
                    obj.put("totaltaxamount", mCursales.getString(15));
                    obj.put("grandtotal", mCursales.getString(16));
                    obj.put("billcopystatus", mCursales.getString(17));
                    obj.put("cashpaidstatus", mCursales.getString(18));
                    obj.put("flag", mCursales.getString(19));
                    obj.put("makerid", mCursales.getString(20));
                    obj.put("createddate", mCursales.getString(21));
                    obj.put("updateddate", mCursales.getString(22));
                    obj.put("bitmapimage", mCursales.getString(23));
                    obj.put("financialyearcode", mCursales.getString(24));
                    obj.put("remarks", mCursales.getString(25));
                    obj.put("bookingno", mCursales.getString(26));
                    obj.put("salestime", mCursales.getString(29));
                    obj.put("beforeroundoff", mCursales.getString(30));
                    obj.put("transportid", mCursales.getString(31));
                    js_array2.put(obj);
                    mCursales.moveToNext();
                }

                for (int i = 0; i < mCursalesitems.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCursalesitems.getString(0));
                    obj.put("transactionno", mCursalesitems.getString(1));
                    obj.put("companycode", mCursalesitems.getString(2));
                    obj.put("itemcode", mCursalesitems.getString(3));
                    obj.put("qty", mCursalesitems.getString(4));
                    obj.put("weight", mCursalesitems.getString(5));
                    obj.put("price", mCursalesitems.getString(6));
                    obj.put("discount", mCursalesitems.getDouble(7));
                    obj.put("amount", mCursalesitems.getDouble(8));
                    obj.put("cgst", mCursalesitems.getDouble(9));
                    obj.put("sgst", mCursalesitems.getDouble(10));
                    obj.put("igst", mCursalesitems.getDouble(11));
                    obj.put("cgstamt", mCursalesitems.getDouble(12));
                    obj.put("sgstamt", mCursalesitems.getDouble(13));
                    obj.put("igstamt", mCursalesitems.getDouble(14));
                    obj.put("freeitemstatus", mCursalesitems.getString(15));
                    obj.put("makerid", mCursalesitems.getString(16));
                    obj.put("createddate", mCursalesitems.getString(17));
                    obj.put("updateddate", mCursalesitems.getString(18));
                    obj.put("bookingno", mCursalesitems.getString(19));
                    obj.put("financialyearcode", mCursalesitems.getString(20));
                    obj.put("vancode", mCursalesitems.getString(21));
                    obj.put("flag", mCursalesitems.getString(22));

                    js_array3.put(obj);
                    mCursalesitems.moveToNext();
                }
                js_salesobj.put("JSonObject", js_array2);
                js_salesitemobj.put("JSonObject", js_array3);

                jsonObj =  api.SalesOrderCancelDetails(js_salesobj.toString(), js_salesitemobj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseSalesCancelDataList(jsonObj);
                dbadapter.close();

                DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                try {
                    objdatabaseadapter.open();
                    if (List.size() >= 1) {
                        if (List.get(0).TransactionNo.length > 0) {
                            for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                                objdatabaseadapter.UpdateOrderCancelSalesFlag(List.get(0).TransactionNo[j]);
                            }
                        }

                    }
                }catch (Exception e) {
                    // TODO Auto-generated catch block
                    Log.d("AsyncSalesDetails", e.getMessage());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSalesDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    /*********SCHEDULE DETAILS*************/
    public void AsyncScheduleDetails(){
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        RestAPI api = new RestAPI();
        String result = "";
        try {
            JSONObject js_obj = new JSONObject();
            try {
                DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                dbadapter.open();
                Cursor mCur2 = dbadapter.GetScheduleDatasDB();
                JSONArray js_array2 = new JSONArray();
                for (int i = 0; i < mCur2.getCount(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("autonum", mCur2.getString(0));
                    obj.put("refno", mCur2.getString(1));
                    obj.put("schedulecode", mCur2.getString(2));
                    obj.put("scheduledate", mCur2.getString(3));
                    obj.put("vancode", mCur2.getString(4));
                    obj.put("routecode", mCur2.getString(5));
                    obj.put("vehiclecode", mCur2.getString(6));
                    obj.put("employeecode", mCur2.getString(7));
                    obj.put("drivercode", mCur2.getString(8));
                    obj.put("helpername", mCur2.getString(9));
                    obj.put("tripadvance", mCur2.getString(10));
                    obj.put("startingkm", mCur2.getString(11));
                    obj.put("endingkm", mCur2.getString(12));
                    obj.put("createddate", mCur2.getString(13));
                    obj.put("updatedate", mCur2.getString(14));
                    obj.put("makerid", mCur2.getString(15));
                    obj.put("lunch_start_time", mCur2.getString(17));
                    obj.put("lunch_end_time", mCur2.getString(18));
                    js_array2.put(obj);
                    mCur2.moveToNext();
                }
                js_obj.put("JSonObject", js_array2);

                jsonObj =  api.ScheduleDetails(js_obj.toString());
                //Call Json parser functionality
                JSONParser parser = new JSONParser();
                //parse the json object to boolean
                List = parser.parseScheduleDataList(jsonObj);
                dbadapter.close();
                if (List.size() >= 1) {
                    if(List.get(0).ScheduleCode.length>0){
                        for(int j=0;j<List.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateScheduleFlag(List.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }
            catch (Exception e)
            {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /*************************END FUNCTIONS***********************/


    private boolean isSuccessful(JSONObject object) {
        boolean success = false;
        if (object != null) {
            try {
                String success1 = object.getString("success");
                if (success1.equals("1")) {
                    success = (object.getJSONArray("Value").length()) > 0;
                }
            } catch (JSONException e) {
                Log.d("JSON Error", e.getMessage());
            }
        }
        return success;
    }
    @Override
    public void onBackPressed() {
        goBack(null);
    }
}
