package thanjavurvansales.sss;

import java.util.ArrayList;
import java.util.Collections;

class SalesItemSorter {
    ArrayList<SalesItemDetails> SAlesItems = new ArrayList<>();
    public SalesItemSorter(ArrayList<SalesItemDetails> SAlesItems) {
        this.SAlesItems = SAlesItems;
    }
    /*public ArrayList<SalesItemDetails> getSortedSalesPurchaseItem() {
        Collections.sort(SAlesItems);
        return SAlesItems;
    }*/
}
