package thanjavurvansales.sss;

class ExpenseDetails {
    String[] TransactionNo;
    public String[] getTransactionNo(){ return TransactionNo;}
    public ExpenseDetails(String[] TransactionNo) {
        super();
        this.TransactionNo = TransactionNo;
    }
}
