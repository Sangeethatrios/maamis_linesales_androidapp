package thanjavurvansales.sss;

class ScheduleDatas {
    String[] ScheduleCode;
    public String[] getScheduleCode(){ return ScheduleCode;}
    public ScheduleDatas(String[] ScheduleCode) {
        super();
        this.ScheduleCode = ScheduleCode;
    }
}
