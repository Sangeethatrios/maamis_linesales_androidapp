package thanjavurvansales.sss;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class CustomerActivity extends AppCompatActivity {

    ImageView addcustomer;
    Dialog dialog;
    Context context;
    ArrayList<CustomerDetails> customerlist = new ArrayList<CustomerDetails>();
    ArrayList<CustomerDetails> getdata;
    public static SwipeMenuListView listView;
    ImageView customerlistgoback,customerlogout;
    public boolean isinsert = true;

    TextView txtcustomername,txtcustomernametamil,txtaddress,txtcityname,
            txtarea,txtphoneno,txtlandlineno,txtemailid,txtgstin,txtadhar,listtxtroute,listtxtarea,totalcustomers;
    Button btnSaveCustomer;
    String[] citycode,cityname,citynametamil;
    String[] areacode,areaname,areanametamil,customercount;
    Dialog citydialog,areadialog,routedialog;
    ListView lv_CityList,lv_ListAreaList,lv_Routelist,lv_AreaList;
    String getcitycode="0",getareacode="0";
    boolean networkstate;
    String getlistroutecode="0",getlistareacode="0";
    CustomerListBaseAdapter adapter =null;
    String[] routecode,routename,routenametamil;
    String[] AreaCode,AreaName,AreaNameTamil,NoOfKm,CityCode,CityName,CustomerCount;
    public static final String GSTINFORMAT_REGEX = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
    public static final String GSTN_CODEPOINT_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String listcustomercode=""; String listcustomername=""; String listcustomernametamil="";
    String listaddress=""; String listareacode=""; String listmobileno=""; String listtelephoneno="";
    String listgstin=""; String listareaname="",listcitycode="",listcityname="",listemailid="",listaadharino="";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String lunch_start_time = "",lunch_end_time="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        context = this;
        listView = (SwipeMenuListView) findViewById(R.id.listView);
        addcustomer = (ImageView)findViewById(R.id.addcustomer);
        customerlistgoback = (ImageView)findViewById(R.id.customerlistgoback);
        customerlogout = (ImageView)findViewById(R.id.customerlogout);
        listtxtroute = (TextView)findViewById(R.id.listtxtroute);
        listtxtarea = (TextView)findViewById(R.id.listtxtarea);
        totalcustomers = (TextView)findViewById(R.id.totalcustomers);

        //Set current route
        if(!String.valueOf(MenuActivity.getroutenametamil).equals("")
                && !String.valueOf(MenuActivity.getroutenametamil).equals("null")
                && !String.valueOf(MenuActivity.getroutenametamil).equals(null)) {
            listtxtroute.setText(String.valueOf(MenuActivity.getroutenametamil));
        }else{
            listtxtroute.setText(String.valueOf(MenuActivity.getroutenametamil));
        }
        getlistroutecode = MenuActivity.getroutecode;


        if(MenuActivity.getroutecode.equals("0")){
            getlistroutecode = "0";
            listtxtroute.setText("");
            listtxtroute.setHint("All Routes");
        }

        addcustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")
                        && !lunch_start_time.equals("1900-01-01 00:00:00") && ( lunch_end_time.equals("") ||
                        lunch_end_time.equals(" ")  || lunch_end_time.equals("null") || lunch_end_time.equals("1900-01-01 00:00:00") ) ){
                    Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.lunchstarted), Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }else {
                    GetCustomerPopup();
                }
            }
        });


        //Get Current date
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            LoginActivity.getformatdate = objdatabaseadapter.GenCreatedDate();
            LoginActivity.getcurrentdatetime = objdatabaseadapter.GenCurrentCreatedDate();
            Cur = objdatabaseadapter.GetScheduleListDB(LoginActivity.getformatdate );
            if(Cur.getCount()>0) {
                for (int i = 0; i < Cur.getCount(); i++) {
                    lunch_start_time = Cur.getString(11);
                    lunch_end_time = Cur.getString(12);
                }
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
        //Logout process
        customerlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HomeActivity.logoutprocess = "True";
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
        //Goback process
        customerlistgoback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack(null);
            }
        });

        //Swipe menu editior functionality
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "open" item
                SwipeMenuItem openItem = new SwipeMenuItem(
                        getApplicationContext());
                //  openItem.setBackground(ContextCompat.getDrawable(context,R.drawable.noborder));
                openItem.setWidth(130);
                openItem.setIcon(R.drawable.ic_mode_edit);
                menu.addMenuItem(openItem);
            }
        };
        listView.setMenuCreator(creator);



        //Click swipemenu action ...delete expense
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        ArrayList<CustomerDetails> currentListDatareview = getdata;
                        listcustomercode = currentListDatareview.get(position).getCustomercode();
                        listcustomername = currentListDatareview.get(position).getCustomername();
                        listcustomernametamil = currentListDatareview.get(position).getCustomernametamil();
                        listaddress = currentListDatareview.get(position).getAddress();
                        listareacode = currentListDatareview.get(position).getAreacode();
                        listmobileno = currentListDatareview.get(position).getMobileno();
                        listtelephoneno = currentListDatareview.get(position).getTelephoneno();
                        listgstin = currentListDatareview.get(position).getGstin();
                        listareaname = currentListDatareview.get(position).getAreaname();
                        listcitycode = currentListDatareview.get(position).getCitycode();
                        listcityname = currentListDatareview.get(position).getCityname();
                        listemailid = currentListDatareview.get(position).getEmailid();
                        listaadharino = currentListDatareview.get(position).getAadharno();

                        GetCustomerUpdatePopup();
                    break;

                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });

        //Get Customer List
        GetCustomerList();

        //Click route dropdown
        listtxtroute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataBaseAdapter objdatabaseadapter = null;
                try {
                    //Order item details
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    String getcustomerroute = objdatabaseadapter.GetCustomerStatusDB();
                    if(getcustomerroute.equals("yes")) {
                        GetRouteList();
                    }
                } catch (Exception e) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }


            }
        });

        //Click area dropdown
        listtxtarea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetListArea(getlistroutecode);
            }
        });
    }

    //cHECK GSTIN FORMAT
    private static boolean validGSTIN(String gstin) throws Exception {
        boolean isValidFormat = false;
        if (checkPattern(gstin, GSTINFORMAT_REGEX)) {
            isValidFormat = verifyCheckDigit(gstin);
        }
        return isValidFormat;

    }
    private static boolean verifyCheckDigit(String gstinWCheckDigit) throws Exception {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));

        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        }
        return isCDValid;
    }
    public static boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }
    public static String getGSTINWithCheckDigit(String gstinWOCheckDigit) throws Exception {
        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        try {
            if (gstinWOCheckDigit == null) {
                throw new Exception("GSTIN supplied for checkdigit calculation is null");
            }
            cpChars = GSTN_CODEPOINT_CHARS.toCharArray();
            inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

            int mod = cpChars.length;
            for (int i = inputChars.length - 1; i >= 0; i--) {
                int codePoint = -1;
                for (int j = 0; j < cpChars.length; j++) {
                    if (cpChars[j] == inputChars[i]) {
                        codePoint = j;
                    }
                }
                int digit = factor * codePoint;
                factor = (factor == 2) ? 1 : 2;
                digit = (digit / mod) + (digit % mod);
                sum += digit;
            }
            checkCodePoint = (mod - (sum % mod)) % mod;
            return gstinWOCheckDigit + cpChars[checkCodePoint];
        } finally {
            inputChars = null;
            cpChars = null;
        }
    }

    //Customer Popup

    public void GetCustomerPopup(){
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.addcustomer);
        ImageView closepopup = (ImageView) dialog.findViewById(R.id.closepopup);
        txtcustomername = (TextView)dialog.findViewById(R.id.txtcustomername) ;
        txtcustomernametamil = (TextView)dialog.findViewById(R.id.txtcustomernametamil) ;
        txtaddress = (TextView)dialog.findViewById(R.id.txtaddress) ;
        txtcityname = (TextView)dialog.findViewById(R.id.txtcityname) ;
        txtarea = (TextView)dialog.findViewById(R.id.txtarea) ;
        txtphoneno = (TextView)dialog.findViewById(R.id.txtphoneno) ;
        txtlandlineno = (TextView)dialog.findViewById(R.id.txtlandlineno) ;
        txtemailid = (TextView)dialog.findViewById(R.id.txtemailid) ;
        txtgstin = (TextView)dialog.findViewById(R.id.txtgstin) ;
        txtadhar = (TextView)dialog.findViewById(R.id.txtadhar) ;
        btnSaveCustomer = (Button)dialog.findViewById(R.id.btnSaveCustomer);

        btnSaveCustomer.setEnabled(true);
        btnSaveCustomer.setText("Save");


        txtcityname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetCity(MenuActivity.getroutecode);
            }
        });
        txtarea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetArea(getcitycode);
            }
        });
        btnSaveCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getcustomername = txtcustomername.getText().toString();
                String getcustomernametamil = txtcustomernametamil.getText().toString();
                String getaddress = txtaddress.getText().toString();
                String getcityname = txtcityname.getText().toString();
                String getarea = txtarea.getText().toString();
                String getphoneno = txtphoneno.getText().toString();
                String getlandlineno = txtlandlineno.getText().toString();
                String getemailid = txtemailid.getText().toString();
                String getgstin = txtgstin.getText().toString();
                String getaadharno = txtadhar.getText().toString();

                if(getcustomername.equals("") || getcustomername.equals("null")
                        || getcustomername.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter customer name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();

                   // Toast.makeText(getApplicationContext(),"Please enter customer name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(getcityname.equals("") || getcityname.equals("null")
                        || getcityname.equals(null) || getcitycode.equals("")|| getcitycode.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select city name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select city name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(getarea.equals("") || getarea.equals("null")
                        || getarea.equals(null) || getareacode.equals("")|| getareacode.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select area name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select area name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if((getphoneno.equals("") || getphoneno.equals("null")
                        || getphoneno.equals(null)) && (getgstin.equals("") || getgstin.equals("null")
                        || getgstin.equals(null)) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter Mobile No. or GSTIN", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Please enter Mobile No. or GSTIN", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(!getphoneno.equals("") && !getphoneno.equals("null")
                        && !getphoneno.equals(null) ) {
                    if (getphoneno.length() < 10) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Mobile No. should contain 10 digits", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Mobile No. should contain 10 digits", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                if(!getgstin.equals("") && !getgstin.equals("null")
                        && !getgstin.equals(null) ) {
                    if (getgstin.length() > 0) {
                        try {
                            if (!validGSTIN(getgstin)) {
                                Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid GSTIN", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                               // Toast.makeText(getApplicationContext(), "Please enter valid GSTIN", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                if(!getaadharno.equals("") && !getaadharno.equals("null")
                        && !getaadharno.equals(null) ) {
                    if (getaadharno.length() <12) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Aadhar No. should contain 12 digits", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Aadhar No. should contain 16 digits", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                if(!getemailid.equals("") && !getemailid.equals("null")
                        && !getemailid.equals(null) ) {
                    if (!getemailid.matches(emailPattern) && getemailid.length() > 0) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid email ID", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                       // Toast.makeText(getApplicationContext(), "Please enter valid email ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }



                btnSaveCustomer.setEnabled(false);
                DataBaseAdapter objdatabaseadapter = null;
                try {
                    if(getcustomernametamil.equals("")||getcustomernametamil.equals(null)
                            || getcustomernametamil.equals("null")){
                        getcustomernametamil = getcustomername;
                    }
                    //Order item details
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    String getresult="";
                    String getretailercount = objdatabaseadapter.CheckCustomerAlreadyExistsCount(getareacode,getcustomername);
                    if(getretailercount.equals("Success")) {
                        getresult = objdatabaseadapter.InsertCustomerDetails(getcustomername, getcustomernametamil,
                                getaddress, getareacode, getemailid, getphoneno, getlandlineno, getaadharno, getgstin);
                        if (!getresult.equals("")) {
                            Toast toast = Toast.makeText(getApplicationContext(),"Saved Successfully", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();

                            //Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            btnSaveCustomer.setEnabled(true);
                            GetCustomerList();
                        }
                    }else{
                        btnSaveCustomer.setEnabled(true);
                        Toast toast = Toast.makeText(getApplicationContext(),"Customer name already exists", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(context, "Customer name already exists", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    networkstate = isNetworkAvailable();
                    if (networkstate == true) {
                        new AsyncCustomerDetails().execute();
                    }

                } catch (Exception e) {
                    btnSaveCustomer.setEnabled(true);
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }

            }
        });

        closepopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void GetCustomerUpdatePopup(){
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.addcustomer);
        ImageView closepopup = (ImageView) dialog.findViewById(R.id.closepopup);
        txtcustomername = (TextView)dialog.findViewById(R.id.txtcustomername) ;
        txtcustomernametamil = (TextView)dialog.findViewById(R.id.txtcustomernametamil) ;
        txtaddress = (TextView)dialog.findViewById(R.id.txtaddress) ;
        txtcityname = (TextView)dialog.findViewById(R.id.txtcityname) ;
        txtarea = (TextView)dialog.findViewById(R.id.txtarea) ;
        txtphoneno = (TextView)dialog.findViewById(R.id.txtphoneno) ;
        txtlandlineno = (TextView)dialog.findViewById(R.id.txtlandlineno) ;
        txtemailid = (TextView)dialog.findViewById(R.id.txtemailid) ;
        txtgstin = (TextView)dialog.findViewById(R.id.txtgstin) ;
        txtadhar = (TextView)dialog.findViewById(R.id.txtadhar) ;
        btnSaveCustomer = (Button)dialog.findViewById(R.id.btnSaveCustomer);

        btnSaveCustomer.setEnabled(true);

        txtcustomername.setEnabled(false);
        txtcustomernametamil.setEnabled(false);
        txtaddress.setEnabled(false);
        txtcityname.setEnabled(false);
        txtarea.setEnabled(false);
        txtcustomername.setBackgroundResource(R.drawable.editbackgroundgray);
        txtcustomernametamil.setBackgroundResource(R.drawable.editbackgroundgray);
        txtaddress.setBackgroundResource(R.drawable.editbackgroundgray);
        txtcityname.setBackgroundResource(R.drawable.editbackgroundgray);
        txtarea.setBackgroundResource(R.drawable.editbackgroundgray);

        txtphoneno.setEnabled(true);
        txtlandlineno.setEnabled(true);
        txtemailid.setEnabled(true);
        txtgstin.setEnabled(true);
        txtadhar.setEnabled(true);

        //Set Text
        txtcustomername.setText(listcustomername);
        txtcustomernametamil.setText(listcustomernametamil);
        txtaddress.setText(listaddress);
        txtcityname.setText(listcityname);
        txtarea.setText(listareaname);
        txtphoneno.setText(listmobileno);
        txtlandlineno.setText(listtelephoneno);
        txtemailid.setText(listemailid);
        txtgstin.setText(listgstin);
        txtadhar.setText(listaadharino);
        btnSaveCustomer.setText("Update");

        btnSaveCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getcustomername = txtcustomername.getText().toString();
                String getcustomernametamil = txtcustomernametamil.getText().toString();
                String getaddress = txtaddress.getText().toString();
                String getcityname = txtcityname.getText().toString();
                String getarea = txtarea.getText().toString();
                String getphoneno = txtphoneno.getText().toString();
                String getlandlineno = txtlandlineno.getText().toString();
                String getemailid = txtemailid.getText().toString();
                String getgstin = txtgstin.getText().toString();
                String getaadharno = txtadhar.getText().toString();


                if(getcustomername.equals("") || getcustomername.equals("null")
                        || getcustomername.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter customer name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();

                    // Toast.makeText(getApplicationContext(),"Please enter customer name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(getcityname.equals("") || getcityname.equals("null")
                        || getcityname.equals(null) || getcitycode.equals("")|| getcitycode.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select city name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select city name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(getarea.equals("") || getarea.equals("null")
                        || getarea.equals(null) || getareacode.equals("")|| getareacode.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select area name", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select area name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if((getphoneno.equals("") || getphoneno.equals("null")
                        || getphoneno.equals(null)) && (getgstin.equals("") || getgstin.equals("null")
                        || getgstin.equals(null)) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter Mobile No. or GSTIN", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Please enter Mobile No. or GSTIN", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(!getphoneno.equals("") && !getphoneno.equals("null")
                        && !getphoneno.equals(null) ) {
                    if (getphoneno.length() < 10) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Mobile No. should contain 10 digits", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Mobile No. should contain 10 digits", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                if(!getgstin.equals("") && !getgstin.equals("null")
                        && !getgstin.equals(null) ) {
                    if (getgstin.length() > 0) {
                        try {
                            if (!validGSTIN(getgstin)) {
                                Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid GSTIN", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                // Toast.makeText(getApplicationContext(), "Please enter valid GSTIN", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                if(!getaadharno.equals("") && !getaadharno.equals("null")
                        && !getaadharno.equals(null) ) {
                    if (getaadharno.length() <12) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Aadhar No. should contain 12 digits", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        return;
                    }
                }

                if(!getemailid.equals("") && !getemailid.equals("null")
                        && !getemailid.equals(null) ) {
                    if (!getemailid.matches(emailPattern) && getemailid.length() > 0) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid email ID", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        // Toast.makeText(getApplicationContext(), "Please enter valid email ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }


                btnSaveCustomer.setEnabled(false);
                DataBaseAdapter objdatabaseadapter = null;
                try {
                    if(getcustomernametamil.equals("")||getcustomernametamil.equals(null)
                            || getcustomernametamil.equals("null")){
                        getcustomernametamil = getcustomername;
                    }
                    //Order item details
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    String getresult="";
                    getresult = objdatabaseadapter.UpdateCustomerDetails(getcustomername, getcustomernametamil,
                            getaddress, getareacode, getemailid, getphoneno, getlandlineno, getaadharno, getgstin,listcustomercode);
                    if (getresult.equals("success")) {
                        Toast toast = Toast.makeText(getApplicationContext(),"Updated Successfully", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Updated Successfully", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        btnSaveCustomer.setEnabled(true);
                        GetCustomerList();
                    }
                    networkstate = isNetworkAvailable();
                    if (networkstate == true) {
                        new AsyncCustomerDetails().execute();
                    }

                } catch (Exception e) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }

            }
        });

        closepopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    //Get Customer List
    public void GetCustomerList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            customerlist.clear();
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCustomerListDB(getlistroutecode,getlistareacode);
            totalcustomers.setText(String.valueOf(Cur.getCount()));
            if(Cur.getCount()>0) {
                for(int i=0;i<Cur.getCount();i++){
                    customerlist.add(new CustomerDetails(Cur.getString(0),Cur.getString(1),
                            Cur.getString(2),Cur.getString(3),Cur.getString(4),
                            Cur.getString(5),Cur.getString(6),Cur.getString(7)
                            ,Cur.getString(8),Cur.getString(9),
                            Cur.getString(10),Cur.getString(11)
                            ,Cur.getString(12),String.valueOf(i+1)));
                    Cur.moveToNext();
                }
                getdata = customerlist;
                adapter =  new CustomerListBaseAdapter(context, customerlist);
                listView.setAdapter(adapter);
            }else{
                adapter = new CustomerListBaseAdapter(context, customerlist);
                listView.setAdapter(adapter);
                Toast toast = Toast.makeText(getApplicationContext(),"No Customer Available", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Customer Available",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("SalesList", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }

    }

    //Checking internet connection
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }
    //*************Drop Down Functionality*********/
    //Get City name
    public  void GetCity(String routecode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCityDB(routecode);
            if(Cur.getCount()>0) {
                citycode = new String[Cur.getCount()];
                cityname = new String[Cur.getCount()];
                citynametamil = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    citycode[i] = Cur.getString(0);
                    cityname[i] = Cur.getString(1);
                    citynametamil[i] = Cur.getString(2);
                    Cur.moveToNext();
                }

                citydialog = new Dialog(context);
                citydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                citydialog.setContentView(R.layout.citypopup);
                lv_CityList = (ListView) citydialog.findViewById(R.id.lv_CityList);
                ImageView close = (ImageView) citydialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        citydialog.dismiss();
                    }
                });
                CityAdapter adapter = new CityAdapter(context);
                lv_CityList.setAdapter(adapter);
                citydialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No city in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No city in this route",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    public  void GetListArea(String routecode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCustomerListAreaDB(routecode);
            if(Cur.getCount()>0) {
                AreaCode = new String[Cur.getCount()];
                AreaName = new String[Cur.getCount()];
                AreaNameTamil = new String[Cur.getCount()];
                NoOfKm = new String[Cur.getCount()];
                CityCode = new String[Cur.getCount()];
                CityName = new String[Cur.getCount()];
                CustomerCount = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    AreaCode[i] = Cur.getString(0);
                    AreaName[i] = Cur.getString(1);
                    AreaNameTamil[i] = Cur.getString(2);
                    NoOfKm[i] = Cur.getString(3);
                    CityCode[i] = Cur.getString(4);
                    CityName[i] = Cur.getString(5);
                    CustomerCount[i] = Cur.getString(6);
                    Cur.moveToNext();
                }

                areadialog = new Dialog(context);
                areadialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                areadialog.setContentView(R.layout.areapopup);
                lv_ListAreaList = (ListView) areadialog.findViewById(R.id.lv_AreaList);
                ImageView close = (ImageView) areadialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        areadialog.dismiss();
                    }
                });
                AreaListAdapter adapter = new AreaListAdapter(context);
                lv_ListAreaList.setAdapter(adapter);
                areadialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Area in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Area in this route",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    //Get Route List
    public void GetRouteList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            customerlist.clear();
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetRouteListDB();
            if(Cur.getCount()>0) {
                routecode = new String[Cur.getCount()];
                routename = new String[Cur.getCount()];
                routenametamil = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    routecode[i] = Cur.getString(0);
                    routename[i] = Cur.getString(1);
                    routenametamil[i] = Cur.getString(2);
                    Cur.moveToNext();
                }
                routedialog = new Dialog(context);
                routedialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                routedialog.setContentView(R.layout.routepopup);
                lv_Routelist = (ListView) routedialog.findViewById(R.id.lv_Routelist);
                ImageView close = (ImageView) routedialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        routedialog.dismiss();
                    }
                });
                RouteAdapter adapter = new RouteAdapter(context);
                lv_Routelist.setAdapter(adapter);
                routedialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Route Available", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Route Available",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("SalesList", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }

    }


    //Get Area name
    public  void GetArea(String citycode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetAreaCityDB(citycode,MenuActivity.getroutecode);
            if(Cur.getCount()>0) {
                areacode = new String[Cur.getCount()];
                areaname = new String[Cur.getCount()];
                areanametamil = new String[Cur.getCount()];
                customercount = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    areacode[i] = Cur.getString(0);
                    areaname[i] = Cur.getString(1);
                    areanametamil[i] = Cur.getString(2);
                    customercount[i] = Cur.getString(6);
                    Cur.moveToNext();
                }

                areadialog = new Dialog(context);
                areadialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                areadialog.setContentView(R.layout.areapopup);
                lv_AreaList = (ListView) areadialog.findViewById(R.id.lv_AreaList);
                ImageView close = (ImageView) areadialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        areadialog.dismiss();
                    }
                });
                AreaAdapter adapter = new AreaAdapter(context);
                lv_AreaList.setAdapter(adapter);
                areadialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Area in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Area in this route",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    //*************END Drop Down Functionality*********/

    /******Base Adapter***********/
    //City Adapter
    public class CityAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        CityAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return citycode.length;
        }

        @Override
        public Object getItem(int position) {
            return citycode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.citypopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listcityname = (TextView) convertView.findViewById(R.id.listcityname);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(String.valueOf(citynametamil[position]).equals("") || String.valueOf(citynametamil[position]).equals("null") ||
                        String.valueOf(citynametamil[position]).equals(null)) {
                    mHolder.listcityname.setText(String.valueOf(cityname[position]));
                }else{
                    mHolder.listcityname.setText(String.valueOf(citynametamil[position]));
                }
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(String.valueOf(citynametamil[position]).equals("") || String.valueOf(citynametamil[position]).equals("null") ||
                            String.valueOf(citynametamil[position]).equals(null)) {
                        txtcityname.setText(String.valueOf(cityname[position]));
                    }else{
                        txtcityname.setText(String.valueOf(citynametamil[position]));
                    }
                    getcitycode = citycode[position];
                    txtarea.setText("");
                    getareacode="0";
                    txtarea.setHint("Area");
                    citydialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listcityname;

        }

    }


    //Area Adapter
    public class AreaAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        AreaAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return areacode.length;
        }

        @Override
        public Object getItem(int position) {
            return areacode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.areapopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listareaname = (TextView) convertView.findViewById(R.id.listareaname);
                    mHolder.listcustomercount = (TextView)convertView.findViewById(R.id.listcustomercount);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
               /* if(!String.valueOf(areanametamil[position]).equals("")
                        && !String.valueOf(areanametamil[position]).equals("null")
                        && !String.valueOf(areanametamil[position]).equals(null)) {*/
                    mHolder.listareaname.setText(String.valueOf(areanametamil[position]));
               /* }else{
                    mHolder.listareaname.setText(String.valueOf(areaname[position]));
                }*/
                mHolder.listcustomercount.setText(String.valueOf(customercount[position]));


                int getcount = 0;
                for(int i = 0;i<areacode.length;i++){
                    if(!areacode[i].equals("0")){
                        getcount = getcount + Integer.parseInt(customercount[i]);
                    }
                }

                if(areacode[position].equals("0")){
                    mHolder.listcustomercount.setText(String.valueOf(getcount));
                }
                mHolder.listcustomercount.setTag(position);
                mHolder.listareaname.setTag(position);
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                  /*  if(!String.valueOf(areanametamil[position]).equals("")
                            && !String.valueOf(areanametamil[position]).equals("null")
                            && !String.valueOf(areanametamil[position]).equals(null)) {*/
                        txtarea.setText(String.valueOf(areanametamil[position]));
                   /* }else{
                        txtarea.setText(String.valueOf(areaname[position]));
                    }*/
                    getareacode = areacode[position];
                    areadialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listareaname,listcustomercount;

        }

    }

    //Route Adapter
    public class RouteAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        RouteAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return routecode.length;
        }

        @Override
        public Object getItem(int position) {
            return routecode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.routepopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listroutename = (TextView) convertView.findViewById(R.id.listroutename);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(!String.valueOf(routenametamil[position]).equals("")
                        && !String.valueOf(routenametamil[position]).equals("null")
                        && !String.valueOf(routenametamil[position]).equals(null)) {
                    mHolder.listroutename.setText(String.valueOf(routenametamil[position]));
                }else{
                    mHolder.listroutename.setText(String.valueOf(routename[position]));
                }
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!String.valueOf(routenametamil[position]).equals("")
                            && !String.valueOf(routenametamil[position]).equals("null")
                            && !String.valueOf(routenametamil[position]).equals(null)) {
                        listtxtroute.setText(String.valueOf(routenametamil[position]));
                    }else{
                        listtxtroute.setText(String.valueOf(routename[position]));
                    }
                    getlistroutecode = routecode[position];
                    listtxtarea.setText("");
                    getlistareacode ="0";
                    listtxtarea.setHint("All Areas");
                    routedialog.dismiss();
                    GetCustomerList();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listroutename;
        }
    }


    //Area Adapter
    public class AreaListAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        AreaListAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return AreaCode.length;
        }

        @Override
        public Object getItem(int position) {
            return AreaCode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.areapopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listareaname = (TextView) convertView.findViewById(R.id.listareaname);
                    mHolder.listcustomercount = (TextView)convertView.findViewById(R.id.listcustomercount);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(CityName[position].equals("")){
                    mHolder.listareaname.setText(String.valueOf(AreaName[position] ));
                }else {
                    mHolder.listareaname.setText(String.valueOf(AreaName[position] + " - " + CityName[position]));
                }
                mHolder.listcustomercount.setText(String.valueOf(CustomerCount[position]));

                int getcount = 0;
                for(int i = 0;i<AreaCode.length;i++){
                    if(!AreaCode[i].equals("0")){
                        getcount = getcount + Integer.parseInt(CustomerCount[i]);
                    }
                }

                if(AreaCode[position].equals("0")){
                    mHolder.listcustomercount.setText(String.valueOf(getcount));
                }

                mHolder.listcustomercount.setTag(position);
                mHolder.listareaname.setTag(position);
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(CityName[position].equals("")){
                        listtxtarea.setText(String.valueOf(AreaName[position]));
                    }else {
                        listtxtarea.setText(String.valueOf(AreaName[position] + " - " + CityName[position]));
                    }
                    getlistareacode =AreaCode[position];
                    areadialog.dismiss();
                    GetCustomerList();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listareaname,listcustomercount;

        }

    }

    /**********END Base Adapter*********/

    /**********Asynchronous Claass***************/

    protected  class AsyncCustomerDetails extends
            AsyncTask<String, JSONObject, ArrayList<CustomerDatas>> {
        ArrayList<CustomerDatas> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<CustomerDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetCustomerDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("customercode", mCur2.getString(1));
                        obj.put("refno", mCur2.getString(2));
                        obj.put("customername", mCur2.getString(3));
                        obj.put("customernametamil", mCur2.getString(4));
                        obj.put("address", mCur2.getString(5));
                        obj.put("areacode", mCur2.getString(6));
                        obj.put("emailid", mCur2.getString(7));
                        obj.put("mobileno", mCur2.getString(8));
                        obj.put("telephoneno", mCur2.getString(9));
                        obj.put("aadharno", mCur2.getString(10));
                        obj.put("gstin", mCur2.getString(11));
                        obj.put("status", mCur2.getString(12));
                        obj.put("makerid", mCur2.getString(13));
                        obj.put("createddate", mCur2.getString(14));
                        obj.put("updateddate", mCur2.getString(15));
                        obj.put("latitude", mCur2.getString(16));
                        obj.put("longitude", mCur2.getString(17));
                        obj.put("flag", mCur2.getString(18));
                        obj.put("schemeapplicable", mCur2.getString(19));
                        obj.put("uploaddocument", mCur2.getString(20));
                        obj.put("business_type", mCur2.getString(23));

                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.CustomerDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseCustomerDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("Customer", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<CustomerDatas> result) {
            // TODO Auto-generated method stub
            try {
                if (result.size() >= 1) {
                    if (result.get(0).CustomerCode.length > 0) {
                        for (int j = 0; j < result.get(0).CustomerCode.length; j++) {
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCustomerFlag(result.get(0).CustomerCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }

        }
    }

    /**********END Asynchronous Claass***************/

    public void goBack(View v) {
        LoginActivity.ismenuopen=true;
        Intent i = new Intent(context, MenuActivity.class);
        startActivity(i);
    }
    @Override
    public void onBackPressed() {
        goBack(null);
    }

}
