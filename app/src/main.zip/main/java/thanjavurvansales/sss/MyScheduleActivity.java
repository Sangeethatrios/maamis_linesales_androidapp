package thanjavurvansales.sss;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jeevandeshmukh.glidetoastlib.GlideToast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class MyScheduleActivity extends AppCompatActivity   {
    public Context context;
    TextView txtscheduledate,txtschedulevanname,txtschedulevehiclename,txtscheduleroutename,txtschedulesalesrepname,
            txtscheduletripadvance,txtscheduledrivername,txtschedulehelpername,txtschedulestartingkm,
            txtscheduleendingkm;
    private int year, month, day;
    private Calendar calendar;
    ImageButton goback ,logout;
    String getschdeuleformatdate="";
    LinearLayout LLvehicledoc;
    private static final int WRITE_REQUEST_CODE = 300;
    private static final String TAG = MyScheduleActivity.class.getSimpleName();
    private String url;
    DecimalFormat df = new DecimalFormat("0.00");
    private static final int PERMISSION_STROAGE_CODE = 1000;
    // Progress Dialog
    private ProgressDialog pDialog;
    public static final int progress_bar_type = 0;
    //Button declare
    TextView btn_lunch_start_time,btn_lunch_end_time,txtschedulelunctime;
    LinearLayout LLlunctime,LLEndingkm;
    String getschedulecode="";
    String lunch_start_time = "";
    String lunch_end_time = "";
    boolean networkstate = false;
    ImageButton btn_cashnotpaiddetails;
    public static String ifopenfromschedule="";

    // File url to download
    private static String file_url = "https://api.androidhive.info/progressdialog/hive.jpg";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_schedule);

        context =this;

        //Declare all variables
        txtscheduledate = (TextView)findViewById(R.id.txtscheduledate);
        txtschedulevanname = (TextView)findViewById(R.id.txtschedulevanname);
        txtschedulevehiclename = (TextView)findViewById(R.id.txtschedulevehiclename);
        txtscheduleroutename = (TextView)findViewById(R.id.txtscheduleroutename);
        txtschedulesalesrepname = (TextView)findViewById(R.id.txtschedulesalesrepname);
        txtscheduletripadvance = (TextView)findViewById(R.id.txtscheduletripadvance);
        txtscheduledrivername = (TextView)findViewById(R.id.txtscheduledrivername);
        txtschedulehelpername = (TextView)findViewById(R.id.txtschedulehelpername);
        txtschedulestartingkm = (TextView)findViewById(R.id.txtschedulestartingkm);
        txtscheduleendingkm = (TextView)findViewById(R.id.txtscheduleendingkm);
        LLvehicledoc  = (LinearLayout) findViewById(R.id.LLvehicledoc);
        goback = (ImageButton)findViewById(R.id.goback);
        logout = (ImageButton)findViewById(R.id.logout);
        btn_lunch_start_time = (TextView)findViewById(R.id.btn_launch_start_time);
        btn_lunch_end_time = (TextView)findViewById(R.id.btn_launch_end_time);
        txtschedulelunctime = (TextView)findViewById(R.id.txtschedulelunctime);
        LLlunctime = (LinearLayout)findViewById(R.id.LLlunctime);
        LLEndingkm = (LinearLayout)findViewById(R.id.LLEndingkm);
        btn_cashnotpaiddetails = (ImageButton)findViewById(R.id.btn_cashnotpaiddetails);

        //Get Current date
        DataBaseAdapter objdatabaseadapter = null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            LoginActivity.getformatdate = objdatabaseadapter.GenCreatedDate();
            LoginActivity.getcurrentdatetime = objdatabaseadapter.GenCurrentCreatedDate();
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (objdatabaseadapter != null)
                objdatabaseadapter.close();
        }

        //Set Now Date
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        //Set Current date
        txtscheduledate.setText(LoginActivity.getcurrentdatetime);
        getschdeuleformatdate = LoginActivity.getformatdate;

        //Download vehicle document
        LLvehicledoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Check if SD card is present or not
             //   new DownloadFileFromURL().execute(file_url);
             if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ){
                 if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                         PackageManager.PERMISSION_DENIED){
                     String[] permisssions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                     requestPermissions(permisssions,PERMISSION_STROAGE_CODE);
                 }else{
                     new DownloadFileFromURL().execute();
                 }
             }else{
                 new DownloadFileFromURL().execute();
             }
            }
        });
        //Schedule date
        txtscheduledate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String vardate = "";
                        String getmonth="";
                        String getdate="";
                        monthOfYear = monthOfYear + 1;
                        if (dayOfMonth < 10) {
                            vardate = "0" + dayOfMonth;
                            getdate = "0" + dayOfMonth;
                        } else {
                            vardate = String.valueOf(dayOfMonth);
                            getdate = String.valueOf(dayOfMonth);
                        }
                        if (monthOfYear < 10) {
                            vardate = vardate + "-" + "0" + monthOfYear;
                            getmonth = "0" + monthOfYear;;
                        } else {
                            vardate = vardate +"-" + monthOfYear;
                            getmonth = String.valueOf(monthOfYear);;
                        }
                        vardate = vardate + "-" + year;
                        getschdeuleformatdate = year+ "-"+getmonth+"-"+getdate;
                        txtscheduledate.setText(vardate );
                        //Call schedule List
                        GetScheduleList();

                    }
                };
                DatePickerDialog dpDialog = new DatePickerDialog(context, listener, year, month, day);
                dpDialog.show();
            }
        });

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack(null);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HomeActivity.logoutprocess = "True";
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        //Click start time
        btn_lunch_start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                starttime_action();
            }
        });

        //Click end time
        btn_lunch_end_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                endtime_action();
            }
        });
        //Call schedule List
        GetScheduleList();

        //click not paid cash details
        btn_cashnotpaiddetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ifopenfromschedule="yes";
                Intent i = new Intent(context,ReviewCashNotpaidDetails.class);
                startActivity(i);
            }
        });
    }

    //Start time action
    public  void starttime_action(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to start lunch ?");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                DataBaseAdapter objdatabaseadapter = null;
                                try {
                                    //Order item details
                                    objdatabaseadapter = new DataBaseAdapter(context);
                                    objdatabaseadapter.open();
                                    String getresult="";
                                    if(!getschedulecode.equals("")) {
                                        getresult = objdatabaseadapter.InsertLaunchtime(getschedulecode);
                                        if (getresult.equals("success")) {
                                            Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.lunchsavestartmsg), Toast.LENGTH_LONG);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.show();

                                            Cursor Cur = objdatabaseadapter.GetScheduleListDB(getschdeuleformatdate);
                                            if (Cur.getCount() > 0) {
                                                for (int i = 0; i < Cur.getCount(); i++) {
                                                    lunch_start_time = Cur.getString(11);
                                                    lunch_end_time = Cur.getString(12);
                                                }
                                            }
                                            Cur.close();

                                            btn_lunch_start_time.setBackgroundColor(getResources().getColor(R.color.gray));
                                            btn_lunch_start_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                                            btn_lunch_end_time.setBackgroundColor(getResources().getColor(R.color.lunchred));
                                            btn_lunch_end_time.setTextColor(getResources().getColor(R.color.white));

                                            btn_lunch_start_time.setEnabled(false);
                                            btn_lunch_end_time.setEnabled(true);

                                            LLlunctime.setVisibility(View.VISIBLE);

                                            String output[] = lunch_start_time.split(" ");

                                            String s = output[1].toString();
                                            DateFormat f1 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                                            Date d = f1.parse(s);
                                            DateFormat f2 = new SimpleDateFormat("hh:mm a");

                                            txtschedulelunctime.setText(f2.format(d).toUpperCase());


                                            networkstate = isNetworkAvailable();
                                            if (networkstate == true) {
                                                new AsyncScheduleDetails().execute();
                                            }
                                        }
                                    }else{
                                        Toast toast = Toast.makeText(getApplicationContext(),"Don't have schedule details", Toast.LENGTH_LONG);
                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                        toast.show();
                                        return;
                                    }
                                } catch (Exception e) {
                                    Toast toast = Toast.makeText(getApplicationContext(),"Error in saving", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                    mDbErrHelper.open();
                                    String geterrror = e.toString();
                                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                    mDbErrHelper.close();
                                } finally {
                                    if(objdatabaseadapter!=null)
                                        objdatabaseadapter.close();
                                }
                            }
                        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    //Checking internet connection
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }


    //end time action
    public  void endtime_action(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to end lunch? ");
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        DataBaseAdapter objdatabaseadapter = null;
                        try {
                            //Order item details
                            objdatabaseadapter = new DataBaseAdapter(context);
                            objdatabaseadapter.open();
                            String getresult = "";
                            if(!getschedulecode.equals("")) {
                            getresult = objdatabaseadapter.InsertLaunchEndtime(getschedulecode);
                            if (getresult.equals("success")) {
                                Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.lunchsaveendmsg), Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();

                                Cursor Cur = objdatabaseadapter.GetScheduleListDB(getschdeuleformatdate);
                                if (Cur.getCount() > 0) {
                                    for (int i = 0; i < Cur.getCount(); i++) {
                                        lunch_start_time = Cur.getString(11);
                                        lunch_end_time = Cur.getString(12);
                                    }
                                }
                                Cur.close();

                                btn_lunch_end_time.setBackgroundColor(getResources().getColor(R.color.gray));
                                btn_lunch_end_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                                btn_lunch_start_time.setBackgroundColor(getResources().getColor(R.color.gray));
                                btn_lunch_start_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                                btn_lunch_start_time.setEnabled(false);
                                btn_lunch_end_time.setEnabled(false);

                                LLlunctime.setVisibility(View.VISIBLE);
                                String output[] = lunch_start_time.split(" ");
                                String output1[] = lunch_end_time.split(" ");


                                String s = output[1].toString();
                                DateFormat f1 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                                Date d = f1.parse(s);
                                DateFormat f2 = new SimpleDateFormat("hh:mm a");

                                String s1 = output1[1].toString();
                                DateFormat f4 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                                Date d1 = f4.parse(s1);
                                DateFormat f3 = new SimpleDateFormat("hh:mm a");

                                txtschedulelunctime.setText(f2.format(d).toUpperCase() + " to " + f3.format(d1).toUpperCase());


                                networkstate = isNetworkAvailable();
                                if (networkstate == true) {
                                    new AsyncScheduleDetails().execute();
                                }
                            }
                        }else{
                                Toast toast = Toast.makeText(getApplicationContext(),"Don't have schedule details", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                return;
                            }
                        } catch (Exception e) {
                            Toast toast = Toast.makeText(getApplicationContext(),"Error in saving", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        } finally {
                            if(objdatabaseadapter!=null)
                                objdatabaseadapter.close();
                        }
                    }
                });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case  PERMISSION_STROAGE_CODE:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    new DownloadFileFromURL().execute();
                }else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Permission denied...", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Permission denied...",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    //Get Schedule List
    public  void GetScheduleList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetScheduleListDB(getschdeuleformatdate);
            if(Cur.getCount()>0) {
                for(int i=0;i<Cur.getCount();i++){
                    getschedulecode = Cur.getString(0);
                    txtschedulevanname.setText(Cur.getString(2));
                    txtschedulevehiclename.setText(Cur.getString(4));
                    txtscheduleroutename.setText(Cur.getString(3));
                    txtschedulesalesrepname.setText(Cur.getString(5));
                    txtscheduledrivername.setText(Cur.getString(6));
                    String gethelpername = Cur.getString(7);
                    if(gethelpername.equals("") || gethelpername.equals("null") || gethelpername.equals(null)){
                        gethelpername = "NIL";
                    }
                    txtschedulehelpername.setText(gethelpername);
                    String gettripadvance = Cur.getString(8);
                    if(gettripadvance.equals("") || gettripadvance.equals("null") || gettripadvance.equals(null)){
                        gettripadvance = "NIL";
                        txtscheduletripadvance.setText(gettripadvance);
                    }else {
                        txtscheduletripadvance.setText(df.format(Double.parseDouble(gettripadvance)));
                    }
                    if(Cur.getString(4).split(" - ")[1].equals("null")){
                        txtschedulevehiclename.setText(Cur.getString(4).split(" - ")[0]);
                    }
                    String getstartingkm = Cur.getString(9);
                    if(getstartingkm.equals("") || getstartingkm.equals("null") || getstartingkm.equals(null)){
                        getstartingkm = "NIL";
                    }

                    txtschedulestartingkm.setText(getstartingkm+" km");

                    String getendingkm = Cur.getString(10);
                    if(!getendingkm.equals("") && !getendingkm.equals("null") && !getendingkm.equals(null)
                            && !getendingkm.equals("0")){
                        txtscheduleendingkm.setText(getendingkm+" km");
                        LLEndingkm.setVisibility(View.VISIBLE);
                    }else{
                        LLEndingkm.setVisibility(View.GONE);
                    }

                     lunch_start_time = Cur.getString(11);
                     lunch_end_time = Cur.getString(12);


                    if(!lunch_end_time.equals("") && !lunch_end_time.equals(" ")  && !lunch_end_time.equals("null") && !lunch_end_time.equals("1900-01-01 00:00:00")
                            &&!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null")  && !lunch_start_time.equals("1900-01-01 00:00:00")){
                        btn_lunch_end_time.setBackgroundColor(getResources().getColor(R.color.gray));
                        btn_lunch_end_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                        btn_lunch_start_time.setBackgroundColor(getResources().getColor(R.color.gray));
                        btn_lunch_start_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                        btn_lunch_start_time.setEnabled(false);
                        btn_lunch_end_time.setEnabled(false);

                        LLlunctime.setVisibility(View.VISIBLE);
                        String output[] = lunch_start_time.split(" ");
                        String output1[] = lunch_end_time.split(" ");


                        String s = output[1].toString();
                        DateFormat f1 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                        Date d = f1.parse(s);
                        DateFormat f2 = new SimpleDateFormat("hh:mm a");

                        String s1 = output1[1].toString();
                        DateFormat f4 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                        Date d1 = f4.parse(s1);
                        DateFormat f3 = new SimpleDateFormat("hh:mm a");

                        txtschedulelunctime.setText( f2.format(d).toUpperCase() + " to "+ f3.format(d1).toUpperCase() );



                    }else if(!lunch_start_time.equals("") && !lunch_start_time.equals(" ")  && !lunch_start_time.equals("null") && !lunch_start_time.equals("1900-01-01 00:00:00") ){
                        btn_lunch_start_time.setBackgroundColor(getResources().getColor(R.color.gray));
                        btn_lunch_start_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                        btn_lunch_end_time.setBackgroundColor(getResources().getColor(R.color.lunchred));
                        btn_lunch_end_time.setTextColor(getResources().getColor(R.color.white));

                        btn_lunch_start_time.setEnabled(false);
                        btn_lunch_end_time.setEnabled(true);

                        LLlunctime.setVisibility(View.VISIBLE);
                        String output[] = lunch_start_time.split(" ");

                        String s = output[1].toString();
                        DateFormat f1 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
                        Date d = f1.parse(s);
                        DateFormat f2 = new SimpleDateFormat("hh:mm a");
                        txtschedulelunctime.setText( f2.format(d).toUpperCase());

                    }else{
                        btn_lunch_end_time.setBackgroundColor(getResources().getColor(R.color.gray));
                        btn_lunch_end_time.setTextColor(getResources().getColor(R.color.darkgraycolor));

                        btn_lunch_start_time.setBackgroundColor(getResources().getColor(R.color.lunchgreen));
                        btn_lunch_start_time.setTextColor(getResources().getColor(R.color.white));

                        btn_lunch_start_time.setEnabled(true);
                        btn_lunch_end_time.setEnabled(false);
                        LLlunctime.setVisibility(View.GONE);
                        txtschedulelunctime.setText("");
                    }


                }

            }else{
                String nillvalue = "NIL";
                txtschedulevanname.setText(nillvalue);
                txtschedulevehiclename.setText(nillvalue);
                txtscheduleroutename.setText(nillvalue);
                txtschedulesalesrepname.setText(nillvalue);
                txtscheduledrivername.setText(nillvalue);
                txtschedulehelpername.setText(nillvalue);
                txtscheduletripadvance.setText(nillvalue);
                txtschedulestartingkm.setText(nillvalue);
                LLEndingkm.setVisibility(View.GONE);
                Toast toast = Toast.makeText(getApplicationContext(),"No Schedule Available", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
               // Toast.makeText(getApplicationContext(),"No Schedule Available",Toast.LENGTH_SHORT).show();

            }
        }  catch (Exception e){
            Log.i("ScheduleList", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }
    public void goBack(View v) {
        LoginActivity.ismenuopen=true;
        Intent i = new Intent(context, MenuActivity.class);
       /* i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);*/
        startActivity(i);
    }



    /**
     * Showing Dialog
     * */

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case progress_bar_type: // we set this to 0
                pDialog = new ProgressDialog(this);
                pDialog.setMessage("Downloading file. Please wait...");
                pDialog.setIndeterminate(false);
                pDialog.setMax(100);
                pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                pDialog.setCancelable(true);
                pDialog.show();
                return pDialog;
            default:
                return null;
        }
    }

    /**
     * Background Async Task to download file
     * */
    class DownloadFileFromURL extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread
         * Show Progress Bar Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showDialog(progress_bar_type);
        }

        /**
         * Downloading file in background thread
         * */
        @Override
        protected String doInBackground(String... f_url) {
            int count;
            try {
                String url = "http://122.165.65.120:8090/linesales/tn67AA6699.pdf";
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI
                        | DownloadManager.Request.NETWORK_MOBILE);
                request.setTitle("Download");
                request.setDescription("Downloading file...");
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,""+System.currentTimeMillis());

                DownloadManager manager = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
                manager.enqueue(request);


            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
            }

            return null;
        }

        /**
         * Updating progress bar
         * */
        protected void onProgressUpdate(String... progress) {
            // setting progress percentage
            pDialog.setProgress(Integer.parseInt(progress[0]));
        }

        /**
         * After completing background task
         * Dismiss the progress dialog
         * **/
        @Override
        protected void onPostExecute(String file_url) {
            // dismiss the dialog after the file was downloaded
            dismissDialog(progress_bar_type);
            Toast toast = Toast.makeText(getApplicationContext(),"Download Completed ...", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
           // Toast.makeText(getApplicationContext(),"Download Completed ...",Toast.LENGTH_SHORT).show();
        }

    }

    /**********Asynchronous Claass***************/

    protected  class AsyncScheduleDetails extends
            AsyncTask<String, JSONObject, ArrayList<ScheduleDatas>> {
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<ScheduleDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            String result = "";
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetScheduleDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("refno", mCur2.getString(1));
                        obj.put("schedulecode", mCur2.getString(2));
                        obj.put("scheduledate", mCur2.getString(3));
                        obj.put("vancode", mCur2.getString(4));
                        obj.put("routecode", mCur2.getString(5));
                        obj.put("vehiclecode", mCur2.getString(6));
                        obj.put("employeecode", mCur2.getString(7));
                        obj.put("drivercode", mCur2.getString(8));
                        obj.put("helpername", mCur2.getString(9));
                        obj.put("tripadvance", mCur2.getString(10));
                        obj.put("startingkm", mCur2.getString(11));
                        obj.put("endingkm", mCur2.getString(12));
                        obj.put("createddate", mCur2.getString(13));
                        obj.put("updatedate", mCur2.getString(14));
                        obj.put("makerid", mCur2.getString(15));
                        obj.put("lunch_start_time", mCur2.getString(17));
                        obj.put("lunch_end_time", mCur2.getString(18));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.ScheduleDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseScheduleDataList(jsonObj);


                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<ScheduleDatas> result) {
            try{
                // TODO Auto-generated method stub
                if (result.size() >= 1) {
                    if(result.get(0).ScheduleCode.length>0){
                        for(int j=0;j<result.get(0).ScheduleCode.length;j++){
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateScheduleFlag(result.get(0).ScheduleCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }

        }
    }

    @Override
    public void onBackPressed() {
        goBack(null);
    }
}
