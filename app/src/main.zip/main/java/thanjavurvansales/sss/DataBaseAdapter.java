package thanjavurvansales.sss;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import android.bluetooth.BluetoothAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

//import com.instacart.library.truetime.TrueTimeRx;

public class DataBaseAdapter
{
    private final Context mContext;
    public static SQLiteDatabase mDb;
    private DataBaseHelper mDbHelper;
    DecimalFormat dft = new DecimalFormat("0.00");
    public String statusvar = "Active";
    public String getdate="";

    //Common function for database
    public DataBaseAdapter(Context context)
    {
        this.mContext = context;
        mDbHelper = new DataBaseHelper(mContext);
    }

    public DataBaseAdapter createDatabase() throws SQLException
    {
        try
        {
            mDbHelper.createDataBase();
        }
        catch (IOException mIOException)
        {
            throw new Error("UnableToCreateDatabase");
        }
        return this;
    }

    public DataBaseAdapter open() throws SQLException
    {
        try
        {
            mDbHelper.openDataBase();
            mDbHelper.close();
            mDb = mDbHelper.getReadableDatabase();

        }
        catch (SQLException mSQLException)
        {
            throw mSQLException;
        }
        return this;
    }

    public void close() {
        mDbHelper.close();
    }
    //Get Created Date
    public String GenCreatedDate()
    {
        String dateString="";
        try{
            Date deviceTime = new Date();

            long date = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            dateString = sdf.format(date);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       // Date trueTime = TrueTimeRx.now();

        //dateString = _formatDate(trueTime, "yyyy-MM-dd", TimeZone.getDefault());
        return dateString;
    }

    //Get Created Date
    public String GenCreatedDateTime()
    {
        String dateString="";
        try{
            Date deviceTime = new Date();

            long date = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            dateString = sdf.format(date);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        // Date trueTime = TrueTimeRx.now();

        //dateString = _formatDate(trueTime, "yyyy-MM-dd", TimeZone.getDefault());
        return dateString;
    }

    //Get Created Date
    public String GetDateTime()
    {
        String dateString="";
        try{
            Date deviceTime = new Date();

            long date = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
            dateString = sdf.format(date);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       // Date trueTime = TrueTimeRx.now();

       // dateString = _formatDate(trueTime, "hh:mm a", TimeZone.getDefault());
        return dateString;
    }



    //Get formated date
    public String GenCurrentCreatedDate()
    {
        String dateString="";
        try{
            Date date = new Date();

            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            dateString = sdf.format(date);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       // Date trueTime = TrueTimeRx.now();

       // dateString = _formatDate(trueTime, "dd-MM-yyyy", TimeZone.getDefault());
        return dateString;
    }
    private String _formatDate(Date date, String pattern, TimeZone timeZone) {
        DateFormat format=null;
        try{
            format = new SimpleDateFormat(pattern, Locale.ENGLISH);
            format.setTimeZone(timeZone);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return format.format(date);
    }
    //Insert Error log
    public void insertErrorLog(String error,String classname,String linenumber)
    {
        String Gencode= GenCreatedDate();
        String sql = "INSERT INTO  'tblerrorlogdetails'(error,classname,linenumber,deviceid,date) " +
                "VALUES('"+error.replace("'","")+"','"+classname+"','"+linenumber+"','"+LoginActivity.deviceid+"','"+ Gencode +"')";
        mDb.execSQL(sql);

    }
    /**************** END COMMON FUNCTION**********/

    //Get Van Datas form database for each imeino
    public Cursor GetVanNameForIMEIDB(String deviceid)
    {
        Cursor mCur = null;
        try{
            String sql ="select vancode,vanname,imeino,pin,business_type,orderprint from tblvanmaster where imeino='"+deviceid+"'" +
                    " and  status='"+statusvar+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


       return mCur;


    }
    //Get Van Datas form database for each imeino
    public String GetIMEICountDB(String deviceid)
    {
        String getcount="0";
        try{

            String sql ="select coalesce(count(*),0) from tblvanmaster where imeino='"+deviceid+"'" +
                    " and  status='"+statusvar+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcount = mCur.getString(0);
            }
            if(mCur != null && !mCur.isClosed()){
                mCur.close();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcount;
    }
    //Get table count
    public String GetCountDB()
    {
        String getcount = "0";
        try{
            String sql ="select coalesce(count(*),0) from tblvanmaster ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcount = mCur.getString(0);
            }
            if(mCur != null && !mCur.isClosed()){
                mCur.close();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcount;
    }
    //GetServerSettingsDB
    public String GetServerSettingsDB()
    {
        String getimeino = "";
        try{
            String sql ="select coalesce(internetip,'') as ipaddress from tblserversettings where status='active' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getimeino = mCur.getString(0);
            }else{
                getimeino = "";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return getimeino;
    }
    //Check today schedule count
    public String GetScheduleCountDB()
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();
            String sql ="select coalesce(count(*),0) from tblsalesschedule where vancode='"+LoginActivity.getvancode+"'" +
                    " and  scheduledate=datetime('"+Gencode+"') ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Check voucher settings for sales
    public String GetSalesVoucherSettingsDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select count(count1-count2) from (select sum(count1) as count1,sum(count2) as count2 " +
                    " from (select count(*) as count1,0 as count2 from tblcompanymaster,tblbilltype  " +
                    " where companycode in (select companycode from tblitemmaster ) union all " +
                    "select 0 , count(*) from tblvouchersettings " +
                    "where financialyearcode='"+LoginActivity.getfinanceyrcode+"' and type='sales' and vancode='"+LoginActivity.getvancode+"')" +
                    " as derv) as de where count1<>count2;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }


    //Check voucher settings for sales
    public String GetSalesOrderVoucherSettingsDB()
    {
        Cursor mCur = null;
        try{
          /*  String sql ="select count(count1-count2) from (select sum(count1) as count1,sum(count2) as count2 " +
                    " from (select count(*) as count1,0 as count2 from tblcompanymaster union all " +
                    "select 0 , count(*) from tblvouchersettings " +
                    "where financialyearcode='"+LoginActivity.getfinanceyrcode+"' and" +
                    "  type='salesorder' and vancode='"+LoginActivity.getvancode+"')" +
                    " as derv) as de where count1<>count2;";*/
            String sql ="select coalesce(count(*),'0') as count from tblvouchersettings " +
                    "where financialyearcode='"+LoginActivity.getfinanceyrcode+"' and" +
                    "  type='salesorder' and vancode='"+LoginActivity.getvancode+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Check item stock
    public String GetSalesItemStockCount()
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(count(*),0) from tblitemmaster as a inner join tblstocktransaction as b on " +
                    " a.itemcode = b.itemcode where b.vancode = '"+LoginActivity.getvancode+"' and b.flag!=3 ;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //delete item cart data
    public void DeleteSalesItemCart()
    {
        try{
            String sqldeletesalescart="delete from tblsalescartdatas ";
            mDb.execSQL(sqldeletesalescart);
            String sqldeletestockconversion="delete from tblstockconversion ";
            mDb.execSQL(sqldeletestockconversion);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //delete item cart data
    public void DeleteSalesCartItemCart()
    {
        try{
            String sqldeletesalescart="delete from tblsalesordercartdatas ";
            mDb.execSQL(sqldeletesalescart);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Check voucher settings for receipt
    public String GetReceiptVoucherSettingsDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select count(count1-count2) from (select sum(count1) as count1,sum(count2) as count2 " +
                    " from (select count(*) as count1,0 as count2 from tblcompanymaster union all " +
                    "select 0 , count(*) from tblvouchersettings " +
                    "where financialyearcode='"+LoginActivity.getfinanceyrcode+"' and" +
                    "  type='receipt' and vancode='"+LoginActivity.getvancode+"')" +
                    " as derv) as de where count1<>count2;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Check get financial yearcode
    public String GetFinancialYrCode()
    {
        String finacialyrcode="0";
        try{
            String Gencode= GenCreatedDate();
            String sql ="select coalesce(financialyearcode,0) from tblfinancialyear where " +
                    " fromdate <= datetime('"+Gencode+"') and todate >= datetime('"+Gencode+"') ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                finacialyrcode = mCur.getString(0);
            }else{
                finacialyrcode = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return finacialyrcode;
    }
    //Get Schedule List
    public Cursor GetScheduleDB()
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();
            String sql ="select schedulecode,routecode,(select routename from tblroute where routecode=a.routecode) as routename," +
                    " tripadvance,(select routenametamil from tblroute where routecode=a.routecode) as routenametamil," +
                    " (select capacity from tblvehiclemaster where vehiclecode=a.vehiclecode) as capacity from " +
                    " tblsalesschedule as a where  vancode='"+LoginActivity.getvancode+"'" +
                    " and  scheduledate=datetime('"+Gencode+"') ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Booking No
    public String GetBookingNo()
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();
         /*   String sql ="select  case when (select Count(*) from tblsales)=0 then case when " +
                    "(select coalesce(max(bookingno),1) from tblmaxcode  where code=2 " +
                    " and datetime(transdate)= datetime('"+Gencode+"') )=1 then  coalesce(max(bookingno),0)+1 " +
                    "else (select coalesce(max(bookingno),0)+1 from tblmaxcode where code=2" +
                    " and datetime(transdate)= datetime('"+Gencode+"')  ) " +
                    " end else  coalesce(max(bookingno),0)+1  " +
                    "end as bookingno from tblsales as  a where financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and datetime(billdate)= datetime('"+Gencode+"'); ";*/
            String sql ="select   coalesce(max(bookingno),0)+1  " +
                    "  as bookingno from tblsales as  a where financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and datetime(billdate)= datetime('"+Gencode+"'); ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Get Booking No
    public String GetSalesOrderBookingNo()
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();
          /*  String sql ="select  case when (select Count(*) from tblsalesorder)=0 then case when " +
                    "(select coalesce(max(bookingno),1) from tblmaxcode  where code=7 " +
                    " and datetime(transdate)= datetime('"+Gencode+"') )=1 then  coalesce(max(bookingno),0)+1 " +
                    "else (select coalesce(max(bookingno),0)+1 from tblmaxcode where code=7" +
                    " and datetime(transdate)= datetime('"+Gencode+"')  ) " +
                    " end else  coalesce(max(bookingno),0)+1  " +
                    "end as bookingno from tblsalesorder as  a where financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and datetime(billdate)= datetime('"+Gencode+"'); ";*/
            String sql ="select   coalesce(max(bookingno),0)+1  " +
                    "  as bookingno from tblsalesorder as  a where financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and datetime(billdate)= datetime('"+Gencode+"'); ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get Booking No
    public String GetSalesOrderVoucherNo(String bookingno,String financialyearcode,String billtypecode)
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();

            String sql ="select   case when (select Count(*) from tblsalesorder where  " +
                "   billtypecode = '"+billtypecode+"' )=0 " +
                        " then case when (select coalesce(max(refno),0)+1 from tblmaxcode where code=777 " +
                        " and billtypecode = '"+billtypecode+"')=1 then " +
                        "(select prefix || printf('%0'||noofdigit||'d','"+ bookingno+"')||suffix FROM tblvouchersettings " +
                        "where type='salesorder' and billtypecode='"+billtypecode+"' and vancode='"+ LoginActivity.getvancode +"' " +
                        "  and financialyearcode='"+ financialyearcode +"')" +
                        "else" +
                        "(select prefix || printf('%0'||noofdigit||'d', '"+bookingno+"')||suffix " +
                        " FROM tblvouchersettings where type='salesorder' and " +
                        "billtypecode='"+billtypecode+"' and vancode='"+ LoginActivity.getvancode +"'  " +
                        "and financialyearcode='"+ financialyearcode +"')" +
                        "end else" +
                        "(select prefix || printf('%0'||noofdigit||'d', '"+bookingno+"')||suffix " +
                        "FROM tblvouchersettings where type='salesorder' and billtypecode='"+billtypecode+"' and " +
                        "vancode='"+ LoginActivity.getvancode +"' and financialyearcode='"+ financialyearcode +"')" +
                        " end as billno";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Get Close cah details
    public String GetCashClose(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblclosecash where schedulecode = '"+getschedulecode+"' and status='2'  ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get Close cah details
    public String GetCashCloseCount(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblclosecash where schedulecode = '"+getschedulecode+"'    ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get GetDenominationCount
    public Double GetDenominationCount(String getschedulecode)
    {
        Double getcashcount = 0.0;
        try{
            String sql ="select  coalesce(count(*),0) from tbldenomination where schedulecode = '"+getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getDouble(0);
            }else{
                getcashcount =  0.0;
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get Close sales details
    public String GetSalesClose(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblclosesales where schedulecode = '"+getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get Close sales details
    public String GetReceiptCount(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblreceipts where schedulecode = '"+getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }


    //Get Close sales details
    public String GetExpenseCount(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblexpenses where schedulecode = '"+getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get Close sales details
    public String GetCountCashClose(String getschedulecode)
    {
        String getcashcount = "0";
        try{
            String sql ="select  coalesce(count(*),0) from tblclosecash where schedulecode = '"+getschedulecode+"' and status='2' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcashcount =  mCur.getString(0);
            }else{
                getcashcount =  "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcashcount;
    }

    //Get wish msg
    public String GetWishmsg()
    {
        String getmsg = "";
        try{
            String sql ="select  coalesce(wishmsg,'') from tblgeneralsettings limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getmsg =  mCur.getString(0);
            }else{
                getmsg =  "";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getmsg;
    }
    //Get Tranasaction No
    public String GetTransactionNo()
    {
        Cursor mCur = null;
        try{
            String sql ="select  case when (select Count(*) from tblsales)=0 then case when " +
                    "(select coalesce(max(transactionno),1) from tblmaxcode where code=22  )=1 then " +
                    " coalesce(max(transactionno),0)+1 " +
                    "else (select coalesce(max(transactionno),0)+1 from tblmaxcode where code=22 ) end " +
                    " else  coalesce(max(transactionno),0)+1  " +
                    "end as transactionno from tblsales as  a ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Get Tranasaction No
    public String GetSalesOrderTransactionNo()
    {
        Cursor mCur = null;
        try{
            String sql ="select  case when (select Count(*) from tblsalesorder)=0 then case when " +
                    "(select coalesce(max(transactionno),1) from tblmaxcode where code=77  )=1 then " +
                    " coalesce(max(transactionno),0)+1 " +
                    "else (select coalesce(max(transactionno),0)+1 from tblmaxcode where code=77 ) end " +
                    " else  coalesce(max(transactionno),0)+1  " +
                    "end as transactionno from tblsalesorder as  a ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get Van Datas form database for each imeino
    public String GetDrildownGroupStatusDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(drilldownitem,'no') from tblgeneralsettings ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get schedule settings
    public String GetScheduleStatusDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(salesschedulemobileapp,'yes') from tblgeneralsettings ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get Customer settings
    public String GetCustomerStatusDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(enableallcustomersmobileapp,'no') from tblgeneralsettings ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get schedule settings
    public String GetBillCopyDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(billcopypopup,'yes') from tblgeneralsettings ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get Receipt remarks
    public Cursor GetReceiptRemarks()
    {
        Cursor mCur = null;
        try{
            String sql ="select receiptremarks,receiptremarkscode from tblreceiptremarks;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get area based on route
    public Cursor GetAreaDB(String routecode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }
            String sql ="select distinct a.areacode,areaname,areanametamil,noofkm,a.citycode,c.citynametamil," +
                    " (select coalesce(count(*),0) as count from tblcustomer as b where areacode=a.areacode " +
                    " and "+getbusinesstype+") as customercount " +
                    "from tblareamaster as a inner join tblroutedetails as b on a.areacode=b.areacode  " +
                    "inner join tblcitymaster as c on c.citycode=a.citycode where routecode='"+routecode+"' " +
                    "and a.status='"+statusvar+"' and c.status='"+statusvar+"' order by citynametamil,areanametamil ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get area based on route
    public Cursor GetTransportDB(String getareacode,String gettransportmodecode)
    {
        Cursor mCur = null;
        try{
            String getdate = GenCreatedDate();
            String sqlc =  "select case cast (strftime('%w', '"+getdate+"') as integer) " +
                    " when 0 then 'Sunday' when 1 then 'Monday' when 2 then 'Tuesday' when 3 then 'Wednesday' when 4 then 'Thursday' when 5 then " +
                    " 'Friday' else 'Saturday' end as dayname" ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getdayname= (mCurc.moveToFirst())?mCurc.getString(0):"Sunday";


            String sql ="select a.transportid,a.transportname,a.vechicle_number,b.day_of_dispatch from tbltransportmaster as a inner join" +
                    "  tbltransportcitymapping as b on a.transportid=b.transportid" +
                    " where a.transportmodecode='"+gettransportmodecode+"' and " +
                    " b.citycode= (select citycode from tblareamaster where areacode='"+getareacode+"')   ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get area based on route
    public Cursor GetTransportModeDB()
    {
        Cursor mCur = null;
        try{


            String sql ="select transportmodecode,transportmodetype from tbltransportmode order by transportmodecode desc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Area Customer List
    public Cursor GetCustomerListAreaDB(String routecode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype="";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (business_type = 2 or business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(business_type = 1 or business_type = 3)";
            }else{
                getbusinesstype="(business_type = 1 or  business_type = 2 or business_type = 3)";
            }
            String sql ="select '0' as areacode,'All Areas' as areaname,'All Areas' as areanametamil,'0' as noofkm," +
                    " '0' as citycode,'' as citynametamil,'0' as customercount  union all " +
                    " select distinct a.areacode,areaname,areanametamil,noofkm,a.citycode,c.citynametamil," +
                    " (select coalesce(count(*),0) as count from tblcustomer where areacode=a.areacode and "+getbusinesstype+") as customercount " +
                    "from tblareamaster as a inner join tblroutedetails as b on a.areacode=b.areacode  " +
                    "inner join tblcitymaster as c on c.citycode=a.citycode where routecode='"+routecode+"' " +
                    "and a.status='"+statusvar+"' and c.status='"+statusvar+"' order by citynametamil,areanametamil ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Receipt Area List
    public Cursor GetReceiptAreaDB(String routecode)
    {
        Cursor mCur = null;
        try{
            String sql ="select '0' as areacode,'All Areas' as areaname,'All Areas' as areanametamil," +
                    " '0' as noofkm,'0' as citycode,'' as citynametamil,'' as customercount union all" +
                    " select distinct a.areacode,areaname,areanametamil,noofkm,a.citycode,c.citynametamil," +
                    " (select coalesce(count(*),0) as count from tblcustomer where areacode=a.areacode) as customercount " +
                    "from tblareamaster as a inner join tblroutedetails as b on a.areacode=b.areacode  " +
                    "inner join tblcitymaster as c on c.citycode=a.citycode where routecode='"+routecode+"' " +
                    "and a.status='"+statusvar+"' and c.status='"+statusvar+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get area based on city
    public Cursor GetAreaCityDB(String getcitycode,String getroutecode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype="";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (business_type = 2 or business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(business_type = 1 or business_type = 3)";
            }else{
                getbusinesstype="(business_type = 1 or  business_type = 2 or business_type = 3)";
            }
            String sql ="select distinct a.areacode,areaname,areanametamil,noofkm,a.citycode,c.cityname," +
                    " (select coalesce(count(*),0) as count from tblcustomer where areacode=a.areacode and  "+getbusinesstype+") as customercount " +
                    "from tblareamaster as a inner join tblroutedetails as b on a.areacode=b.areacode  " +
                    "inner join tblcitymaster as c on c.citycode=a.citycode where routecode='"+getroutecode+"' " +
                    " and a.citycode='"+getcitycode+"' " +
                    "and a.status='"+statusvar+"' and c.status='"+statusvar+"' order by areanametamil ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get City based on route
    public Cursor GetCityDB(String routecode)
    {
        Cursor mCur = null;
        try{
            String sql ="select distinct a.citycode,a.cityname,a.citynametamil from tblcitymaster as a inner join tblareamaster as b " +
                    "on a.citycode=b.citycode where b.areacode in " +
                    " (select areacode from tblroutedetails where routecode='"+routecode+"') and " +
                    " a.status='"+statusvar+"' and b.status='"+statusvar+"' order by a.citynametamil ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get item group
    public Cursor GetOrderItemgroupDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select '0' as itemgroupcode,'All Item Group' as itemgroupname,'All Item Group' as itemgroupnametamil " +
                    " union all " +
                    " select itemgroupcode,itemgroupname,itemgroupnametamil" +
                    " from tblitemgroupmaster where status='"+statusvar+"' order by itemgroupcode desc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get item sub group
    public Cursor GetOrderItemSubgroupDB(String getitemgroupcode)
    {
        Cursor mCur = null;
        try{
            String itemgroupcode="";
            if(getitemgroupcode.equals("0")){
                itemgroupcode = "1=1";
            }else{
                itemgroupcode = "itemgroupcode='"+getitemgroupcode+"'";
            }
            String sql ="select '0' as itemsubgroupcode,'All Item Sub-Group' as itemsubgroupname,'All Item Sub-Group' as  " +
                    " itemsubgroupnametamil union all " +
                    " select itemsubgroupcode,itemsubgroupname,itemsubgroupnametamil " +
                    " from tblitemsubgroupmaster where status='"+statusvar+"' and "+itemgroupcode+" " +
                    "order by itemsubgroupcode desc " ;
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Return List
    public Cursor GetSalesReturnListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur = null;
        try{
            String sql="";
            String getbilltype="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }


            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsalesreturn as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+"  order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Return List
    public Cursor GetSalesPrintReturnListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur = null;
        try{
            String sql="";
            String getbilltype="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }


            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsalesreturn as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and   a.flag!=3 and a.flag!=6 and  " +
                    " "+getcompany+" and "+getbilltype+"  order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Return List
    public Cursor GetSalesOrderPrintListDB(String getdate)
    {
        Cursor mCur = null;
        try{
            String sql="";

            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsalesorder as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and   a.flag!=3 and a.flag!=6    " +
                    "   order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get close sales report
    public Cursor GetCloseSalesitemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblclosesales where flag=1  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get NilStockDetail
    public Cursor GetNilStockDetailsDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblnilstocktransaction where syncflag=0  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get NilStockDetail
    public Cursor GetWholeNilStockDetailsDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblnilstocktransaction    ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales Return List data Details
    public Cursor GetSalesReturnListDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname," +
                    " (select sum(grandtotal) from tblsalesreturn as b where transactionno = '"+gettransactionno+"' and financialyearcode = '"+getfinancialyr+"' ) as totalamt " +
                    " from tblsalesreturn as a where transactionno = '"+gettransactionno+"' " +
                    " and financialyearcode = '"+getfinancialyr+"' and companycode='"+getcompanycode+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get Sales Return List data Details
    public Cursor GetSalesReturnListItemDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select a.itemcode,b.itemnametamil,a.qty,a.weight,a.price,a.discount,a.amount,a.freeitemstatus ," +
                    "(select unitname from tblunitmaster where unitcode=b.unitcode) as unitname," +
                    "(select hsn from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as hsn," +
                    "(select tax from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as tax," +
                    " coalesce((Select noofdecimals from tblunitmaster where unitcode=b.unitcode),0) as noofdecimals," +
                    " coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " from tblsalesreturnitemdetails as a inner join tblitemmaster as b on a.itemcode=b.itemcode" +
                    " where a.transactionno='"+gettransactionno+"' and a.companycode='"+getcompanycode+"' " +
                    " and a.financialyearcode='"+getfinancialyr+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get Sales Return cancel Datas
    public Cursor GetSalesReturnCancelDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesreturn where flag=3 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get group based on sub group return
    public Cursor GetSubGroup_GroupDBSalesReturn(String itemgroupcode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select distinct c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil from " +
                    "  tblitemmaster  as b inner join  " +
                    "tblitemsubgroupmaster as c on c.itemsubgroupcode=b.itemsubgroupcode where " +
                    " c.itemgroupcode='"+itemgroupcode+"' " +
                    " and b.status='"+statusvar+"' and c.Status='"+statusvar+"' order by c.itemsubgroupnametamil";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public String insertReceipt(String receiptdate,String companycode,
                                String vancode,String customercode,String schedulecode,String receiptremarkscode,
                                String receiptmode,
                                String chequerefno,String amount,String financialyearcode,String note )

    {
        String transno= "1";
        try{
            String Gencode= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String getcurtime = GetDateTime();


            String sqlc = "select  count(*) from tblreceipt " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";


            if(getcount.equals("0")){
                String sql1 = "select coalesce(transactionno,0) from tblmaxcode where code=4  ";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                transno = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
                if(transno.equals("0")){
                    transno ="1";
                }
            }else {
                String sql1 = "select coalesce(max(transactionno),0)+1 from tblreceipt";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                transno = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
            }

            String sql="INSERT INTO tblreceipt(autonum,transactionno,receiptdate,prefix,suffix,voucherno,refno," +
                    "companycode,vancode," +
                    "customercode,schedulecode,receiptremarkscode,receiptmode,chequerefno,amount," +
                    "makerid,createddate,financialyearcode," +
                    "flag,note,syncstatus,receipttime) VALUES ((select coalesce(max(autonum),0)+1 from tblreceipt),'"+ transno +"',datetime('"+ receiptdate +"')," +
                    "(select prefix FROM tblvouchersettings where type='receipt'  and vancode='"+ vancode +"' " +
                    "and companycode='"+ companycode +"' and financialyearcode='"+ financialyearcode +"')  ," +
                    "(select suffix FROM tblvouchersettings where type='receipt'  and vancode='"+ vancode +"' " +
                    "and companycode='"+ companycode +"' and financialyearcode='"+ financialyearcode +"')  ," +
                    "case when (select Count(*) from tblreceipt where companycode='"+companycode+"')=0 then " +
                    " case when (select coalesce(max(refno),1) " +
                    "from tblmaxcode where code=44 and companycode='"+companycode+"' )=1 then " +
                    "(select prefix || printf('%0'||noofdigit||'d', startingno)||suffix FROM tblvouchersettings " +
                    "where type='receipt'  and vancode='"+ vancode +"' and companycode='"+ companycode +"' " +
                    "and financialyearcode='"+ financialyearcode +"')" +
                    "else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0) from tblmaxcode " +
                    "where code=44 and companycode='"+companycode+"'))||suffix FROM tblvouchersettings where type='receipt'  and vancode='"+ vancode +"' " +
                    "and companycode='"+ companycode+"' and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblreceipt where  " +
                    " companycode='"+ companycode+"' and financialyearcode='"+ financialyearcode +"' ))||suffix FROM " +
                    " tblvouchersettings where type='receipt'  and vancode='"+ vancode +"' and companycode='"+ companycode +"'" +
                    " and financialyearcode='"+ financialyearcode +"')" +
                    " end  ,case when (select Count(*) from tblreceipt  where companycode='"+companycode+"')=0 then " +
                    " case when (select coalesce(max(refno),1) " +
                    " from tblmaxcode where code=44 and companycode='"+companycode+"')=1 then " +
                    " (select  printf('%0'||noofdigit||'d', startingno) FROM tblvouchersettings where type='receipt'  " +
                    " and vancode='"+ vancode +"' and companycode='"+ companycode +"' and financialyearcode='"+ financialyearcode +"')" +
                    " else " +
                    " (select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)  from tblmaxcode where code=44 and companycode='"+companycode+"')) " +
                    " FROM tblvouchersettings where type='receipt' and vancode='"+ vancode +"' and companycode='"+ companycode +"'" +
                    " and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblreceipt where " +
                    " companycode='"+ companycode+"' and financialyearcode='"+ financialyearcode +"')) FROM tblvouchersettings " +
                    "where type='receipt'  and vancode='"+ vancode +"' and companycode='"+ companycode +"' and " +
                    " financialyearcode='"+ financialyearcode +"')" +
                    " end  ,'"+ companycode +"','"+ vancode +"','"+ customercode +"','"+ schedulecode +"'," +
                    " '"+ receiptremarkscode +"','"+ receiptmode +"','"+ chequerefno +"'," +
                    "'"+ amount +"','1',datetime('now', 'localtime'),'"+ financialyearcode +"','1','"+ note +"',0,'"+getcurtime+"')";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return transno;
    }
    //Update Sales Return Stock transaction
    public String UpdateSalesReturnStockTransaction(String gettransactiono,String getfinancialyrcode)
    {
        try{
            String GetDate= GenCreatedDate();
            String sql = " insert into tblstocktransaction (transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,flag,createddate,companycode,op,financialyearcode,autonum)" +
                    "select (select coalesce(max(transactionno),0)+1 from tblstocktransaction),datetime('"+GetDate+"')," +
                    "vancode,itemcode,'-'||qty,0,'salesreturncancel',transactionno,1,datetime('now', 'localtime'),companycode,0,'"+getfinancialyrcode+"',(select coalesce(max(autonum),0)+1 from tblstocktransaction)+autonum " +
                    " from tblsalesreturnitemdetails where transactionno='"+gettransactiono+"' " +
                    "and financialyearcode='"+getfinancialyrcode+"'  ";
            mDb.execSQL(sql);


            String sql1 = " insert into tblappstocktransactiondetails (transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,flag,createddate,companycode,op,financialyearcode,syncstatus)" +
                    "select (select coalesce(max(transactionno),0)+1 from tblappstocktransactiondetails),datetime('"+GetDate+"')," +
                    "vancode,itemcode,'-'||qty,0,'salesreturncancel',transactionno,1,datetime('"+GetDate+"'),companycode,0,'"+getfinancialyrcode+"',0 " +
                    " from tblsalesreturnitemdetails where transactionno='"+gettransactiono+"' " +
                    "and financialyearcode='"+getfinancialyrcode+"'  ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

      /*  String sql = " update  tblstocktransaction set flag=3 " +
                " where refno='"+gettransactiono+"' " +
                "and financialyearcode='"+getfinancialyrcode+"' and type='salesreturn'  ";
        mDb.execSQL(sql);

        String sql1 = " update  tblappstocktransactiondetails set flag=3 and syncstatus=0 " +
                " where refno='"+gettransactiono+"' " +
                "and financialyearcode='"+getfinancialyrcode+"' and type='salesreturn'  ";
        mDb.execSQL(sql1);*/
        return "success";
    }

    //stock checking for return cancel
    public String StockChecking(String paraTransactionNo,String parafinancialyearcode)
    {
        String getcount = "0";
        try{
            String sql ="select count(*) from (" +
                    "select itemcode,sum(op)+sum(inward)-sum(outward) as closing from tblstocktransaction where " +
                    "datetime(transactiondate)<=datetime('now', 'localtime')  and flag!=3 group by itemcode) as derv inner join (" +
                    "select itemcode,sum(qty) as returnstock from tblsalesreturnitemdetails where transactionno='"+paraTransactionNo+"' and financialyearcode='"+parafinancialyearcode+"' and flag!=3 group by itemcode) as returnval on " +
                    "derv.itemcode=returnval.itemcode where closing-returnstock<0";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcount = mCur.getString(0);
            }else{
                getcount = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcount;
    }



    //Update Sales Return Cancel Flag
    public String UpdateSalesReturnCancelFlag(String gettransactiono,String getfinancialyrcode)
    {
        try{
            String sql = "update tblsalesreturn set flag=3,syncstatus=0 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql);

            String sql1 = "update tblsalesreturnitemdetails set flag=3 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }

    //Update Sales Return Flag
    public void UpdateCancelSalesReturnFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesreturn set flag=6,syncstatus=1 where transactionno='" + gettransactiono + "' and flag=3 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }
    //Get item sub group
    public Cursor GetOrderItemDB(String getitemgroupcode,String getsubitemgroupcode)
    {
        Cursor mCur = null;
        try{
            String itemsubgroupcode="";
            if(getsubitemgroupcode.equals("0")){
                itemsubgroupcode = "1=1";
            }else{
                itemsubgroupcode = "a.itemsubgroupcode='"+getsubitemgroupcode+"'";
            }
            String itemgroupcode="";
            if(getitemgroupcode.equals("0")){
                itemgroupcode = "1=1";
            }else{
                itemgroupcode = "c.itemgroupcode='"+getitemgroupcode+"'";
            }
            String sql ="select a.itemcode,a.itemname,a.itemnametamil,a.unitweight," +
                    "a.companycode,(select colourcode from tblcompanymaster where companycode=a.companycode) as colourcode," +
                    "(select unitname from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "(select hsn from tblitemsubgroupmaster where itemsubgroupcode=a.itemsubgroupcode) as hsn," +
                    "(select tax from tblitemsubgroupmaster where itemsubgroupcode=a.itemsubgroupcode) as tax " +
                    ",(select coalesce(sum(op)+sum(inward)-sum(outward),0) from tblstocktransaction" +
                    " where itemcode=a.itemcode and flag!=3) as stock,a.uppweight" +
                    " from tblitemmaster as a inner join tblitemsubgroupmaster as c on a.itemsubgroupcode=c.itemsubgroupcode " +
                    "where a.status='"+statusvar+"' and "+itemgroupcode+" and "+itemsubgroupcode+" ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Items Sales Return
    public Cursor GetSalesOrderItemDB(String itemsubgroupcode,String getroutecode,String getareacode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }

            String getitembusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getitembusinesstype=" (a.business_type = 2 or a.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getitembusinesstype="(a.business_type = 1 or a.business_type = 3)";
            }else{
                getitembusinesstype="(a.business_type = 1 or  a.business_type = 2 or a.business_type = 3)";
            }
            getdate = GenCreatedDate();
            String sql ="select a.itemcode,a.companycode,a.brandcode,a.manualitemcode,a.itemname,a.itemnametamil,a.unitcode," +
                    "a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight,a.itemcategory,a.parentitemcode," +
                    "a.allowpriceedit,a.allownegativestock,a.allowdiscount, '0' as stockqty," +
                    "(Select unitname  from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "coalesce((Select noofdecimals from tblunitmaster where unitcode=a.unitcode),0) as noofdecimals," +
                    "coalesce((select oldorderprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    "order by autonum desc limit 1),0) as oldorderprice,coalesce((select neworderprice from tblitempricelisttransaction" +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as neworderprice,coalesce((select colourcode " +
                    "from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode,coalesce(c.hsn,'') " +
                    "as hsn,coalesce(c.tax,'') as tax,(select allowpriceedit from tblroutedetails where routecode='"+getroutecode+"' and areacode='"+getareacode+"')" +
                    " as routeallowpricedit,case when parentitemcode=0 then a.itemcode else parentitemcode " +
                    " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  a.orderstatus,a.maxorderqty ,(select count(*) from tblschemeratedetails as aa inner join " +
                      "  tblscheme as b on aa.schemecode=b.schemecode where aa.itemcode=a.itemcode and b.status='"+statusvar+"' " +
                    "  and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' " +
                    "  and(validityfrom<=datetime('"+getdate+"')) and (ifnull(validityto,'')='' or " +
                    " (validityfrom<=datetime('"+getdate+"') " +
                    " and  validityto>=datetime('"+getdate+"'))) and "+getbusinesstype+" ) as ratecount," +
                    " (select count(*) from tblschemeitemdetails as ab  inner join  tblscheme as b " +
                    " on ab.schemecode=b.schemecode where ab.purchaseitemcode=a.itemcode and b.status='"+statusvar+"' and (','||multipleroutecode||',') " +
                    " LIKE '%,"+getroutecode+",%' and(validityfrom<=datetime('"+getdate+"')) and (ifnull(validityto,'')='' or (validityfrom<=datetime('"+getdate+"') " +
                    " and  validityto>=datetime('"+getdate+"')))  and  "+getbusinesstype+" ) as freecount " +
                    " from tblitemmaster as a   " +
                    " inner join tblitemsubgroupmaster as c on c.itemsubgroupcode=a.itemsubgroupcode" +
                    " inner join tblbrandmaster as d on a.brandcode=d.brandcode  where "+getitembusinesstype+" and " +
                    " a.itemsubgroupcode ='"+itemsubgroupcode+"' and a.status='"+statusvar+"'  group by a.itemcode,a.companycode,a.brandcode,a.manualitemcode," +
                    "a.itemname,a.itemnametamil,a.unitcode,a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight," +
                    "a.itemcategory,a.parentitemcode,a.allowpriceedit,a.allownegativestock,a.allowdiscount" +
                    " order by c.itemsubgroupname,d.brandname,a.itemcategory desc ";
            //parentcode,itemorder,a.itemname
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor GetNextdayItemDB(String getitemgroupcode,String getsubitemgroupcode,String Schedulecode)
    {
        Cursor mCur = null;
        try{
            String itemsubgroupcode="";
            if(getsubitemgroupcode.equals("0")){
                itemsubgroupcode = "1=1";
            }else{
                itemsubgroupcode = "a.itemsubgroupcode='"+getsubitemgroupcode+"'";
            }
            String itemgroupcode="";
            if(getitemgroupcode.equals("0")){
                itemgroupcode = "1=1";
            }else{
                itemgroupcode = "c.itemgroupcode='"+getitemgroupcode+"'";
            }
            String sql ="select a.itemcode,a.itemname,a.itemnametamil,a.unitweight," +
                    "a.companycode,(select colourcode from tblcompanymaster where companycode=a.companycode) as colourcode," +
                    "(select unitname from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "(select hsn from tblitemsubgroupmaster where itemsubgroupcode=a.itemsubgroupcode) as hsn," +
                    "(select tax from tblitemsubgroupmaster where itemsubgroupcode=a.itemsubgroupcode) as tax " +
                    ",(select coalesce(sum(op)+sum(inward)-sum(outward),0) from tblstocktransaction" +
                    " where itemcode=a.itemcode and flag!=3) as stock,a.uppweight,d.qty" +
                    " from tblitemmaster as a inner join tblitemsubgroupmaster as c on" +
                    "  a.itemsubgroupcode=c.itemsubgroupcode inner join tblorderdetails as d on d.itemcode=a.itemcode  " +
                    "where a.status='"+statusvar+"' and  "+itemgroupcode+" and "+itemsubgroupcode+" and d.schedulecode='"+Schedulecode+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get item sub group
    public Cursor GetPriceItemDB(String getitemgroupcode,String getsubitemgroupcode,
                                 String getitemname,String itemtype)
    {
        Cursor mCur = null;
        try{
            String itemsubgroupcode="";
            if(getsubitemgroupcode.equals("0")){
                itemsubgroupcode = "1=1";
            }else{
                itemsubgroupcode = "a.itemsubgroupcode='"+getsubitemgroupcode+"'";
            }
            String itemgroupcode="";
            if(getitemgroupcode.equals("0")){
                itemgroupcode = "1=1";
            }else{
                itemgroupcode = "c.itemgroupcode='"+getitemgroupcode+"'";
            }

            String getitemtype="";
            if(itemtype.equals("All Items")){
                getitemtype = "1=1";
            }else{
                if(itemtype.equals("Parent")){
                    itemtype = "parent";
                }else{
                    itemtype = "child";
                }
                getitemtype = "a.itemcategory='"+itemtype+"' ";
            }
            String sql ="select a.itemcode,a.itemname,a.itemnametamil,a.unitcode," +
                    "a.companycode,(select colourcode from tblcompanymaster where companycode=a.companycode) as colourcode," +
                    "(select unitname from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "c.hsn, c.tax, " +
                    " coalesce((select oldprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    " order by autonum desc limit 1),0) as oldprice," +
                    " coalesce((select newprice from tblitempricelisttransaction" +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as newprice," +
                    " case when parentitemcode=0 then a.itemcode else parentitemcode " +
                    " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder ," +
                    " c.itemsubgroupname,d.brandname,a.itemcategory," +
                    " case when f.createddate  >= datetime('now','-1 day')   then 'pricechanged' else 'nochanges' end as pricetatus,  " +
                    " coalesce((select oldorderprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    " order by autonum desc limit 1),0) as oldorderprice," +
                    " coalesce((select neworderprice from tblitempricelisttransaction" +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as neworderprice " +
                    " from tblitemmaster as a inner join tblitemsubgroupmaster as c on" +
                    " a.itemsubgroupcode=c.itemsubgroupcode  inner join tblbrandmaster as d on a.brandcode=d.brandcode inner join " +
                    " tblitempricelisttransaction as f on f.itemcode=a.itemcode " +
                    "where a.status='"+statusvar+"' and  "+itemgroupcode+" and "+itemsubgroupcode+" and "+getitemtype+" " +
                    " and itemname like '%"+getitemname+"%' order by c.itemgroupcode, c.itemsubgroupcode," +
                    " d.brandname,a.itemcategory desc";
            //parentcode,itemorder,a.itemname,
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    // GetCashNotPaidDetails
    public Cursor GetCashNotPaidDetails()
    {
        Cursor mCur = null;
        try{

            String sql ="SELECT transactionno,bookingno,customercode,grandtotal,customernametamil,schedulecode," +
                    " areanametamil from tblcashnotpaiddetails order by grandtotal desc";
            //parentcode,itemorder,a.itemname,
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get company
    public Cursor GetCompanyDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select '0' as companycode,'All Company' as companyname,'All Company' as shortname  union all" +
                    " select companycode,companyname,shortname from tblcompanymaster where status='"+statusvar+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get company
    public Cursor GetCompanyNAmeDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select companycode,companyname,shortname from tblcompanymaster where status='"+statusvar+"'" +
                    " order by shortname ";
             mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Route -- test git
    public Cursor GetRouteDB()
    {
        Cursor mCur = null;
        try{
            String getdate = GenCreatedDate();
          //  String sql ="select routecode,routename,routenametamil,routeday from tblroute where status='"+statusvar+"'" +
              //      " order by routenametamil ";
            String sqlc =  "select case cast (strftime('%w', '"+getdate+"') as integer) " +
                " when 0 then 'Sunday' when 1 then 'Monday' when 2 then 'Tuesday' when 3 then 'Wednesday' when 4 then 'Thursday' when 5 then " +
                        " 'Friday' else 'Saturday' end as dayname" ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getdayname= (mCurc.moveToFirst())?mCurc.getString(0):"Sunday";

            String sql = "";
            if(LoginActivity.getbusiness_type.equals("2")) {
                 sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and (business_type='2'  or business_type='3')  " +
                         " union all SELECT '0' as routecode,'Others' as routename,'Others' as routenametamil,'' as routeday ";

            }else if(LoginActivity.getbusiness_type.equals("1")){
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and (business_type='1'  or business_type='3')   " +
                        "  union all SELECT '0' as routecode,'Others' as routename,'Others' as routenametamil,'' as routeday ";
            }else{
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and (business_type='1' or business_type='2' or  business_type='3')   " +
                        "  union all SELECT '0' as routecode,'Others' as routename,'Others' as routenametamil,'' as routeday ";
            }
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Route
    public Cursor GetFirstRouteDB()
    {
        Cursor mCur = null;
        try{
            String getdate = GenCreatedDate();
            //  String sql ="select routecode,routename,routenametamil,routeday from tblroute where status='"+statusvar+"'" +
            //      " order by routenametamil ";
            String sqlc =  "select case cast (strftime('%w', '"+getdate+"') as integer) " +
                    " when 0 then 'Sunday' when 1 then 'Monday' when 2 then 'Tuesday' when 3 then 'Wednesday' when 4 then 'Thursday' when 5 then " +
                    " 'Friday' else 'Saturday' end as dayname" ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getdayname= (mCurc.moveToFirst())?mCurc.getString(0):"Sunday";

            String sql = "";
            if(LoginActivity.getbusiness_type.equals("2")) {
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and routeday like '%" + getdayname + "%' " +
                        " and (business_type='2'  or business_type='3') limit 1    ";
            }else if(LoginActivity.getbusiness_type.equals("1")) {
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and routeday like '%" + getdayname + "%' " +
                        " and (business_type='1'  or business_type='3') limit 1    ";
            }else{
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode='" + LoginActivity.getvancode + "' and routeday like '%" + getdayname + "%' " +
                        " and (business_type='1'  or business_type='2' or business_type='3') limit 1    ";
            }

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Route
    public Cursor GetOthersRouteDB()
    {
        Cursor mCur = null;
        try{
            String getdate = GenCreatedDate();
            String sqlc =  "select case cast (strftime('%w', '"+getdate+"') as integer) " +
                    " when 0 then 'Sunday' when 1 then 'Monday' when 2 then 'Tuesday' when 3 then 'Wednesday' when 4 then 'Thursday' when 5 then " +
                    " 'Friday' else 'Saturday' end as dayname" ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getdayname= (mCurc.moveToFirst())?mCurc.getString(0):"Sunday";

            //  String sql ="select routecode,routename,routenametamil,routeday from tblroute where status='"+statusvar+"'" +
            //      " order by routenametamil ";
            String sql = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='"+statusvar+"'" +
                        "  and vancode!='"+LoginActivity.getvancode+"' and (business_type='2'  or business_type='3') ";
            }else  if(LoginActivity.getbusiness_type.equals("1")) {
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode!='" + LoginActivity.getvancode + "' and (business_type='1'  or business_type='3')    ";
            }else {
                sql = "  SELECT  routecode,routename,routenametamil,routeday FROM tblroute where status='" + statusvar + "'" +
                        "  and vancode!='" + LoginActivity.getvancode + "' and (business_type='1'  or business_type='2'  or business_type='3')    ";
            }

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get GetCashSummaryCompany
    public Cursor GetCashSummaryCompany()
    {
        Cursor mCur = null;
        try{
            String sql ="select companycode from tblcompanymaster order by companycode asc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get GetCashSummaryDatas
    public Cursor GetCashSummaryDatas(String getschedulecode,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce((select tripadvance from tblsalesschedule where schedulecode='"+getschedulecode+"'),0) as advance, " +
                    "coalesce(sum(grandtotal),0) as amount, " +
                    "(select coalesce(sum(amount),0) from tblreceipt where schedulecode='"+getschedulecode+"' and receiptmode='Cash'  " +
                    "and companycode='"+getcompanycode+"'  and flag!=3 and flag !=6) as receiptamount, " +
                    "(select coalesce(sum(grandtotal),0) from tblsalesreturn where schedulecode='"+getschedulecode+"' and  billtypecode='1' " +
                    "and companycode='"+getcompanycode+"' and flag!=3 and flag !=6) as salesreturnamount, " +
                    "(select companyname from tblcompanymaster where companycode='"+getcompanycode+"') as companyname," +
                    " (select coalesce(sum(amount),0) from tblexpenses where schedulecode='"+getschedulecode+"' and flag!=3) as expenseamt  " +
                    " from tblsales where billtypecode='1' and cashpaidstatus='yes' " +
                    " and schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"'  and flag!=3 and flag !=6 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public Cursor GetExpenseHeadDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select expensesheadcode,expenseshead,expensesheadtamil " +
                    " from tblexpenseshead where status='"+statusvar+"' order by expensesheadtamil ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get denomination
    public Cursor GetCurrencyDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select currencycode,currency from tblcurrency  order by currencycode asc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Schedule denomination
    public Cursor GetScheduleCurrencyDB(String getschedulecode)
    {
        Cursor mCur = null;
        try{
            String sql ="select currencycode,qty from tbldenomination where schedulecode='"+getschedulecode+"';  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Schedule for cash report
    public String GetScheduleCode()
    {
        String getschedulecode = "0";
        try{
            String sql ="select schedulecode from tblsalesschedule where vancode='"+LoginActivity.getvancode+"' " +
                    " order by scheduledate desc limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getschedulecode = mCur.getString(0);
            }else{
                getschedulecode = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getschedulecode;
    }

    //Get Schedule for cash report
    public String GetOrderScheduleCode()
    {
        String getschedulecode = "0";
        try{
            String getdate = GenCreatedDate();
            String sql ="select schedulecode from tblsalesschedule where vancode='"+LoginActivity.getvancode+"'" +
                    " and datetime(scheduledate) != datetime('"+getdate+"') " +
                    " order by scheduledate desc limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getschedulecode = mCur.getString(0);
            }else{
                getschedulecode = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getschedulecode;
    }
    //Get Schedule for cash report
    public String GetOrderFormCount(String getschedulecode)
    {
        String getordercount = "0";
        try{
            String sql ="select coalesce(count(*),0) from tblorderdetails" +
                    "  where schedulecode='"+getschedulecode+"' " +
                    "  limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getordercount = mCur.getString(0);
            }else{
                getordercount = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getordercount;
    }
    //Get Schedule KM
    public Cursor GetScheduleKM(String schedulecode)
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(startingkm,''),coalesce(endingkm,'')" +
                    "  from tblsalesschedule where schedulecode='"+schedulecode+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();

            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public String GetCashRoutename(String getschedulecode)
    {
        String getroutename = "0";
        try{
            String sql =" select a.routecode,(select routenametamil from tblroute where routecode=a.routecode) " +
                    " as routename FROM tblsalesschedule as a where schedulecode='"+getschedulecode+"' limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getroutename = mCur.getString(1);
            }else{
                getroutename = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getroutename;
    }

    public String GetCashStartingKm(String getschedulecode)
    {
        String getstartingkm = "0";
        try{
            String sql =" select startingkm FROM tblsalesschedule as a where schedulecode='"+getschedulecode+"' limit 1 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getstartingkm = mCur.getString(0);
            }else{
                getstartingkm = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getstartingkm;
    }

    public String GetScheduleCount()
    {
        String getschedulecode = "0";
        try{
            String sql ="select coalesce(count(*),'0') as count from tblsalesschedule ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getschedulecode = mCur.getString(0);
            }else{
                getschedulecode = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getschedulecode;
    }
    //Get sales amount for cash report
    public String GetSalesCash(String getschedulecode)
    {
        String getsalescash = "0";
        try{
            String sql ="select coalesce(sum(grandtotal),0) as totalcash from tblsales where " +
                    " schedulecode='"+getschedulecode+"' " +
                    " and billtypecode=1 and flag!=3 and flag!=6 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getsalescash = String.valueOf( mCur.getDouble(0));
            }else{
                getsalescash = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getsalescash;
    }
    //Get receipt amount for cash report
    public String GetReceiptCash(String getschedulecode)
    {
        String getreceiptcash = "0";
        try{
            String sql ="select coalesce(sum(amount),0) from tblreceipt where schedulecode='"+getschedulecode+"' and " +
                    " receiptmode='Cash' and flag!=3 and flag!=6";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getreceiptcash = String.valueOf(mCur.getDouble(0));
            }else{
                getreceiptcash = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getreceiptcash;
    }

    //Get schedule advance amount for cash report
    public String GetScheduleAdvance(String getschedulecode)
    {
        String getadvance = "0";
        try{
            String sql ="select coalesce(tripadvance,0) from tblsalesschedule where schedulecode='"+getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance =String.valueOf( mCur.getDouble(0));
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getadvance;
    }

    //Get schedule advance amount for cash report
    public String GetReceiptAmountSummary(String getschedulecode)
    {
        String getadvance = "0";
        try{
            String sql ="select coalesce(sum(amount),0) from tblreceipt where schedulecode='"+getschedulecode+"' " +
                    " and receiptmode='Cash' and flag!=3 and flag!=6 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance = mCur.getString(0);
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getadvance;
    }

    //Get schedule advance amount for cash report
    public Cursor GetAllCompanyCode()
    {
        Cursor mCur = null;
        try{
            String sql ="select distinct companycode,shortname from tblcompanymaster   ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get GetCompanyDetails
    public Cursor GetCompanyDetails()
    {
        Cursor mCur = null;
        try{
            String sql ="select distinct b.companycode,b.companyname,b.street,b.area,b.city,b.pincode," +
                    " b.telephone,b.mobileno,b.gstin, " +
                    " b.fssaino,b.panno " +
                    " from tblcompanymaster  as b ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get GetCompanyDetails
    public Cursor GetScheduleSummaryDetails(String getschedulecode)
    {
        Cursor mCur = null;
        try{
            String sql =" select (select registrationno from tblvehiclemaster where vehiclecode=a.vehiclecode) as vechiclename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.employeecode) as salesname," +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.drivercode) as drivername" +
                    "  from tblsalesschedule as a where schedulecode='"+getschedulecode+"' limit 1 ";
             mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get GetSummary Sales
    public Cursor GetSalesSummaryDetails(String getschedulecode,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="  select billno,substr((select customernametamil from tblcustomer where customercode = a.customercode),1,50) as customertamil,\n" +
                    " grandtotal,cashpaidstatus from tblsales as a" +
                    " where schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"' and billtypecode='1'" +
                    "  and flag!=3 and flag!=6 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get GetSummary Sales Return
    public Cursor GetSalesReturnSummaryDetails(String getschedulecode,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="  select billno,substr((select customernametamil from tblcustomer where customercode = a.customercode),1,50) as customertamil,\n" +
                    " grandtotal,cashpaidstatus from tblsalesreturn as a" +
                    " where schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"' " +
                    "  and billtypecode='1'  and flag!=3 and flag!=6 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get GetSummary Recipt
    public Cursor GetReceiptSummaryDetails(String getschedulecode,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="  select voucherno,substr((select customernametamil from tblcustomer where customercode = a.customercode),1,50)" +
                    "  as customernametamil,amount,receiptmode from tblreceipt as a " +
                    " where schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"'  and flag!=3 and flag!=6 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor GetFirstSales(String getschedulecode,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(sum(grandtotal),0) as total,(select billno from  tblsales where " +
                    " schedulecode='"+getschedulecode+"'  and companycode='"+getcompanycode+"' and billtypecode='1' " +
                    " order by transactionno asc limit 1 ) as frombillno, " +
                    " (select billno from  tblsales where schedulecode='"+getschedulecode+"'  " +
                    " and companycode='"+getcompanycode+"' and billtypecode='1' " +
                    " order by transactionno desc limit 1 )  as tobillno " +
                    " from tblsales where schedulecode='"+getschedulecode+"' and billtypecode='1' " +
                    "  and companycode='"+getcompanycode+"' and flag!=3 and flag!=6  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get expense amount for cash report
    public String GetExpenseAmount(String getschedulecode)
    {
        String getexpenseamt = "0";
        try{
            String sql ="select coalesce(sum(amount),0) from tblexpenses " +
                    " where schedulecode='"+getschedulecode+"' and flag!=3 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getexpenseamt = String.valueOf(mCur.getDouble(0));
            }else{
                getexpenseamt = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getexpenseamt;
    }
    public String GetSummaryAdvanceAmount(String getschedulecode)
    {
        String getadvance = "0";
        try{
            String sql ="select coalesce(tripadvance,0) from tblsalesschedule " +
                    " where schedulecode='"+getschedulecode+"'   ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance = mCur.getString(0);
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getadvance;
    }

    public String GetSummarySalesAmount(String getschedulecode,String getcompanycode)
    {
        String getadvance = "0";
        try{
            String sql =" select coalesce(sum(grandtotal),0)  as amount from tblsales as a" +
                    " where schedulecode='"+getschedulecode+"' and billtypecode='1' " +
                    " and cashpaidstatus='yes' and companycode='"+getcompanycode+"'  and flag!=3 and flag!=6  ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance = mCur.getString(0);
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       /* String sql =" select coalesce(sum(grandtotal),0)-coalesce((select sum(grandtotal) from tblsales " +
                " where cashpaidstatus='no' and schedulecode='"+getschedulecode+"' " +
                " and companycode='"+getcompanycode+"'),0) as amount from tblsales as a" +
                " where schedulecode='"+getschedulecode+"' and billtypecode='1' and companycode='"+getcompanycode+"'   ";*/


        return getadvance;
    }

    public String GetSummarySalesReturnAmount(String getschedulecode,String getcompanycode)
    {
        String getadvance = "0";
        try{
            String sql =" select coalesce(sum(grandtotal),0)  as amount from tblsalesreturn as a" +
                    " where schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"' and billtypecode='1'" +
                    "  and flag!=3 and flag!=6    ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance = mCur.getString(0);
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getadvance;
    }

    public String GetSummaryReceiptAmount(String getschedulecode,String getcompanycode)
    {
        String getadvance = "0";
        try{
            String sql =" select coalesce(sum(amount),0) - coalesce((select sum(amount) from tblreceipt " +
                    " where receiptmode!='Cash' and schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"'),0)" +
                    " as amount from tblreceipt as a" +
                    " where schedulecode='"+getschedulecode+"' and companycode='"+getcompanycode+"' " +
                    "  and flag!=3 and flag!=6   ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getadvance = mCur.getString(0);
            }else{
                getadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getadvance;
    }

    //Get sales return amount for cash report
    public String GetSalesReturnAmount(String getschedulecode)
    {
        String getsalesreturn = "0";
        try{
            String sql ="select coalesce(sum(grandtotal),0) from tblsalesreturn where schedulecode='"+getschedulecode+"' " +
                    " and flag!=3 and flag!=6 ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getsalesreturn = String.valueOf(mCur.getDouble(0));
            }else{
                getsalesreturn = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getsalesreturn;
    }

    //Get Schedule List
    public Cursor GetScheduleListDB(String getschedulecode)
    {
        Cursor mCur=null;
        try{
            String sql ="select schedulecode,scheduledate,(select vanname from tblvanmaster where vancode =a.vancode) as " +
                    "vanname,(select routenametamil from tblroute where routecode= a.routecode) as routename," +
                    "(select coalesce(vehiclename,'') || ' - ' || coalesce(registrationno,'NIL') as vehiclename from tblvehiclemaster" +
                    " where vehiclecode=a.vehiclecode) as vechiclename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.employeecode) employeename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.drivercode) drivername,helpername," +
                    "tripadvance,startingkm,endingkm,coalesce(lunch_start_time,'') as lunch_start_time ," +
                    " coalesce(lunch_end_time,'') as lunch_end_time from tblsalesschedule as a where scheduledate=datetime('"+getschedulecode+"')" +
                    " and vancode='"+LoginActivity.getvancode+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales List
    public Cursor GetSalesListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getpaymentstaus="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }
            if(paymentstatus.equals("Paid")){
                paymentstatus = "yes";
            }else if(paymentstatus.equals("Not Paid")){
                paymentstatus ="no";
            }else{
                paymentstatus ="0";
            }

            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }
            if(paymentstatus.equals("0")){
                getpaymentstaus = "1=1";
            }if(paymentstatus.equals("yes")){
                getpaymentstaus = "cashpaidstatus='yes'";
            }if(paymentstatus.equals("no")){
                getpaymentstaus = "cashpaidstatus='no'";
            }
            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsales as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "'  and " +
                    " "+getcompany+" and "+getbilltype+" and  "+getpaymentstaus+" order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List
    public Cursor GetSalesOrderListDB(String getdate,String getcompanycode)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getcompany = "";

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname,coalesce(status,'') as status " +
                    "from tblsalesorder as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "'  and " +
                    " "+getcompany+"   order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales List
    public Cursor GetSalesPrintListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getpaymentstaus="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }
            if(paymentstatus.equals("Paid")){
                paymentstatus = "yes";
            }else if(paymentstatus.equals("Not Paid")){
                paymentstatus ="no";
            }else{
                paymentstatus ="0";
            }

            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }
            if(paymentstatus.equals("0")){
                getpaymentstaus = "1=1";
            }if(paymentstatus.equals("yes")){
                getpaymentstaus = "cashpaidstatus='yes'";
            }if(paymentstatus.equals("no")){
                getpaymentstaus = "cashpaidstatus='no'";
            }
            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsales as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  a.flag!=3 and a.flag!=6 and " +
                    " "+getcompany+" and "+getbilltype+" and  "+getpaymentstaus+" order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List
    public Cursor GetSalesBillPrintListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getpaymentstaus="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }
            if(paymentstatus.equals("Paid")){
                paymentstatus = "yes";
            }else if(paymentstatus.equals("Not Paid")){
                paymentstatus ="no";
            }else{
                paymentstatus ="0";
            }

            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }
            if(paymentstatus.equals("0")){
                getpaymentstaus = "1=1";
            }if(paymentstatus.equals("yes")){
                getpaymentstaus = "cashpaidstatus='yes'";
            }if(paymentstatus.equals("no")){
                getpaymentstaus = "cashpaidstatus='no'";
            }
            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    " SUBSTR( (select customername from tblcustomer where customercode=a.customercode),1,15) as customernametamil ," +
                    "SUBSTR( (select areaname from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )),1,15) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsales as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+" and  "+getpaymentstaus+" and a.flag!=3 and a.flag!=6 order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }



    //Get Sales List
    public Cursor GetSalesReturnBillListDB(String getdate,String getcompanycode,String paymenttype)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }


            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    " SUBSTR( (select customername from tblcustomer where customercode=a.customercode),1,15) as customernametamil ," +
                    " SUBSTR( (select areaname from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )),1,15) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsalesreturn as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+"   and a.flag!=3 and a.flag!=6 order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List
    public Cursor GetSalesOrderBillListDB(String getdate)
    {
        Cursor mCur=null;
        try{
            String sql="";

            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    " SUBSTR( (select customername from tblcustomer where customercode=a.customercode),1,15) as customernametamil ," +
                    " SUBSTR( (select areaname from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )),1,15) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsalesorder as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "'    " +
                    "   and a.flag!=3 and a.flag!=6 order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales List
    public Cursor GetSalesBillWiseCompanyListDB(String getdate,String getcompanycode,String paymenttype,
                                                 String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getpaymentstaus="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }
            if(paymentstatus.equals("Paid")){
                paymentstatus = "yes";
            }else if(paymentstatus.equals("Not Paid")){
                paymentstatus ="no";
            }else{
                paymentstatus ="0";
            }

            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }
            if(paymentstatus.equals("0")){
                getpaymentstaus = "1=1";
            }if(paymentstatus.equals("yes")){
                getpaymentstaus = "cashpaidstatus='yes'";
            }if(paymentstatus.equals("no")){
                getpaymentstaus = "cashpaidstatus='no'";
            }
            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select distinct a.companycode,f.companyname, f.companynametamil, f.shortname, f.street, f.area, f.mobileno, " +
                    " f.gstin, f.city, f.telephone, f.panno, f.pincode,a.schedulecode  " +
                    "from tblsales as a inner join tblcompanymaster as f on a.companycode=f.companycode" +
                    "  where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+" and  "+getpaymentstaus+" order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get schedule details
    public Cursor GetBillScheduleDetails(String schedulecode)
    {
        Cursor mCur=null;
        try{
            String sql="";
            sql = "select (select routenametamil from tblroute where routecode=a.routecode) as routename " +
                    ",(select registrationno from tblvehiclemaster where vehiclecode=a.vehiclecode) as vehcilename, " +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.employeecode) as employeenametamil," +
                    "(select employeenametamil from tblemployeemaster where employeecode=a.drivercode) as drivername " +
                    " from tblsalesschedule as a where schedulecode = '"+schedulecode+"' ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List
    public Cursor GetSalesReturnBillWiseCompanyListDB(String getdate,String getcompanycode,String paymenttype,
                                                String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }


            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select distinct a.companycode,f.companyname, f.companynametamil, f.shortname, f.street, f.area, f.mobileno, " +
                    " f.gstin, f.city, f.telephone, f.panno, f.pincode,a.schedulecode  " +
                    "from tblsalesreturn as a inner join tblcompanymaster as f on a.companycode=f.companycode" +
                    "  where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+" order by a.companycode asc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List
    public Cursor GetBillwiseSalesListDB(String getdate,String getcompanycode,String paymenttype,String paymentstatus)
    {
        Cursor mCur=null;
        try{
            String sql="";
            String getbilltype="";
            String getpaymentstaus="";
            String getcompany = "";
            if(paymenttype.equals("All Bills")){
                paymenttype = "0";
            }else if(paymenttype.equals("Cash")){
                paymenttype ="1";
            }else{
                paymenttype ="2";
            }
            if(paymentstatus.equals("Paid")){
                paymentstatus = "yes";
            }else if(paymentstatus.equals("Not Paid")){
                paymentstatus ="no";
            }else{
                paymentstatus ="0";
            }

            if(paymenttype.equals("0")){
                getbilltype = "1=1";
            }if(paymenttype.equals("1")){
                getbilltype = "billtypecode=1";
            }if(paymenttype.equals("2")){
                getbilltype = "billtypecode=2";
            }
            if(paymentstatus.equals("0")){
                getpaymentstaus = "1=1";
            }if(paymentstatus.equals("yes")){
                getpaymentstaus = "cashpaidstatus='yes'";
            }if(paymentstatus.equals("no")){
                getpaymentstaus = "cashpaidstatus='no'";
            }
            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="companycode='"+getcompanycode+"'";
            }
            sql = "select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsales as a where billdate = datetime('" + getdate + "') " +
                    "and vancode = '" + LoginActivity.getvancode + "' and  " +
                    " "+getcompany+" and "+getbilltype+" and  "+getpaymentstaus+" order by transactionno desc ";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get CheckPaymentVoucher
    public Cursor CheckPaymentVoucher()
    {
        Cursor mCur=null;
        try{
            String sql="";

            String getdate= GenCreatedDate();

            sql = "select coalesce(count(*),'0') from tblsales  ";
            Cursor mCur1 = mDb.rawQuery(sql, null);
            if (mCur1.getCount() > 0)
            {
                mCur1.moveToFirst();
            }
            //  if(!mCur1.getString(0).equals("0")) {

            sql = "select billtypecode,billcopystatus,cashpaidstatus,transactionno,financialyearcode," +
                    " bookingno,GROUP_CONCAT(billno),gstin" +
                    " from tblsales as a " +
                    " where " +
                    " vancode = '" + LoginActivity.getvancode + "' and flag!=3 and flag!=6 group by transactionno " +
                    " order by transactionno desc limit 1 ";
            // billdate = datetime('" + getdate + "') and
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

            return mCur;
        /*}else{
            return mCur1;
        }*/

    }

    //Get CheckPaymentVoucher
    public Cursor SalesListPaymentVoucher(String gettransno,String getfinacialyr)
    {
        Cursor mCur = null;
        try{
            String sql="";
            mCur=null;
            sql = "select billtypecode,billcopystatus,cashpaidstatus,transactionno,financialyearcode," +
                    " bookingno,GROUP_CONCAT(billno)" +
                    " from tblsales as a " +
                    " where " +
                    " vancode = '" + LoginActivity.getvancode + "' and flag!=3 and flag!=6 and " +
                    " transactionno = '"+gettransno+"' and financialyearcode='"+getfinacialyr+"' group by transactionno " +
                    " order by transactionno desc limit 1 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;

    }

    //Get Sales List data Details
    public Cursor GetSalesListDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode ))" +
                    "  as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname,bitmapimage," +
                    " (select sum(grandtotal) from tblsales as b where transactionno = '"+gettransactionno+"' and financialyearcode = '"+getfinancialyr+"' ) as totalamt" +
                    " from tblsales as a where transactionno = '"+gettransactionno+"' " +
                    " and financialyearcode = '"+getfinancialyr+"' and companycode='"+getcompanycode+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List data Details
    public Cursor GetSalesOrderListDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areanametamil from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode ))" +
                    "  as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname,bitmapimage," +
                    " (select sum(grandtotal) from tblsalesorder as b where transactionno = '"+gettransactionno+"' and financialyearcode = '"+getfinancialyr+"' ) as totalamt, " +
                    " case when a.transportid!='0' then   (select transportname || ' - ' || (select day_of_dispatch from tbltransportcitymapping " +
                    " where citycode= (select citycode from tblareamaster where areacode =(select areacode from tblcustomer where customercode=a.customercode)) )" +
                    "  from tbltransportmaster where transportid= a.transportid) else  " +
                    " (select transportmodetype from tbltransportmode where transportmodecode=1 ) end  as transport" +
                    " from tblsalesorder as a where transactionno = '"+gettransactionno+"' " +
                    " and financialyearcode = '"+getfinancialyr+"'     ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Expenses List
    public Cursor GetExpensesListDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;

        try{
            String sql ="select companycode,vancode,transactionno,billno,refno,prefix,suffix," +
                    "strftime('%d-%m-%Y',billdate) as billdate,customercode," +
                    " billtypecode,gstin,schedulecode," +
                    "subtotal,discount,grandtotal,billcopystatus,cashpaidstatus,financialyearcode,bookingno,flag," +
                    "(select customername from tblcustomer where customercode=a.customercode) as customername," +
                    "(select customernametamil from tblcustomer where customercode=a.customercode) as customernametamil ," +
                    "(select areaname from tblareamaster where areacode=(select areacode from tblcustomer where customercode=a.customercode )) as areaname," +
                    "(select cityname from tblcitymaster where citycode=(select citycode from tblareamaster where areacode=" +
                    "(select areacode from tblcustomer where customercode=a.customercode ))) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname " +
                    "from tblsales as a where transactionno = '"+gettransactionno+"' " +
                    " and financialyearcode = '"+getfinancialyr+"' and companycode='"+getcompanycode+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List data Details
    public Cursor GetSalesListItemDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select a.itemcode,b.itemnametamil,a.qty,a.weight,a.price,a.discount,a.amount,a.freeitemstatus ," +
                    "(select unitname from tblunitmaster where unitcode=b.unitcode) as unitname," +
                    "(select hsn from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as hsn," +
                    "(select tax from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as tax," +
                    " coalesce((Select noofdecimals from tblunitmaster where unitcode=b.unitcode),0) as noofdecimals," +
                    " coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " from tblsalesitemdetails as a inner join tblitemmaster as b on a.itemcode=b.itemcode" +
                    " where a.transactionno='"+gettransactionno+"' and a.companycode='"+getcompanycode+"' " +
                    " and a.financialyearcode='"+getfinancialyr+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales List data Details
    public Cursor GetSalesOrderListItemDatasDB(String gettransactionno,String getfinancialyr,String getcompanycode)
    {
        Cursor mCur = null;
        try{
            String sql ="select a.itemcode,b.itemnametamil,a.qty,a.weight,a.price,a.discount,a.amount,a.freeitemstatus ," +
                    "(select unitname from tblunitmaster where unitcode=b.unitcode) as unitname," +
                    "(select hsn from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as hsn," +
                    "(select tax from tblitemsubgroupmaster where itemsubgroupcode=b.itemsubgroupcode) as tax," +
                    " coalesce((Select noofdecimals from tblunitmaster where unitcode=b.unitcode),0) as noofdecimals," +
                    " coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " from tblsalesorderitemdetails as a inner join tblitemmaster as b on a.itemcode=b.itemcode" +
                    " where a.transactionno='"+gettransactionno+"'   " +
                    " and a.financialyearcode='"+getfinancialyr+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Schedule Datas
    public Cursor GetScheduleDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesschedule  where coalesce(flag,0)=0";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Customer Datas
    public Cursor GetCustomerDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblcustomer where flag=1 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Customer Datas
    public Cursor GetWholeCustomerDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select * from tblcustomer as a   where  strftime('%Y-%m-%d',a.createddate)='"+getdate+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Order Datas
    public Cursor GetOrderDetailsDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblorderdetails where flag=1 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Expense Datas
    public Cursor GetExpensesDetailsDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblexpenses where (flag=1 or syncstatus=0) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Cash report
    public Cursor GetCashReportDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select autonum,schedulecode,vancode,sales,salesreturn,advance,receipt,expenses,cash,denominationcash,makerid,createddate from tblcashreport where flag=1  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get close cash report
    public Cursor GetCloseSalesDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select autonum,closedate,vancode,schedulecode,makerid,createddate,paidparties,expenseentries from tblclosecash where flag=1 and status='2'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Denomination
    public Cursor GetDenominationDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tbldenomination where flag=1  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Ending km
    public Cursor GetEndingKmScheduleDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select endingkm,schedulecode from tblsalesschedule where schedulecode in " +
                    " (select schedulecode from tblclosecash )  ";
            mCur = mDb.rawQuery(sql,null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Receipt Datas
    public Cursor GetReceiptDetailsDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblreceipt where (flag=1 or syncstatus=0) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Expense Datas
    public Cursor GetCancelExpensesDetailsDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblexpenses where flag=3 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Receipt Datas
    public Cursor GetCancelReceiptDetailsDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblreceipt where flag=3 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales Datas
    public Cursor GetSalesDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsales where (flag in (1,3,4)) and syncstatus=0 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Datas
    public Cursor GetWholeSalesDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate =GenCreatedDate();
            String sql ="select * from tblsales where  billdate = datetime('" + getdate + "')  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales Datas
    public Cursor GetSalesOrderDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesorder where (flag in (1,3,4)) and syncstatus=0 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales Datas
    public Cursor GetSalesReceiptDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsales where flag=4 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

      //Get Sales Item Datas
    public Cursor GetSalesItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql = "select * from tblsalesitemdetails where flag in (1,3)";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        // String sql ="select * from tblsalesitemdetails where transactionno in" +
        //" (select transactionno from tblsales where flag=1 or syncstatus=0) ";

        return mCur;
    }
    //Get Sales Item Datas
    public Cursor GetWholeSalesItemDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql = "select * from tblsalesitemdetails as a   where strftime('%Y-%m-%d',a.createddate)='"+getdate+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        // String sql ="select * from tblsalesitemdetails where transactionno in" +
        //" (select transactionno from tblsales where flag=1 or syncstatus=0) ";

        return mCur;
    }

    //Get Sales Item Datas
    public Cursor GetSalesOrderItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql = "select * from tblsalesorderitemdetails where flag in (1,3)";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        // String sql ="select * from tblsalesitemdetails where transactionno in" +
        //" (select transactionno from tblsales where flag=1 or syncstatus=0) ";

        return mCur;
    }
    //Get Stock transaction Datas
    public Cursor GetStockTransactionDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select transactionno,transactiondate,vancode,itemcode,inward,outward,type," +
                    " refno,createddate,flag,companycode,op,financialyearcode,autonum from tblstocktransaction where flag=1 and type='salesreturn' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Stock transaction Datas
    public Cursor GetSalesStockTransactionDatasDB()
    {
        Cursor mCur = null;

        try{
            getdate = GenCreatedDate();
            String sql ="select * from tblsalesstockconversion as a   where  strftime('%Y-%m-%d',a.transactiondate) ='"+getdate+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales cancel Datas
    public Cursor GetSalesCancelDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsales where flag=3 and syncstatus=0  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales cancel Datas
    public Cursor GetWholeSalesCancelDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsales where (flag=3 or flag=6)   ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales cancel Datas
    public Cursor GetSalesOrderCancelDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesorder where flag=3 and syncstatus=0  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales cancel Datas
    public Cursor GetSalesCancelItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select b.* from tblsales as a inner join tblsalesitemdetails as b on a.transactionno=b.transactionno " +
                    "and a.companycode=b.companycode and a.vancode=b.vancode where a.flag=3 and a.syncstatus=0  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get Sales cancel Datas
    public Cursor GetWholeSalesCancelItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select b.* from tblsales as a inner join tblsalesitemdetails as b on a.transactionno=b.transactionno " +
                    "and a.companycode=b.companycode and a.vancode=b.vancode where a.flag=3   ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get Sales cancel Datas
    public Cursor GetSalesOrderCancelItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select b.* from tblsalesorder as a inner join " +
                    " tblsalesorderitemdetails as b on a.transactionno=b.transactionno and a.companycode=b.companycode " +
                    " and a.vancode=b.vancode where a.flag=3 and a.syncstatus=0  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get cancel Stock transaction Datas
    public Cursor GetCancelStockTransactionDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select transactionno,transactiondate,vancode,itemcode,inward,outward,type, " +
                    "refno,createddate,flag,companycode,op,financialyearcode,'1' as autonum from tblappstocktransactiondetails as a where" +
                    "   type='salescancel' and  strftime('%Y-%m-%d',a.transactiondate)='"+getdate+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get cancel Stock transaction Datas
    public Cursor GetWholeCancelStockTransactionDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select transactionno,transactiondate,vancode,itemcode,inward,outward,type, " +
                    "refno,createddate,flag,companycode,op,financialyearcode,'1' as autonum from tblappstocktransactiondetails as a where" +
                    "   type='salescancel' and  strftime('%Y-%m-%d',a.transactiondate)='"+getdate+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get cancel Stock transaction Datas
    public Cursor GetWholeStockConversionDatasDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select * from tblsalesstockconversion as a   where  strftime('%Y-%m-%d',a.transactiondate) ='"+getdate+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get cancel Stock transaction Datas
    public Cursor GetCancelReturnStockTransactionDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select transactionno,transactiondate,vancode,itemcode,inward,outward,type, refno,createddate,flag,companycode,op,financialyearcode,autonum from tblstocktransaction where flag=1 and type='salesreturncancel' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Update Sales Flag
    public void UpdateSalesFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsales set flag=2 ,syncstatus=1 where" +
                    " transactionno='" + gettransactiono + "' and (flag=1 or flag=4) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update Sales Flag
    public void UpdateSalesOrderFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesorder set flag=2 ,syncstatus=1 where" +
                    " transactionno='" + gettransactiono + "' and (flag=1 or flag=4) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Sales Flag
    public void UpdateCancelSalesFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsales set flag=6,syncstatus=1 where transactionno='" + gettransactiono + "' and flag=3 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }

    //Update Sales Flag
    public void UpdateOrderCancelSalesFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesorder set flag=6,syncstatus=1 where transactionno='" + gettransactiono + "' and flag=3 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }
    //Update Sales Item Flag
    public void UpdateSalesItemFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesitemdetails set flag=2 where transactionno='"+gettransactiono+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Sales Item Flag
    public void UpdateSalesOrderItemFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesorderitemdetails set flag=2 where transactionno='"+gettransactiono+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update stock transaction Flag
    public void UpdateStockTransactionFlag(String gettransactiono)
    {
        try{
            String sql = "update tblstocktransaction set flag=2 where refno='"+gettransactiono+"' and type='salesreturn' ";
            mDb.execSQL(sql);
            String sql1 = "update tblappstocktransactiondetails set flag=2 and syncstatus=1 " +
                    " where refno='"+gettransactiono+"' and type='salesreturn' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }
    public void UpdateSalesStockTransactionFlag(String getrefno,String gettransactiono)
    {
        try{
            String sql = "update tblsalesstockconversion set flag=2 where refno='"+getrefno+"' and (type='stockconversion')" +
                    "  and transactionno='"+gettransactiono+"' ";
            mDb.execSQL(sql);
            String sql1 = "update tblappstocktransactiondetails set flag=2 and syncstatus=1 " +
                    " where refno='"+getrefno+"' and ( type='stockconversion') ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    public void UpdateCancelSalesStockTransactionFlag(String gettransactiono)
    {
        try{
            String sql = "update tblstocktransaction set flag=2 where refno='"+gettransactiono+"' and type='salescancel' ";
            mDb.execSQL(sql);
            String sql1 = "update tblappstocktransactiondetails set flag=2 and syncstatus=1 " +
                    " where refno='"+gettransactiono+"' and type='salescancel' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }
    public void UpdateCancelSalesReturnStockTransactionFlag(String gettransactiono)
    {
        try{
            String sql = "update tblstocktransaction set flag=2 where refno='"+gettransactiono+"'" +
                    " and type='salesreturncancel' ";
            mDb.execSQL(sql);
            String sql1 = "update tblappstocktransactiondetails set flag=2 and syncstatus=1 " +
                    " where refno='"+gettransactiono+"' and type='salesreturncancel' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }

    //Update Sales Cancel Flag
    public String UpdateSalesCancelFlag(String gettransactiono,String getfinancialyrcode)
    {
        try{
            String sql = "update tblsales set flag=3,syncstatus=0 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql);

            String sql1 = "update tblsalesitemdetails set flag=3 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }

    //Update Sales Cancel Flag
    public String UpdateSalesOrderCancelFlag(String gettransactiono,String getfinancialyrcode)
    {
        try{
            String sql = "update tblsalesorder set flag=3,syncstatus=0 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql);

            String sql1 = "update tblsalesorderitemdetails set flag=3 where transactionno='"+gettransactiono+"' and " +
                    " financialyearcode='"+getfinancialyrcode+"' and vancode='"+LoginActivity.getvancode+"'  ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }

    //Update Sales Stock transaction
    public String UpdateSalesStockTransaction(String gettransactiono,String getfinancialyrcode)
    {
        try{
            String GetDate= GenCreatedDate();
            String sql = " insert into tblstocktransaction (transactionno,transactiondate,vancode," +
                    "  itemcode,inward,outward,type,refno,flag,createddate,companycode,op,financialyearcode,autonum)" +
                    "select (select coalesce(max(transactionno),0)+1 from tblstocktransaction),datetime('"+GetDate+"')," +
                    "vancode,itemcode,0,'-'||qty,'salescancel',transactionno,1,datetime('now', 'localtime'),companycode ,0,'"+getfinancialyrcode+"',(select coalesce(max(autonum),0)+1 from tblstocktransaction)+(select count(*) from tblsalesitemdetails b  " +
                    "where transactionno='"+gettransactiono+"' and financialyearcode='"+getfinancialyrcode+"' and a.autonum >= b.autonum) " +
                    " from tblsalesitemdetails as a where transactionno='"+gettransactiono+"' " +
                    "and financialyearcode='"+getfinancialyrcode+"'  ";
            mDb.execSQL(sql);

            String sql1 = " insert into tblappstocktransactiondetails (transactionno,transactiondate,vancode," +
                    "  itemcode,inward,outward,type,refno,flag,createddate,companycode,op,financialyearcode,syncstatus)" +
                    "select (select coalesce(max(transactionno),0)+1 from tblappstocktransactiondetails),datetime('"+GetDate+"')," +
                    "vancode,itemcode,0,'-'||qty,'salescancel',transactionno,1,datetime('"+GetDate+"'),companycode ,0," +
                    " '"+getfinancialyrcode+"',0 " +
                    " from tblsalesitemdetails where transactionno='"+gettransactiono+"' " +
                    "and financialyearcode='"+getfinancialyrcode+"'  ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

      /*  String sql = " UPDATE tblstocktransaction set flag=3 " +
                "  where refno='"+gettransactiono+"' " +
                "and financialyearcode='"+getfinancialyrcode+"' and type='sales' ";
        mDb.execSQL(sql);
        String sql1 = " UPDATE tblappstocktransactiondetails set flag=3 and syncstatus=0 " +
                "  where refno='"+gettransactiono+"' " +
                "and financialyearcode='"+getfinancialyrcode+"' and type='sales' ";
        mDb.execSQL(sql1);*/
        return "success";
    }
    //Get vehicle
    public Cursor GetVehicleDB()
    {
        Cursor mCur = null;
        try{
            String sql ="";
            if(LoginActivity.getbusiness_type.equals("2")){
                sql ="select vehiclecode,vehiclename ,modelandyear,registrationno,capacity,fc,permit,insurance,documentupload," +
                        " status from tblvehiclemaster where status='"+statusvar+"' and vehiclecode='0' order by vehiclename ";
            }else {
                sql = "select vehiclecode,vehiclename || ' - ' || registrationno as vehiclename ,modelandyear,registrationno,capacity,fc,permit,insurance,documentupload," +
                        " status from tblvehiclemaster where status='" + statusvar + "' and vehiclecode !='0' order by vehiclename ";
            }
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Rep
    public Cursor GetSalesRepDB()
    {
        Cursor mCur = null;
        try{
            String sql ="";
           /* if(LoginActivity.getbusiness_type.equals("2")){
                sql ="select employeecategorycode,employeecode,employeename,employeenametamil,mobileno,documentupload from " +
                        "tblemployeemaster where employeecode='0' and status='"+statusvar+"' order by employeenametamil ";
            }else {*/
                sql = "select employeecategorycode,employeecode,employeename,employeenametamil,mobileno,documentupload from " +
                        "tblemployeemaster where employeecode !='0' and employeecategorycode=1 and status='" + statusvar + "' order by employeenametamil ";
           // }
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Driver
    public Cursor GetDriverDB()
    {
        Cursor mCur = null;
        try{
            String sql="";
            if(LoginActivity.getbusiness_type.equals("2")){
                sql ="select employeecategorycode,employeecode,employeename,employeenametamil,mobileno,documentupload from " +
                        "tblemployeemaster where employeecode='0' and status='"+statusvar+"' order by employeenametamil ";
            }else {
                sql = "select employeecategorycode,employeecode,employeename,employeenametamil,mobileno,documentupload from " +
                        "tblemployeemaster where employeecode !='0' and employeecategorycode=2 and status='" + statusvar + "' order by employeenametamil ";
            }
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get area based on route
    public Cursor GetCustomerDB(String areacode)
    {
        Cursor mCur = null;
        try{
            String sql = "";
            if(LoginActivity.getbusiness_type.equals("2")) {
                sql = "select customercode,customername,customernametamil,address,areacode,emailid,mobileno,telephoneno," +
                        " aadharno,gstin,schemeapplicable,coalesce(customertypecode,'1')  from tblcustomer " +
                        " where areacode = '" + areacode + "' and status='" + statusvar + "' and (business_type='2' or business_type='3') " +
                        " order by customernametamil ";
            }
            else if(LoginActivity.getbusiness_type.equals("1")) {
                sql = "select customercode,customername,customernametamil,address,areacode,emailid,mobileno,telephoneno," +
                        " aadharno,gstin,schemeapplicable,coalesce(customertypecode,'1')  from tblcustomer " +
                        " where areacode = '" + areacode + "' and status='" + statusvar + "' and (business_type='1' or business_type='3') " +
                        " order by customernametamil ";
            }else {
                sql = "select customercode,customername,customernametamil,address,areacode,emailid,mobileno,telephoneno," +
                        " aadharno,gstin,schemeapplicable,coalesce(customertypecode,'1')  from" +
                        " tblcustomer where areacode = '" + areacode + "' and status='" + statusvar + "' and (business_type='1' or business_type='2' " +
                        " or business_type='3') " +
                        " order by customernametamil ";
            }
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get sub group based on stock transfer items
    public Cursor GetSubGroupDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            /*and a.transactiondate=datetime('"+getdate+"')*/
            String sql =" select * from (select  c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil, " +
                    " c.itemgroupcode,sum(op)+sum(inward)-sum(outward) as closing from tblstocktransaction as a inner join tblitemmaster  " +
                    " as b on a.itemcode = b.itemcode inner join tblitemsubgroupmaster as c on " +
                    " c.itemsubgroupcode=b.itemsubgroupcode where a.vancode='"+LoginActivity.getvancode+"'" +
                    "  and b.status='"+statusvar+"' " +
                    " and c.Status='"+statusvar+"'  and a.flag!=3 " +
                    " group by c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil,c.itemgroupcode ) as dev where dev.closing>0 " +
                    " order by dev.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public Cursor GetAllGroupDB(){
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            /* " and a.transactiondate=datetime('"+getdate+"') " +*/
            String sql =" SELECT * from ( select  d.itemgroupcode,d.itemgroupname,d.itemgroupnametamil " +
                    " from   tblitemmaster  as b inner join tblitemsubgroupmaster as c   on c.itemsubgroupcode=b.itemsubgroupcode " +
                    " inner join tblitemgroupmaster as d      on d.itemgroupcode = c.itemgroupcode where b.status='"+statusvar+"' and" +
                    " c.Status='"+statusvar+"' and  d.status ='"+statusvar+"' group by d.itemgroupcode,d.itemgroupname,d.itemgroupnametamil  )  " +
                    " as dev  order by dev.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get group based on sub group
    public Cursor GetAllSubGroup_GroupDB(String itemgroupcode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select distinct c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil,c.itemgroupcode from " +
                    "    tblitemmaster  as b   inner join  " +
                    " tblitemsubgroupmaster as c on c.itemsubgroupcode=b.itemsubgroupcode where " +
                    "   c.itemgroupcode='"+itemgroupcode+"' " +
                    " and b.status='"+statusvar+"' and c.Status='"+statusvar+"'  " +
                    "    order by c.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/

        return mCur;
    }
    //Get sub group based on stock transfer items
    public Cursor GetGroupDB()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            /* " and a.transactiondate=datetime('"+getdate+"') " +*/
            String sql =" select * from ( select  d.itemgroupcode,d.itemgroupname,d.itemgroupnametamil, " +
                    "sum(op)+sum(inward)-sum(outward) as closing from tblstocktransaction  " +
                    "as a inner join tblitemmaster  as b on a.itemcode = b.itemcode inner join tblitemsubgroupmaster as c " +
                    "on c.itemsubgroupcode=b.itemsubgroupcode inner join tblitemgroupmaster as d   " +
                    "on d.itemgroupcode = c.itemgroupcode where a.vancode='"+LoginActivity.getvancode+"'  " +
                    "and b.status='"+statusvar+"' and c.Status='"+statusvar+"' and a.flag!=3 and  d.status ='"+statusvar+"'" +
                    " group by d.itemgroupcode,d.itemgroupname,d.itemgroupnametamil  ) as dev where dev.closing>0  " +
                    "  order by dev.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get group based on sub group
    public Cursor GetSubGroup_GroupDB(String itemgroupcode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
           /* String sql =" select * from (select  c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil, " +
                    " c.itemgroupcode,sum(op)+sum(inward)-sum(outward) as closing from tblstocktransaction as a inner join tblitemmaster  " +
                    " as b on a.itemcode = b.itemcode inner join tblitemsubgroupmaster as c on " +
                    " c.itemsubgroupcode=b.itemsubgroupcode where a.vancode='"+LoginActivity.getvancode+"'" +
                    "  and c.itemgroupcode='"+itemgroupcode+"'  and b.status='"+statusvar+"' " +
                    " and c.Status='"+statusvar+"'  and a.flag!=3 " +
                    " group by c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil,c.itemgroupcode ) as dev where dev.closing>0 " +
                    " order by dev.itemgroupcode ";
*/
            String sql ="select distinct c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil from " +
                    " tblstocktransaction as a inner join tblitemmaster  as b on a.itemcode = b.itemcode inner join  " +
                    "tblitemsubgroupmaster as c on c.itemsubgroupcode=b.itemsubgroupcode where " +
                    " a.vancode='"+LoginActivity.getvancode+"' and c.itemgroupcode='"+itemgroupcode+"' " +
                    "and b.status='"+statusvar+"' and c.Status='"+statusvar+"'  " +
                    "    order by c.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/

        return mCur;
    }
    //Get group based on sub group
    public Cursor GetSubGroup_GroupOrderDB(String itemgroupcode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select distinct c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil from " +
                    "   tblitemmaster  as b inner join  " +
                    "tblitemsubgroupmaster as c on c.itemsubgroupcode=b.itemsubgroupcode where " +
                    "  c.itemgroupcode='"+itemgroupcode+"' " +
                    "and b.status='"+statusvar+"' and c.Status='"+statusvar+"'  " +
                    "    order by c.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/

        return mCur;
    }
    //Get Sales items for cart
    public Cursor GetSalesItemsCart()
    {
        Cursor mCur = null;
        try{
            /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/
            getdate = GenCreatedDate();
            String sql ="select * from tblsalescartdatas order by cartcode asc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales items for cart
    public Cursor GetSalesOrderItemsCarts()
    {
        Cursor mCur = null;
        try{
            /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/
            getdate = GenCreatedDate();
            String sql ="select * from tblsalesordercartdatas order by cartcode asc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales items for cart
    public Cursor GetSalesOrderItemsCart()
    {
        Cursor mCur = null;
        try{
            /*  "  and a.transactiondate=datetime('"+getdate+"') " +*/
            getdate = GenCreatedDate();
            String sql ="select * from tblsalesordercartdatas order by cartcode asc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Items
    public Cursor GetItemsDB(String itemsubgroupcode,String getroutecode,String getareacode)
    {
        Cursor mCur = null;
        try{
            /*and b.transactiondate=datetime('"+getdate+"')*/
            String getdate = GenCreatedDate();
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }

            String getitembusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getitembusinesstype=" (a.business_type = 2 or a.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getitembusinesstype="(a.business_type = 1 or a.business_type = 3)";
            }else{
                getitembusinesstype="(a.business_type = 1 or  a.business_type = 2 or a.business_type = 3)";
            }
        /*String sql =" select a.itemcode,a.companycode,a.brandcode,a.manualitemcode,a.itemname,a.itemnametamil,a.unitcode," +
                " a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight,a.itemcategory,a.parentitemcode," +
                " a.allowpriceedit,a.allownegativestock,a.allowdiscount, (sum(b.op)+sum(b.inward)-sum(b.outward)) as stockqty," +
                " (Select unitname  from tblunitmaster where unitcode=a.unitcode) as unitname," +
                " coalesce((Select noofdecimals from tblunitmaster where unitcode=a.unitcode),0) as noofdecimals," +
                " coalesce((select oldprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                " order by autonum desc limit 1),0) as oldprice,coalesce((select newprice from tblitempricelisttransaction" +
                " where itemcode=a.itemcode order by autonum desc limit 1),0) as newprice,coalesce((select colourcode " +
                " from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode,coalesce(c.hsn,'') " +
                " as hsn,coalesce(c.tax,'') as tax,(select allowpriceedit from tblroutedetails where routecode='"+getroutecode+"' and areacode='"+getareacode+"')" +
                " as routeallowpricedit,case when parentitemcode=0 then a.itemcode else parentitemcode " +
                " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder," +
                " c.itemsubgroupname,d.brandname " +
                " from tblitemmaster as a inner join tblstocktransaction as b " +
                " on a.itemcode=b.itemcode inner join tblitemsubgroupmaster as c on" +
                " c.itemsubgroupcode=a.itemsubgroupcode inner join tblbrandmaster as d on a.brandcode=d.brandcode " +
                " where a.itemsubgroupcode ='"+itemsubgroupcode+"' and a.status='"+statusvar+"' " +
                " and b.vancode='"+LoginActivity.getvancode+"' and" +
                " a.companycode in (select companycode from tblcompanymaster where status='"+statusvar+"') " +
                " group by a.itemcode,a.companycode,a.brandcode,a.manualitemcode," +
                " a.itemname,a.itemnametamil,a.unitcode,a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight," +
                " a.itemcategory,a.parentitemcode,a.allowpriceedit,a.allownegativestock,a.allowdiscount" +
                " order by c.itemsubgroupname,d.brandname,parentcode,itemorder,a.itemname ";*/
            String sql = "select * from (select a.itemcode,a.companycode,a.brandcode,a.manualitemcode,a.itemname,a.itemnametamil,a.unitcode," +
                    " a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight,a.itemcategory,a.parentitemcode," +
                    " a.allowpriceedit,a.allownegativestock,a.allowdiscount, " +
                    " coalesce(coalesce((select sum(op)+sum(inward)-Sum(outward) from tblstocktransaction where itemcode=a.itemcode" +
                    " and vancode='"+LoginActivity.getvancode+"' and flag!=3),0) + coalesce((select sum(inward)-Sum(outward) from tblstockconversion where itemcode=a.itemcode "  +
                    " and vancode='"+LoginActivity.getvancode+"'  ),0),0)" +
                    " as stockqty," +

                    " (Select unitname  from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    " coalesce((Select noofdecimals from tblunitmaster where unitcode=a.unitcode),0) as noofdecimals," +
                    " coalesce((select oldprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    " order by autonum desc limit 1),0) as oldprice,coalesce((select newprice from tblitempricelisttransaction " +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as newprice,coalesce((select colourcode " +
                    " from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode,coalesce(c.hsn,'') " +
                    " as hsn,coalesce(c.tax,'') as tax,(select allowpriceedit from tblroutedetails where routecode='"+getroutecode+"' and areacode='"+getareacode+"')" +
                    " as routeallowpricedit,case when parentitemcode=0 then a.itemcode else parentitemcode " +
                    " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder," +
                    " c.itemsubgroupname,d.brandname,(select count(*) from tblschemeratedetails as aa inner join " +
                    "  tblscheme as b on aa.schemecode=b.schemecode where aa.itemcode=a.itemcode and b.status='"+statusvar+"' " +
                    "  and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' " +
                    "  and(validityfrom<=datetime('"+getdate+"')) and (ifnull(validityto,'')='' or " +
                    " (validityfrom<=datetime('"+getdate+"') " +
                    " and  validityto>=datetime('"+getdate+"'))) and  "+getbusinesstype+") as ratecount," +
                    " (select count(*) from tblschemeitemdetails as ab  inner join  tblscheme as b " +
                    " on ab.schemecode=b.schemecode where ab.purchaseitemcode=a.itemcode and b.status='"+statusvar+"' and (','||multipleroutecode||',') " +
                    " LIKE '%,"+getroutecode+",%' and(validityfrom<=datetime('"+getdate+"')) and (ifnull(validityto,'')='' or (validityfrom<=datetime('"+getdate+"') " +
                    " and  validityto>=datetime('"+getdate+"')))  and "+getbusinesstype+" ) as freecount, " +
                    " coalesce(coalesce((select sum(op)+sum(inward)-Sum(outward) from tblstocktransaction where itemcode=a.parentitemcode " +
                    " and vancode='"+LoginActivity.getvancode+"' and flag!=3),0) + " +
                    " coalesce((select sum(inward)-Sum(outward) from tblstockconversion where itemcode=a.parentitemcode " +
                    " and vancode='"+LoginActivity.getvancode+"'  ),0),0) " +
                    " as parentstockqty "+
                    " from tblitemmaster as a  inner join tblitemsubgroupmaster as c on " +
                    " c.itemsubgroupcode=a.itemsubgroupcode inner join tblbrandmaster as d on a.brandcode=d.brandcode " +
                    " where  a.itemsubgroupcode ='"+itemsubgroupcode+"' and a.status='"+statusvar+"'  " +
                    " and (a.itemcode in (select itemcode from tblstocktransaction where  flag!=3) " +
                    " or parentcode in (select itemcode from tblstocktransaction where  flag!=3)) and " +
                    " a.companycode in (select companycode from tblcompanymaster where status='"+statusvar+"' ) ) as dec                " +
                    " where (itemcategory='child'  and (parentstockqty>0 or stockqty>0) ) or (itemcategory= 'parent' and stockqty>0 )   " +
                    " order by   itemcategory desc,uppweight desc";

            //brandname
             mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get Scheme Details
    public Cursor GetSchemeFORItemDB(String getitemcode,String getroutecode,String getqty)
    {
        Cursor mCur = null;
        try{
            String GenDate= GenCreatedDate();
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }
            String sql ="select coalesce(a.minqty,0) as minqty,coalesce(a.discountamount,0) as discountamount from tblschemeratedetails as a inner join " +
                    " tblscheme as b on a.schemecode=b.schemecode where a.itemcode='"+getitemcode+"'" +
                    " and b.status='"+statusvar+"' and "+getbusinesstype+" and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' and" +
                    "(validityfrom<=datetime('"+GenDate+"')) " +
                    "and (ifnull(validityto,'')='' " +
                    "or (validityfrom<=datetime('"+GenDate+"') and  validityto>=datetime('"+GenDate+"')))  and  a.minqty <='"+getqty+"' order by minqty desc limit 1 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Scheme Details
    public Cursor GetOrderSchemeFORItemDB(String getitemcode,String getroutecode,String getqty)
    {
        Cursor mCur = null;
        try{
            String GenDate= GenCreatedDate();
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }
            String sql ="select coalesce(a.minqty,0) as minqty,coalesce(a.discountamount,0) as discountamount from tblschemeratedetails as a inner join " +
                    " tblscheme as b on a.schemecode=b.schemecode where a.itemcode='"+getitemcode+"' " +
                    "and b.status='"+statusvar+"' and "+getbusinesstype+" and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' and" +
                    "(validityfrom<=datetime('"+GenDate+"')) " +
                    "and (ifnull(validityto,'')='' " +
                    "or (validityfrom<=datetime('"+GenDate+"') and  validityto>=datetime('"+GenDate+"'))) " +
                    " and  a.minqty <='"+getqty+"' order by minqty desc limit 1 ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Scheme  Free Item Details
    public Cursor GetSchemeFORFreeItemDB(String getitemcode,String getroutecode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }
            String GenDate= GenCreatedDate();
            String sql ="select purchaseitemcode,purchaseqty,freeitemcode,freeqty from tblschemeitemdetails as a  inner join " +
                    " tblscheme as b on a.schemecode=b.schemecode where a.purchaseitemcode='"+getitemcode+"'" +
                    " and b.status='"+statusvar+"'  and "+getbusinesstype+" and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' and" +
                    "(validityfrom<=datetime('"+GenDate+"')) " +
                    "and (ifnull(validityto,'')='' " +
                    "or (validityfrom<=datetime('"+GenDate+"') and  validityto>=datetime('"+GenDate+"'))) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Scheme  Free Item Details
    public Cursor GetOrderSchemeFORFreeItemDB(String getitemcode,String getroutecode)
    {
        Cursor mCur = null;
        try{
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (b.business_type = 2 or b.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(b.business_type = 1 or b.business_type = 3)";
            }else{
                getbusinesstype="(b.business_type = 1 or  b.business_type = 2 or b.business_type = 3)";
            }
            String GenDate= GenCreatedDate();
            String sql ="select purchaseitemcode,purchaseqty,freeitemcode,freeqty from tblschemeitemdetails as a  inner join " +
                    " tblscheme as b on a.schemecode=b.schemecode where a.purchaseitemcode='"+getitemcode+"'" +
                    " and b.status='"+statusvar+"' and "+getbusinesstype+" and (','||multipleroutecode||',') LIKE '%,"+ getroutecode +",%' and" +
                    "(validityfrom<=datetime('"+GenDate+"')) " +
                    "and (ifnull(validityto,'')='' " +
                    "or (validityfrom<=datetime('"+GenDate+"') and  validityto>=datetime('"+GenDate+"'))) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Stock for parent item details
    public Cursor GetStockForItem(String getitemcode)
    {
        Cursor mCur = null;
        try{
            String sql ="select (coalesce(sum(a.op)+sum(a.inward)-sum(a.outward),0))+" +
                    " (select coalesce((sum(inward)-sum(outward)),0) from tblstockconversion where itemcode='"+getitemcode+"' )" +
                    " as stock,b.itemnametamil," +
                    "(select unitname from tblunitmaster where unitcode=b.unitcode) as unitname,coalesce(b.upp,0) as upp " +
                    " from tblstocktransaction as a inner join tblitemmaster as b on a.itemcode=b.itemcode  " +
                    " where a.itemcode='"+getitemcode+"' and vancode='"+LoginActivity.getvancode+"' and a.flag!=3  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Stock for parent item details
    public String GetCartItemStock(String getitemcode)
    {
        String getqty = "0";
        try{
            String sql ="select coalesce(itemqty,0) from tblsalescartdatas where itemcode = '"+getitemcode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getqty = mCur.getString(0);
            }else{
                getqty = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getqty;
    }

    //Get Stock for parent item details
    public String GetCartOrderItemStock(String getitemcode)
    {
        String getqty = "0";
        try{
            String sql ="select coalesce(itemqty,0) from tblsalesordercartdatas where itemcode = '"+getitemcode+"' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getqty = mCur.getString(0);
            }else{
                getqty = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getqty;
    }

    //Get Item qty and price
    public Cursor GetCartItemQtyAndPrice(String getitemcode)
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(itemqty,0),coalesce(newprice,0) " +
                    " from tblsalescartdatas where itemcode = '"+getitemcode+"' ";
            mCur = mDb.rawQuery(sql, null);
            String getqty = "0";
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Item qty and price
    public Cursor GetCartOrderItemQtyAndPrice(String getitemcode)
    {
        Cursor mCur = null;
        try{
            String sql ="select coalesce(itemqty,0),coalesce(newprice,0) " +
                    " from tblsalesordercartdatas where itemcode = '"+getitemcode+"' ";
            mCur = mDb.rawQuery(sql, null);
            String getqty = "0";
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Stock for parent item details
    public String GetFreeCartItemStock(String getitemcode)
    {
        String getqty = "0";
        try{
            String sql ="select coalesce(itemqty,0) from tblsalescartdatas where itemcode = '"+getitemcode+"' and freeflag !='' ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getqty = mCur.getString(0);
            }else{
                getqty = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getqty;
    }


    //Get Purchase Items
    public Cursor GetPurchaseItems(String itemcode,String getroutecode,String getareacode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select a.itemcode,a.companycode,a.brandcode,a.manualitemcode,a.itemname,a.itemnametamil,a.unitcode," +
                    "a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight,a.itemcategory,a.parentitemcode," +
                    "a.allowpriceedit,a.allownegativestock,a.allowdiscount, " +
                    "(select coalesce((sum(op)+sum(inward)-sum(outward)),0) from tblstocktransaction where itemcode='"+itemcode+"' and flag!=3 ) " +
                    " + (select coalesce((sum(inward)-sum(outward)),0) from tblstockconversion where itemcode='"+itemcode+"' ) as stockqty," +
                    "(Select unitname  from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "coalesce((Select noofdecimals from tblunitmaster where unitcode=a.unitcode),0) as noofdecimals," +
                    "coalesce((select oldprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    "order by autonum desc limit 1),0) as oldprice,coalesce((select newprice from tblitempricelisttransaction" +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as newprice,coalesce((select colourcode " +
                    "from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode,coalesce(c.hsn,'') " +
                    "as hsn,coalesce(c.tax,'') as tax,(select allowpriceedit from tblroutedetails where routecode='"+getroutecode+"' and areacode='"+getareacode+"')" +
                    " as routeallowpricedit ,(select itemname from tblitemmaster as parent where parent.itemcode=a.itemcode) " +
                    " as parentitemnae,a.orderstatus,a.maxorderqty" +
                    " from tblitemmaster as a " +
                    "   inner join tblitemsubgroupmaster as c " +
                    " on c.itemsubgroupcode=a.itemsubgroupcode " +
                    " where a.itemcode ='"+itemcode+"' and a.status='"+statusvar+"'   group by a.itemcode,a.companycode,a.brandcode,a.manualitemcode," +
                    "a.itemname,a.itemnametamil,a.unitcode,a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight," +
                    "a.itemcategory,a.parentitemcode,a.allowpriceedit,a.allownegativestock,a.allowdiscount ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }



    //Get Purchase Items
    public String GetFreeitemname(String itemcode)
    {
        Cursor mCur =null;
        try{
            getdate = GenCreatedDate();
            String sql ="select a.itemnametamil " +
                    " from tblitemmaster as a "+
                    " where a.itemcode ='"+itemcode+"' and a.status='"+statusvar+"'  ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Get tripadavance for corresponding van and schedule date
    public String GetScheduleTripAdavanceDB(String getdate)
    {
        String gettripadvance="0";
        try{
            String sql =" select schedulecode,coalesce(tripadvance,0) from " +
                    " tblsalesschedule as a where  vancode='"+LoginActivity.getvancode+"' " +
                    " and  scheduledate=datetime('"+getdate+"')  ";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                gettripadvance = mCur.getString(1);
            }else{
                gettripadvance = "0";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return gettripadvance;
    }
    //Get Expense List
    public Cursor GetExpenseListDB(String getdate)
    {
        Cursor mCur = null;
        try{
            String sql ="select transactionno,strftime('%d-%m-%Y',transactiondate) transactiondate,expensesheadcode," +
                    " amount,remarks," +
                    "(select expenseshead from tblexpenseshead where expensesheadcode=a.expensesheadcode) as expensesheadname," +
                    "(select expensesheadtamil from tblexpenseshead where expensesheadcode=a.expensesheadcode)  " +
                    " as expensesheadnametamil ,schedulecode" +
                    " from tblexpenses as a where transactiondate=datetime('"+getdate+"') and ( flag=1 or flag=2) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Customer List
    public Cursor GetCustomerListDB(String getroutecode,String getareacode)
    {
        Cursor mCur = null;
        try{
            String routecode="";
            if(getroutecode.equals("0") || getroutecode.equals("")){
                routecode = "1=1";
            }else{
                routecode="c.routecode='"+getroutecode+"'";
            }

            String areacode="";
            if(getareacode.equals("0") || getareacode.equals("")){
                areacode = "1=1";
            }else{
                areacode="a.areacode='"+getareacode+"'";
            }
            String sql = "";
            String getbusinesstype = "";
            if(LoginActivity.getbusiness_type.equals("2")){
                getbusinesstype=" (a.business_type = 2 or a.business_type = 3) ";
            }else  if(LoginActivity.getbusiness_type.equals("1")){
                getbusinesstype="(a.business_type = 1 or a.business_type = 3)";
            }else{
                getbusinesstype="(a.business_type = 1 or  a.business_type = 2 or a.business_type = 3)";
            }

                sql ="select distinct customercode,customername,customernametamil,address," +
                        " a.areacode,mobileno,coalesce(telephoneno,'') as telephoneno,gstin ," +
                        "b.areanametamil,b.citycode,(select citynametamil from tblcitymaster where citycode=(" +
                        "select citycode from tblareamaster where areacode=b.areacode)) as citynametamil,emailid,aadharno " +
                        "from tblcustomer as a inner join tblareamaster as b on a.areacode=b.areacode " +
                        " left outer join tblroutedetails as c on c.areacode=b.areacode where "+areacode+" " +
                        " and "+routecode+" and a.status='"+statusvar+"' and "+getbusinesstype+" order by refno desc ";


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Receipt List
    public Cursor GetReceiptListDB(String getdate,String getcompanycode,String getareacode)
    {
        Cursor mCur = null;
        try{
            String companycode="";
            if(getcompanycode.equals("0") || getcompanycode.equals("")){
                companycode = "1=1";
            }else{
                companycode="a.companycode='"+getcompanycode+"'";
            }

            String areacode="";
            if(getareacode.equals("0") || getareacode.equals("")){
                areacode = "1=1";
            }else{
                areacode="b.areacode='"+getareacode+"'";
            }
            String sql ="select a.transactionno,strftime('%d-%m-%Y',a.receiptdate) as receiptdate,a.voucherno,a.refno,a.companycode,a.vancode,a.customercode,a.schedulecode," +
                    "a.receiptremarkscode,a.receiptmode,a.chequerefno,a.amount,a.note,b.customernametamil," +
                    "(select areanametamil from tblareamaster where areacode=b.areacode) as areaname," +
                    "(select citynametamil from tblcitymaster where citycode=" +
                    "(select citycode from tblareamaster where areacode=b.areacode)) as cityname," +
                    "(select shortname from tblcompanymaster where companycode=a.companycode) as shortname,a.flag,a.financialyearcode" +
                    " from tblreceipt as a inner join tblcustomer as b on a.customercode=b.customercode where "+areacode+" " +
                    " and "+companycode+" and a.receiptdate=datetime('"+getdate+"') and b.status='"+statusvar+"' order by transactionno desc ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Route List
    public Cursor GetRouteListDB()
    {
        Cursor mCur = null;
        try{
            String sql =" select distinct b.routecode,b.routename,b.routenametamil " +
                    " FROM  tblroute as b  where " +
                    " b.vancode='"+LoginActivity.getvancode+"' and b.status='"+statusvar+"' order by b.routenametamil ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Check voucher settings for sales
    public String GetSalesReturnVoucherSettingsDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select count(count1-count2) from (select sum(count1) as count1,sum(count2) as count2 " +
                    " from (select count(*) as count1,0 as count2 from tblcompanymaster,tblbilltype  " +
                    " where companycode in (select companycode from tblitemmaster ) union all " +
                    "select 0 , count(*) from tblvouchersettings " +
                    "where financialyearcode='"+LoginActivity.getfinanceyrcode+"' and " +
                    " type='salesreturn' and vancode='"+LoginActivity.getvancode+"')" +
                    " as derv) as de where count1<>count2;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }
    //Get sub group based on stock transfer items for sales Returb
    public Cursor GetSubGroupDBSalesReturn()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select distinct c.itemsubgroupcode,c.itemsubgroupname,c.itemsubgroupnametamil from " +
                    "tblitemmaster  as b  inner join " +
                    "tblitemsubgroupmaster as c on c.itemsubgroupcode=b.itemsubgroupcode where " +
                    " b.status='"+statusvar+"' and c.Status='"+statusvar+"' order by c.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Items Sales Return
    public Cursor GetItemsDBSalesReturn(String itemsubgroupcode,String getroutecode,String getareacode)
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select a.itemcode,a.companycode,a.brandcode,a.manualitemcode,a.itemname,a.itemnametamil,a.unitcode," +
                    "a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight,a.itemcategory,a.parentitemcode," +
                    "a.allowpriceedit,a.allownegativestock,a.allowdiscount, (sum(b.op)+sum(b.inward)-sum(b.outward)) as stockqty," +
                    "(Select unitname  from tblunitmaster where unitcode=a.unitcode) as unitname," +
                    "coalesce((Select noofdecimals from tblunitmaster where unitcode=a.unitcode),0) as noofdecimals," +
                    "coalesce((select oldprice from tblitempricelisttransaction where itemcode=a.itemcode " +
                    "order by autonum desc limit 1),0) as oldprice,coalesce((select newprice from tblitempricelisttransaction" +
                    " where itemcode=a.itemcode order by autonum desc limit 1),0) as newprice,coalesce((select colourcode " +
                    "from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode,coalesce(c.hsn,'') " +
                    "as hsn,coalesce(c.tax,'') as tax,(select allowpriceedit from tblroutedetails where routecode='"+getroutecode+"' and areacode='"+getareacode+"')" +
                    " as routeallowpricedit,case when parentitemcode=0 then a.itemcode else parentitemcode " +
                    " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  c.itemsubgroupname,d.brandname " +
                    " from tblitemmaster as a inner join tblstocktransaction as b " +
                    " inner join tblitemsubgroupmaster as c on c.itemsubgroupcode=a.itemsubgroupcode" +
                    " inner join tblbrandmaster as d on a.brandcode=d.brandcode  where " +
                    " a.itemsubgroupcode ='"+itemsubgroupcode+"' and a.status='"+statusvar+"' and b.flag!=3  group by a.itemcode,a.companycode,a.brandcode,a.manualitemcode," +
                    "a.itemname,a.itemnametamil,a.unitcode,a.unitweightunitcode,a.unitweight,a.uppunitcode,a.uppweight," +
                    "a.itemcategory,a.parentitemcode,a.allowpriceedit,a.allownegativestock,a.allowdiscount" +
                    " order by c.itemsubgroupname,d.brandname,a.itemcategory desc ";
            //parentcode,itemorder,a.itemname
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get sub group based on stock transfer items for Sales Return
    public Cursor GetGroupDBSalesReturn()
    {
        Cursor mCur = null;
        try{
            getdate = GenCreatedDate();
            String sql ="select distinct d.itemgroupcode,d.itemgroupname,d.itemgroupnametamil from " +
                    " tblitemmaster  as b  inner join tblitemsubgroupmaster as c " +
                    "on c.itemsubgroupcode=b.itemsubgroupcode inner join tblitemgroupmaster as d   " +
                    "on d.itemgroupcode = c.itemgroupcode where " +
                    " b.status='"+statusvar+"' and c.Status='"+statusvar+"' order by c.itemgroupcode ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Booking No Sales Return
    public String GetBookingNoSalesReturn()
    {
        Cursor mCur = null;
        try{
            String Gencode= GenCreatedDate();
            /*String sql ="select  case when (select Count(*) from tblsalesreturn)=0 then case when " +
                    "(select coalesce(max(bookingno),1) from tblmaxcode where code=3 " +
                    " and datetime(transdate)= datetime('"+Gencode+"'))=1 " +
                    " then  coalesce(max(bookingno),0)+1 " +
                    "else (select coalesce(max(bookingno),0)+1 from tblmaxcode where" +
                    " code=3  and datetime(transdate)= datetime('"+Gencode+"')) " +
                    " end else  coalesce(max(bookingno),0)+1  " +
                    "end as bookingno from tblsalesreturn as  a where " +
                    "financialyearcode='"+LoginActivity.getfinanceyrcode+"' " +
                    " and datetime(billdate)= datetime('"+Gencode+"') ; ";*/
            String sql ="select   coalesce(max(bookingno),0)+1  " +
                    "  as bookingno from tblsalesreturn as  a where financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and datetime(billdate)= datetime('"+Gencode+"'); ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }

    //Get Tranasaction No Sales Return
    public String GetTransactionNoSalesReturn()
    {
        Cursor mCur = null;
        try{
            String sql ="select  case when (select Count(*) from tblsalesreturn)=0 then case when " +
                    "(select coalesce(max(transactionno),1) from tblmaxcode where code=33)=1 " +
                    "then  coalesce(max(transactionno),0)+1 " +
                    "else (select coalesce(max(transactionno),0)+1 from tblmaxcode where code=33) " +
                    "end else  coalesce(max(transactionno),0)+1  " +
                    "end as transactionno from tblsalesreturn as  a ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur.getString(0);
    }


    //Insert into Sales Return
    public String InsertSalesReturn(String vancode,String billdate,String customercode,String billtypecode,
                                    String gstin,String schedulecode,String subtotal,String discount,String
                                            grandtotal,String financialyearcode,String remarks,String bookingno,
                                    String Transactionno,String getrefno)
    {
        try{
            String Gencode= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String getcurtime = GetDateTime();

            String sql="INSERT INTO tblsalesreturn(autonum,companycode,vancode,transactionno,billno,refno,bookingno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                    "schedulecode,subtotal,discount,grandtotal,flag,makerid,createddate,financialyearcode,remarks,syncstatus,salestime,beforeroundoff)" +
                    " select (select coalesce(max(autonum),0)+1 from tblsalesreturn)+companycode,companycode,'"+ vancode +"','"+ Transactionno +"', case when " +
                    "(select Count(*) from tblsalesreturn where  companycode=a.companycode and billtypecode = "+billtypecode+")=0 then " +
                    "case when (select coalesce(max(refno),0)+1 " +
                    "from tblmaxcode where code=333 and companycode=a.companycode and billtypecode = "+billtypecode+" )=1 then " +
                    "(select prefix || printf('%0'||noofdigit||'d', startingno)||suffix FROM tblvouchersettings" +
                    " where type='salesreturn' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' " +
                    "and companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    "else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 " +
                    "from tblmaxcode where code=333 and companycode=a.companycode and billtypecode = "+billtypecode+"))" +
                    " ||suffix FROM tblvouchersettings where type='salesreturn' " +
                    "and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and companycode=a.companycode" +
                    " and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblsalesreturn where" +
                    " companycode=a.companycode and financialyearcode='"+ financialyearcode +"' and billtypecode = "+billtypecode+" ))" +
                    "||suffix FROM tblvouchersettings where type='salesreturn' and billtypecode='"+ billtypecode +"'" +
                    " and vancode='"+ vancode +"' and companycode=a.companycode and " +
                    "financialyearcode='"+ financialyearcode +"')" +
                    " end as billno," +
                    "case when (select Count(*) from tblsalesreturn where  companycode=a.companycode and billtypecode = "+billtypecode+")=0 then" +
                    " case when (select coalesce(max(refno),0)+1 " +
                    " from tblmaxcode where code=333 and companycode=a.companycode and billtypecode = "+billtypecode+")=1 then " +
                    " (select  printf('%0'||noofdigit||'d', startingno) FROM tblvouchersettings where " +
                    "type='salesreturn' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' " +
                    "and companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    " else " +
                    " (select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblmaxcode " +
                    "where code=333 and companycode=a.companycode and billtypecode = "+billtypecode+" )) FROM" +
                    " tblvouchersettings where type='salesreturn' " +
                    " and billtypecode='"+ billtypecode +"'" +
                    " and vancode='"+ vancode +"' and companycode=a.companycode and " +
                    "financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblsalesreturn where " +
                    " companycode=a.companycode and financialyearcode='"+ financialyearcode +"' and billtypecode = "+billtypecode+")) " +
                    "FROM tblvouchersettings where type='salesreturn' and billtypecode='"+ billtypecode +"' " +
                    "and vancode='"+ vancode +"' and companycode=a.companycode and " +
                    "financialyearcode='"+ financialyearcode +"')" +
                    " end as refno,'"+ bookingno +"',(select prefix FROM tblvouchersettings where" +
                    " type='salesreturn' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' " +
                    "and companycode=a.companycode and financialyearcode='"+ financialyearcode +"') as prefix," +
                    " (select suffix FROM tblvouchersettings where type='salesreturn' and " +
                    "billtypecode='"+ billtypecode +"' and vancode='"+ vancode+"' and companycode=a.companycode " +
                    "and financialyearcode='"+ financialyearcode +"') as suffix,datetime('"+ billdate +"')," +
                    " '"+ customercode +"','"+ billtypecode +"','"+ gstin +"','"+ schedulecode +"',round(sum(amount),0)," +
                    "coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"' " +
                    "and companycode=a.companycode " +
                    " and freeitemstatus<>''),0)," +
                    "round(round(sum(amount),0)-coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"' " +
                    "and companycode=a.companycode and freeitemstatus<>''),0),0),'1','1',datetime('now', 'localtime')," +
                    "'"+ financialyearcode +"','"+ remarks +"',0,'"+getcurtime+"',sum(amount)-coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"'" +
                    " and companycode=a.companycode and freeitemstatus<>''),0) "  +
                    " from tbltempsalesitemdetails as  a where refno='"+ getrefno +"' group by companycode";
            mDb.execSQL(sql);

            String sqlitem="INSERT INTO tblsalesreturnitemdetails(autonum,transactionno,bookingno,financialyearcode,companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst," +
                    "cgstamt,sgstamt,igstamt,freeitemstatus,makerid,createddate,vancode,flag,weight)" +
                    "SELECT (select coalesce(max(autonum),0)+1 from tblsalesreturnitemdetails)+autonum,'"+ Transactionno +"','"+ bookingno +"','"+ financialyearcode +"',companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst,cgstamt,sgstamt,igstamt," +
                    "freeitemstatus,'1',datetime('now', 'localtime'),'"+vancode+"',1,weight from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";
            mDb.execSQL(sqlitem);

            String sqlstock="INSERT INTO tblstocktransaction(transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,createddate,flag,op,companycode,financialyearcode,autonum)" +
                    "SELECT (select coalesce(max(transactionno),0)+1 from tblstocktransaction),datetime('"+ Gencode +"'),'"+ vancode +"',itemcode,qty,0," +
                    "'salesreturn','"+ Transactionno +"',datetime('now', 'localtime'),1,0,companycode,'"+financialyearcode+"',(select coalesce(max(autonum),0)+1 from tblstocktransaction)+autonum from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";
            mDb.execSQL(sqlstock);

            String sqlstock1="INSERT INTO tblappstocktransactiondetails(transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,createddate,flag,op,companycode,financialyearcode,syncstatus)" +
                    "SELECT (select coalesce(max(transactionno),0)+1 from tblappstocktransactiondetails),datetime('"+ Gencode +"'),'"+ vancode +"',itemcode,qty,0," +
                    "'salesreturn','"+ Transactionno +"',datetime('now', 'localtime'),1,0,companycode,'"+financialyearcode+"',0 from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";

            mDb.execSQL(sqlstock1);

            String sqldeletesales="delete from tbltempsalesitemdetails where refno='"+ getrefno +"'";
            mDb.execSQL(sqldeletesales);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return Transactionno;
    }

    //Get Sales Return Datas
    public Cursor GetSalesReturnDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesreturn where (flag=1 or syncstatus=0)";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales Return Item Datas
    public Cursor GetSalesReturnItemDatasDB()
    {
        Cursor mCur = null;
        try{
            String sql ="select * from tblsalesreturnitemdetails where flag in (1,3) ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Get Sales Receipt
    public Cursor GetSalesReceiptDB(String getsalestransactionno,String getfinacialyear)
    {
        Cursor mCur =null;
        try{
            String sql ="select billcopystatus,cashpaidstatus from " +
                    " tblsales where transactionno='"+getsalestransactionno+"' and " +
                    " financialyearcode='"+getfinacialyear+"' ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    //Update Sales Return Flag
    public void UpdateSalesReturnFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesreturn set flag=2,syncstatus=1 where transactionno='"+gettransactiono+"'  and flag=1 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Sales Item Flag
    public void UpdateSalesReturnItemFlag(String gettransactiono)
    {
        try{
            String sql = "update tblsalesreturnitemdetails set flag=2 where transactionno='"+gettransactiono+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }



    /*************************************START INSERT UPDATE FUNCTIONALITY******************************/

    public String insertSchedule(String getscheduledate,String getroutecode,String getvehiclecode,String getemployeecode,
                               String getdrivercode,String gethelpername,String gettripadvance,String getstartingkm)
    {
        String generateschedulecode="";
        try{
            String Gencode= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();

            String sqlc = "select  count(*) from tblsalesschedule " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
            String getmaxschedulecode= "1";

            if(getcount.equals("0")){
                String sql1 = "select coalesce(refno,0) from tblmaxcode where code=1";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                getmaxschedulecode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
                if(getmaxschedulecode.equals("0")){
                    getmaxschedulecode ="1";
                }
            }else {
                String sql1 = "select coalesce(max(refno),0)+1 from tblsalesschedule  where refno != 'null' ";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                getmaxschedulecode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
            }
            String sql2 = "select 'V' || substr('00'||'"+LoginActivity.getvancode+"', -2, 2) || substr('0000'||'"+getmaxschedulecode+"', -4, 4) ";
            Cursor mCur1 = mDb.rawQuery(sql2, null);
            mCur1.moveToFirst();
            generateschedulecode= (mCur1.moveToFirst())?mCur1.getString(0):"0";
            if(gettripadvance.equals("")){
                gettripadvance="0";
            }

            String chlschedule = "select count(*) as schedulecount from tblsalesschedule where scheduledate=datetime('"+Gencode+"') ";
            Cursor mschedule = mDb.rawQuery(chlschedule, null);
            mschedule.moveToFirst();
            String getschedulecount = (mschedule.moveToFirst()) ? mschedule.getString(0) : "0";

            if(getschedulecount.equals("0")){
                String sql = "INSERT INTO  'tblsalesschedule' (autonum, refno,schedulecode, scheduledate,vancode,routecode,vehiclecode,employeecode, drivercode,helpername," +
                        "tripadvance,startingkm,endingkm,createddate, updateddate,makerid,flag,lunch_start_time,lunch_end_time) VALUES " +
                        "(0,'"+getmaxschedulecode+"','"+generateschedulecode+"',datetime('"+Gencode+"')," +
                        " '"+LoginActivity.getvancode+"','"+ getroutecode +"','"+ getvehiclecode +"','"+ getemployeecode +"'," +
                        " '"+getdrivercode+"','"+gethelpername+"','"+gettripadvance+"','"+getstartingkm+"',0," +
                        " datetime('now', 'localtime'),datetime('now', 'localtime'),0,0,'','')";
                mDb.execSQL(sql);
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return generateschedulecode;

    }

    //Insert Stock Conversion
    public String insertStockConversion(String getparentitemcode,String getinward,String getoutward,
                                        String getchilditemcode,String getschedulecode)
    {
        try{
            String GenDate= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
       /* String sql1 = "select coalesce(max(transactionno),0)+1 from tblstocktransaction";
        Cursor mCur = mDb.rawQuery(sql1, null);
        mCur.moveToFirst();
        String getmaxtransactionno = (mCur.moveToFirst()) ? mCur.getString(0) : "0";*/

            String sqlconvert = "select coalesce(max(transactionno),0)+1 from tblstockconversion";
            Cursor mCurconvert = mDb.rawQuery(sqlconvert, null);
            mCurconvert.moveToFirst();
            String getmaxstocktransactionno = (mCurconvert.moveToFirst()) ? mCurconvert.getString(0) : "0";

       /* String sqlstockoutward = "INSERT INTO  'tblstocktransaction' VALUES " +
                "('"+getmaxtransactionno+"',datetime('"+GenDate+"')," +
                " '"+LoginActivity.getvancode+"','"+ getparentitemcode +"',0,'"+ getoutward +"'," +
                " 'stockconversion','"+getmaxstocktransactionno+"',datetime('"+GenDate+"'),1,0,0)";
        mDb.execSQL(sqlstockoutward);

        String sqlstockinward = "INSERT INTO  'tblstocktransaction' VALUES " +
                "('"+getmaxtransactionno+"',datetime('"+GenDate+"')," +
                " '"+LoginActivity.getvancode+"','"+ getchilditemcode +"','"+ getinward +"',0," +
                " 'stockconversion','"+getmaxstocktransactionno+"',datetime('"+GenDate+"'),1,0,0)";
        mDb.execSQL(sqlstockinward);*/

            String sqlconvertinward = "INSERT INTO  'tblstockconversion' VALUES " +
                    "('"+getmaxstocktransactionno+"',datetime('"+GenDate+"')," +
                    " '"+LoginActivity.getvancode+"','"+ getparentitemcode +"',0,'"+ getoutward +"'," +
                    " 'stockconversion','"+getschedulecode+"',datetime('"+GenDate+"'))";
            mDb.execSQL(sqlconvertinward);

            String sqlconvertoutward = "INSERT INTO  'tblstockconversion' VALUES " +
                    "('"+getmaxstocktransactionno+"',datetime('"+GenDate+"')," +
                    " '"+LoginActivity.getvancode+"','"+ getchilditemcode +"','"+ getinward +"',0," +
                    " 'stockconversion','"+getschedulecode+"',datetime('"+GenDate+"'))";
            mDb.execSQL(sqlconvertoutward);



        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }


    //Insert Sales item in cart table
    public String insertSalesCart(String itemcode, String companycode,String brandcode, String manualitemcode,
                                  String itemname, String itemnametamil,
                                  String unitcode, String unitweightunitcode, String unitweight,
                                  String uppunitcode, String uppweight, String itemcategory, String parentitemcode,
                                  String allowpriceedit,
                                  String allownegativestock, String allowdiscount, String stockqty, String unitname, String noofdecimals,
                                  String oldprice, String newprice,
                                  String colourcode, String hsn, String tax,
                                  String itemqty, String subtotal,
                                  String routeallowpricedit, String discount, String freeflag,
                                  String purchaseitemcode, String freeitemcode)
    {
        try{
            String GenDate= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select coalesce(max(cartcode),0)+1 from tblsalescartdatas";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            String getmaxcartcode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";


            String sql2 = "select coalesce(count(*),0) as count,coalesce(cartcode,0) as cartcode from tblsalescartdatas " +
                    " where itemcode = '"+itemcode+"' and freeflag='' ";
            Cursor mCur1 = mDb.rawQuery(sql2, null);
            mCur1.moveToFirst();
            String getcount = (mCur1.moveToFirst()) ? mCur1.getString(0) : "0";
            String getcartcode = (mCur1.moveToFirst()) ? mCur1.getString(1) : "0";

            if(getcount.equals("0") ) {
                String sqlcart = "INSERT INTO  'tblsalescartdatas' VALUES " +
                        "('" + getmaxcartcode + "','" + itemcode + "'," +
                        " '" + companycode + "','" + brandcode + "','" + manualitemcode + "','" + itemname + "','" + itemnametamil + "'," +
                        " '" + unitcode + "','" + unitweightunitcode + "','" + unitweight + "'," +
                        " '" + uppunitcode + "','" + uppweight + "','" + itemcategory + "'," +
                        " '" + parentitemcode + "','" + allowpriceedit + "','" + allownegativestock + "' ," +
                        " '" + allowdiscount + "','" + stockqty + "','" + unitname + "'," +
                        " '" + noofdecimals + "','" + oldprice + "','" + newprice + "'," +
                        " '" + colourcode + "','" + hsn + "','" + tax + "'," +
                        " '" + itemqty + "','" + subtotal + "','" + routeallowpricedit + "'," +
                        " '" + discount + "','" + freeflag + "','" + purchaseitemcode + "'," +
                        " '" + freeitemcode + "'  )";
                mDb.execSQL(sqlcart);
            }else if(Integer.parseInt(getcount) > 0){
                String sqlcart = "UPDATE   'tblsalescartdatas' SET " +
                        " companycode= '" + companycode + "',brandcode='" + brandcode + "'," +
                        " manualitemcode='" + manualitemcode + "',itemname='" + itemname + "',itemnametamil='" + itemnametamil + "'," +
                        " unitcode='" + unitcode + "',unitweightunitcode='" + unitweightunitcode + "',unitweight='" + unitweight + "'," +
                        " uppunitcode='" + uppunitcode + "',uppweight='" + uppweight + "',itemcategory='" + itemcategory + "'," +
                        " parentitemcode='" + parentitemcode + "',allowpriceedit='" + allowpriceedit + "',allownegativestock='" + allownegativestock + "' ," +
                        " allowdiscount='" + allowdiscount + "',stockqty='" + stockqty + "',unitname='" + unitname + "'," +
                        " noofdecimals='" + noofdecimals + "',oldprice='" + oldprice + "',newprice='" + newprice + "'," +
                        " colourcode='" + colourcode + "',hsn='" + hsn + "',tax='" + tax + "'," +
                        " itemqty='" + itemqty + "',subtotal='" + subtotal + "',routeallowpricedit='" + routeallowpricedit + "'," +
                        " discount='" + discount + "',freeflag='" + freeflag + "',purchaseitemcode='" + purchaseitemcode + "'," +
                        " freeitemcode='" + freeitemcode + "'   where  cartcode='"+getcartcode+"'" +
                        " and itemcode='"+itemcode+"' and  freeflag='' ";
                mDb.execSQL(sqlcart);

            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }




        return "success";

    }



    //Insert Sales item in cart table
    public String insertSalesOrderCart(String itemcode, String companycode,String brandcode, String manualitemcode,
                                  String itemname, String itemnametamil,
                                  String unitcode, String unitweightunitcode, String unitweight,
                                  String uppunitcode, String uppweight, String itemcategory, String parentitemcode,
                                  String allowpriceedit,
                                  String allownegativestock, String allowdiscount, String stockqty, String unitname, String noofdecimals,
                                  String oldprice, String newprice,
                                  String colourcode, String hsn, String tax,
                                  String itemqty, String subtotal,
                                  String routeallowpricedit, String discount, String freeflag,
                                  String purchaseitemcode, String freeitemcode)
    {
        try{
            String GenDate= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select coalesce(max(cartcode),0)+1 from tblsalesordercartdatas";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            String getmaxcartcode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";


            String sql2 = "select coalesce(count(*),0) as count,coalesce(cartcode,0) as cartcode from tblsalesordercartdatas " +
                    " where itemcode = '"+itemcode+"' and freeflag='' ";
            Cursor mCur1 = mDb.rawQuery(sql2, null);
            mCur1.moveToFirst();
            String getcount = (mCur1.moveToFirst()) ? mCur1.getString(0) : "0";
            String getcartcode = (mCur1.moveToFirst()) ? mCur1.getString(1) : "0";

            if(getcount.equals("0") ) {
                String sqlcart = "INSERT INTO  'tblsalesordercartdatas' VALUES " +
                        "('" + getmaxcartcode + "','" + itemcode + "'," +
                        " '" + companycode + "','" + brandcode + "','" + manualitemcode + "','" + itemname + "','" + itemnametamil + "'," +
                        " '" + unitcode + "','" + unitweightunitcode + "','" + unitweight + "'," +
                        " '" + uppunitcode + "','" + uppweight + "','" + itemcategory + "'," +
                        " '" + parentitemcode + "','" + allowpriceedit + "','" + allownegativestock + "' ," +
                        " '" + allowdiscount + "','" + stockqty + "','" + unitname + "'," +
                        " '" + noofdecimals + "','" + oldprice + "','" + newprice + "'," +
                        " '" + colourcode + "','" + hsn + "','" + tax + "'," +
                        " '" + itemqty + "','" + subtotal + "','" + routeallowpricedit + "'," +
                        " '" + discount + "','" + freeflag + "','" + purchaseitemcode + "'," +
                        " '" + freeitemcode + "'  )";
                mDb.execSQL(sqlcart);
            }else if(Integer.parseInt(getcount) > 0){
                String sqlcart = "UPDATE   'tblsalesordercartdatas' SET " +
                        " companycode= '" + companycode + "',brandcode='" + brandcode + "'," +
                        " manualitemcode='" + manualitemcode + "',itemname='" + itemname + "',itemnametamil='" + itemnametamil + "'," +
                        " unitcode='" + unitcode + "',unitweightunitcode='" + unitweightunitcode + "',unitweight='" + unitweight + "'," +
                        " uppunitcode='" + uppunitcode + "',uppweight='" + uppweight + "',itemcategory='" + itemcategory + "'," +
                        " parentitemcode='" + parentitemcode + "',allowpriceedit='" + allowpriceedit + "',allownegativestock='" + allownegativestock + "' ," +
                        " allowdiscount='" + allowdiscount + "',stockqty='" + stockqty + "',unitname='" + unitname + "'," +
                        " noofdecimals='" + noofdecimals + "',oldprice='" + oldprice + "',newprice='" + newprice + "'," +
                        " colourcode='" + colourcode + "',hsn='" + hsn + "',tax='" + tax + "'," +
                        " itemqty='" + itemqty + "',subtotal='" + subtotal + "',routeallowpricedit='" + routeallowpricedit + "'," +
                        " discount='" + discount + "',freeflag='" + freeflag + "',purchaseitemcode='" + purchaseitemcode + "'," +
                        " freeitemcode='" + freeitemcode + "'   where  cartcode='"+getcartcode+"'" +
                        " and itemcode='"+itemcode+"' and  freeflag='' ";
                mDb.execSQL(sqlcart);

            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }




        return "success";

    }



    //Insert Sales item in cart table
    public String insertFreeSalesCart(String itemcode, String companycode,String brandcode, String manualitemcode,
                                  String itemname, String itemnametamil,
                                  String unitcode, String unitweightunitcode, String unitweight,
                                  String uppunitcode, String uppweight, String itemcategory, String parentitemcode,
                                  String allowpriceedit,
                                  String allownegativestock, String allowdiscount, String stockqty, String unitname, String noofdecimals,
                                  String oldprice, String newprice,
                                  String colourcode, String hsn, String tax,
                                  String itemqty, String subtotal,
                                  String routeallowpricedit, String discount, String freeflag,
                                  String purchaseitemcode, String freeitemcode)
    {
        try{
            String GenDate= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select coalesce(max(cartcode),0)+1 from tblsalescartdatas";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            String getmaxcartcode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";

            String sql3 = "select coalesce(count(*),0) as count,coalesce(cartcode,0) as cartcode from tblsalescartdatas " +
                    " where freeitemcode = '"+freeitemcode+"' and purchaseitemcode='"+purchaseitemcode+"' " +
                    " and freeflag='freeitem' ";
            Cursor mCur2 = mDb.rawQuery(sql3, null);
            mCur2.moveToFirst();
            String getfreecount = (mCur2.moveToFirst()) ? mCur2.getString(0) : "0";
            String getfreecartcode = (mCur2.moveToFirst()) ? mCur2.getString(1) : "0";

            if(getfreecount.equals("0")) {
                String sqlcart = "INSERT INTO  'tblsalescartdatas' VALUES " +
                        "('" + getmaxcartcode + "','" + itemcode + "'," +
                        " '" + companycode + "','" + brandcode + "','" + manualitemcode + "','" + itemname + "','" + itemnametamil + "'," +
                        " '" + unitcode + "','" + unitweightunitcode + "','" + unitweight + "'," +
                        " '" + uppunitcode + "','" + uppweight + "','" + itemcategory + "'," +
                        " '" + parentitemcode + "','" + allowpriceedit + "','" + allownegativestock + "' ," +
                        " '" + allowdiscount + "','" + stockqty + "','" + unitname + "'," +
                        " '" + noofdecimals + "','" + oldprice + "','" + newprice + "'," +
                        " '" + colourcode + "','" + hsn + "','" + tax + "'," +
                        " '" + itemqty + "','" + subtotal + "','" + routeallowpricedit + "'," +
                        " '" + discount + "','" + freeflag + "','" + purchaseitemcode + "'," +
                        " '" + freeitemcode + "'  )";
                mDb.execSQL(sqlcart);
            }else if(Integer.parseInt(getfreecount) > 0){
                String sqlcart = "UPDATE   'tblsalescartdatas' SET " +
                        " companycode= '" + companycode + "',brandcode='" + brandcode + "'," +
                        " manualitemcode='" + manualitemcode + "',itemname='" + itemname + "',itemnametamil='" + itemnametamil + "'," +
                        " unitcode='" + unitcode + "',unitweightunitcode='" + unitweightunitcode + "',unitweight='" + unitweight + "'," +
                        " uppunitcode='" + uppunitcode + "',uppweight='" + uppweight + "',itemcategory='" + itemcategory + "'," +
                        " parentitemcode='" + parentitemcode + "',allowpriceedit='" + allowpriceedit + "',allownegativestock='" + allownegativestock + "' ," +
                        " allowdiscount='" + allowdiscount + "',stockqty='" + stockqty + "',unitname='" + unitname + "'," +
                        " noofdecimals='" + noofdecimals + "',oldprice='" + oldprice + "',newprice='" + newprice + "'," +
                        " colourcode='" + colourcode + "',hsn='" + hsn + "',tax='" + tax + "'," +
                        " itemqty='" + itemqty + "',subtotal='" + subtotal + "',routeallowpricedit='" + routeallowpricedit + "'," +
                        " discount='" + discount + "',freeflag='" + freeflag + "',purchaseitemcode='" + purchaseitemcode + "'," +
                        " freeitemcode='" + freeitemcode + "'   where  cartcode='"+getfreecartcode+"'" +
                        " and freeitemcode='"+freeitemcode+"' and purchaseitemcode='"+purchaseitemcode+"'" +
                        "  and  freeflag='freeitem' ";
                mDb.execSQL(sqlcart);
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }




        return "success";

    }

    //Insert Sales item in cart table
    public String insertFreeSalesOrderCart(String itemcode, String companycode,String brandcode, String manualitemcode,
                                      String itemname, String itemnametamil,
                                      String unitcode, String unitweightunitcode, String unitweight,
                                      String uppunitcode, String uppweight, String itemcategory, String parentitemcode,
                                      String allowpriceedit,
                                      String allownegativestock, String allowdiscount, String stockqty, String unitname, String noofdecimals,
                                      String oldprice, String newprice,
                                      String colourcode, String hsn, String tax,
                                      String itemqty, String subtotal,
                                      String routeallowpricedit, String discount, String freeflag,
                                      String purchaseitemcode, String freeitemcode)
    {
        try{
            String GenDate= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select coalesce(max(cartcode),0)+1 from tblsalesordercartdatas";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            String getmaxcartcode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";

            String sql3 = "select coalesce(count(*),0) as count,coalesce(cartcode,0) as cartcode from tblsalesordercartdatas " +
                    " where freeitemcode = '"+freeitemcode+"' and purchaseitemcode='"+purchaseitemcode+"' " +
                    " and freeflag='freeitem' ";
            Cursor mCur2 = mDb.rawQuery(sql3, null);
            mCur2.moveToFirst();
            String getfreecount = (mCur2.moveToFirst()) ? mCur2.getString(0) : "0";
            String getfreecartcode = (mCur2.moveToFirst()) ? mCur2.getString(1) : "0";

            if(getfreecount.equals("0")) {
                String sqlcart = "INSERT INTO  'tblsalesordercartdatas' VALUES " +
                        "('" + getmaxcartcode + "','" + itemcode + "'," +
                        " '" + companycode + "','" + brandcode + "','" + manualitemcode + "','" + itemname + "','" + itemnametamil + "'," +
                        " '" + unitcode + "','" + unitweightunitcode + "','" + unitweight + "'," +
                        " '" + uppunitcode + "','" + uppweight + "','" + itemcategory + "'," +
                        " '" + parentitemcode + "','" + allowpriceedit + "','" + allownegativestock + "' ," +
                        " '" + allowdiscount + "','" + stockqty + "','" + unitname + "'," +
                        " '" + noofdecimals + "','" + oldprice + "','" + newprice + "'," +
                        " '" + colourcode + "','" + hsn + "','" + tax + "'," +
                        " '" + itemqty + "','" + subtotal + "','" + routeallowpricedit + "'," +
                        " '" + discount + "','" + freeflag + "','" + purchaseitemcode + "'," +
                        " '" + freeitemcode + "'  )";
                mDb.execSQL(sqlcart);
            }else if(Integer.parseInt(getfreecount) > 0){
                String sqlcart = "UPDATE   'tblsalesordercartdatas' SET " +
                        " companycode= '" + companycode + "',brandcode='" + brandcode + "'," +
                        " manualitemcode='" + manualitemcode + "',itemname='" + itemname + "',itemnametamil='" + itemnametamil + "'," +
                        " unitcode='" + unitcode + "',unitweightunitcode='" + unitweightunitcode + "',unitweight='" + unitweight + "'," +
                        " uppunitcode='" + uppunitcode + "',uppweight='" + uppweight + "',itemcategory='" + itemcategory + "'," +
                        " parentitemcode='" + parentitemcode + "',allowpriceedit='" + allowpriceedit + "',allownegativestock='" + allownegativestock + "' ," +
                        " allowdiscount='" + allowdiscount + "',stockqty='" + stockqty + "',unitname='" + unitname + "'," +
                        " noofdecimals='" + noofdecimals + "',oldprice='" + oldprice + "',newprice='" + newprice + "'," +
                        " colourcode='" + colourcode + "',hsn='" + hsn + "',tax='" + tax + "'," +
                        " itemqty='" + itemqty + "',subtotal='" + subtotal + "',routeallowpricedit='" + routeallowpricedit + "'," +
                        " discount='" + discount + "',freeflag='" + freeflag + "',purchaseitemcode='" + purchaseitemcode + "'," +
                        " freeitemcode='" + freeitemcode + "'   where  cartcode='"+getfreecartcode+"'" +
                        " and freeitemcode='"+freeitemcode+"' and purchaseitemcode='"+purchaseitemcode+"'" +
                        "  and  freeflag='freeitem' ";
                mDb.execSQL(sqlcart);
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }




        return "success";

    }

    //Update schedule Flag
    public void UpdateScheduleFlag(String getschedulecode)
    {
        try{
            String sql = "update tblsalesschedule set flag=1 where schedulecode='"+getschedulecode+"'";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Customer Flag
    public void UpdateCustomerFlag(String getcustomercode)
    {
        try{
            String sql = "update tblcustomer set flag=2 where customercode='"+getcustomercode+"'";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update Order Details Flag
    public void UpdateOrderDetailsFlag(String getschedulecode)
    {
        try{
            String Getdate= GenCreatedDate();
            String sql = "update tblorderdetails set flag=2 where schedulecode='"+getschedulecode+"'" +
                    " and vancode='"+LoginActivity.getvancode+"' and orderdate=datetime('"+Getdate+"') ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Expense Flag
    public void UpdateExpenseDetailsFlag(String gettransactionno)
    {
        try{
            String Getdate= GenCreatedDate();
            String sql = "update tblexpenses set flag=2 ,syncstatus=1 where transactionno='"+gettransactionno+"'" +
                    " and vancode='"+LoginActivity.getvancode+"' and " +
                    " financialyearcode='"+LoginActivity.getfinanceyrcode+"' and flag=1 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update Cash reporrt and denomination Flag
    public void UpdateCashDetailsFlag(String getschedulecode)
    {
        try{
            String sql1 = "update tblcashreport set flag=2  where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql1);
            String sql = "update tbldenomination set flag=2  where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update Cash close Flag
    public void UpdateCashCloseFlag(String getschedulecode)
    {
        try{
            String sql1 = "update tblclosecash set flag=2  where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Update Sales close Flag
    public void UpdateSalesCloseFlag(String getschedulecode)
    {
        try{
            String sql1 = "update tblclosesales set flag=2  where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update NIl stock close Flag
    public void UpdateNilStockFlag(String getschedulecode,String getautonum)
    {
        try{
            String sql1 = "update tblnilstocktransaction set syncflag=1  where schedulecode='"+getschedulecode+"' and autonum ='"+getautonum+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update Receipt Flag
    public void UpdateReceiptDetailsFlag(String gettransactionno)
    {
        try{
            String Getdate= GenCreatedDate();
            String sql = "update tblreceipt set flag=2 ,syncstatus=1 where transactionno='"+gettransactionno+"'" +
                    " and vancode='"+LoginActivity.getvancode+"' and " +
                    " financialyearcode='"+LoginActivity.getfinanceyrcode+"' and flag=1 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    //Delete Expense Flag
    public void DeleteExpenseDetailsFlag(String gettransactionno)
    {
        try{
            String sql = "delete from tblexpenses where transactionno='"+gettransactionno+"'" +
                    " and vancode='"+LoginActivity.getvancode+"' and " +
                    " financialyearcode='"+LoginActivity.getfinanceyrcode+"' and flag=3 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //Update cancel Receipt flag
    public String  UpdateCancelReceiptFlag(String gettranasactionno) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql = "update tblreceipt set flag=6,syncstatus=1 where transactionno = '"+gettranasactionno+"'" +
                    "and vancode='"+LoginActivity.getvancode+"' and financialyearcode='"+LoginActivity.getfinanceyrcode+"'" +
                    " and flag=3 ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }
    /***********************INSERT SALES FUNCTIONALITY***********************/
    public String GetMaxRefnoSalesItems(){
        String getrefno="";
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select COALESCE(max(refno),0)+1 from tbltempsalesitemdetails";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            getrefno= (mCur.moveToFirst())?mCur.getString(0):"0";
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  getrefno;
    }

    public String GetMaxRefnoSalesOrderItems(){
        String getrefno="";
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select COALESCE(max(refno),0)+1 from tbltempsalesorderitemdetails";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            getrefno= (mCur.moveToFirst())?mCur.getString(0):"0";
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  getrefno;
    }
    // insert temp sales item details
    public void  InsertTempSalesItemDetails(String itemcode,String companycode,String qty,String price,
                                                String discount,String amount,String freeitemstatus,String tax,
                                                String gstin,String getrefno,double getweight,int autonum) {
        try{
            mDb = mDbHelper.getReadableDatabase();

            double vartaxamount=((Double.parseDouble(price)/(1+Double.parseDouble(tax)/100))*(Double.parseDouble(tax)/100))*Double.parseDouble(qty);
            double cgst,sgst,igst,cgstamt,sgstamt,igstamt;
            if (!gstin.equals(""))
            {
                if ((gstin.substring(0,2)).equals("33"))
                {
                    cgst=Double.parseDouble(tax)/2;
                    sgst=cgst;
                    igst=0;
                    cgstamt=vartaxamount/2;
                    sgstamt=cgstamt;
                    igstamt=0;
                }
                else
                {
                    igst=Double.parseDouble(tax);
                    cgst=0;
                    sgst=0;
                    cgstamt=0;
                    sgstamt=0;
                    igstamt=vartaxamount;

                }
            }
            else
            {
                cgst=Double.parseDouble(tax)/2;
                sgst=cgst;
                igst=0;
                cgstamt=vartaxamount/2;
                sgstamt=cgstamt;
                igstamt=0;
            }
            String sql="INSERT INTO tbltempsalesitemdetails(autonum,refno,companycode,itemcode,qty,price,discount," +
                    "amount,cgst,sgst,igst,cgstamt,sgstamt,igstamt,freeitemstatus,weight) " +
                    "values ('"+autonum+"','"+ getrefno +"','"+ companycode +"','"+ itemcode +"','"+ Double.parseDouble(qty) +"','"+ Double.parseDouble(price) +"'," +
                    "'"+ discount +"','"+ amount +"','"+ dft.format(cgst) +"','"+ dft.format(sgst) +"','"+ dft.format(igst)+"'," +
                    "'"+ dft.format(cgstamt) +"','"+ dft.format(sgstamt) +"','"+ dft.format(igstamt) +"','"+ freeitemstatus +"','"+getweight+"')";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }

    // insert temp sales item details
    public void  InsertTempSalesOrderItemDetails(String itemcode,String companycode,String qty,String price,
                                            String discount,String amount,String freeitemstatus,String tax,
                                            String gstin,String getrefno,double getweight,int autonum) {
        try{
            mDb = mDbHelper.getReadableDatabase();

            double vartaxamount=((Double.parseDouble(price)/(1+Double.parseDouble(tax)/100))*(Double.parseDouble(tax)/100))*Double.parseDouble(qty);
            double cgst,sgst,igst,cgstamt,sgstamt,igstamt;
            if (!gstin.equals(""))
            {
                if ((gstin.substring(0,2)).equals("33"))
                {
                    cgst=Double.parseDouble(tax)/2;
                    sgst=cgst;
                    igst=0;
                    cgstamt=vartaxamount/2;
                    sgstamt=cgstamt;
                    igstamt=0;
                }
                else
                {
                    igst=Double.parseDouble(tax);
                    cgst=0;
                    sgst=0;
                    cgstamt=0;
                    sgstamt=0;
                    igstamt=vartaxamount;

                }
            }
            else
            {
                cgst=Double.parseDouble(tax)/2;
                sgst=cgst;
                igst=0;
                cgstamt=vartaxamount/2;
                sgstamt=cgstamt;
                igstamt=0;
            }
            String sql="INSERT INTO tbltempsalesorderitemdetails(autonum,refno,companycode,itemcode,qty,price,discount," +
                    "amount,cgst,sgst,igst,cgstamt,sgstamt,igstamt,freeitemstatus,weight) " +
                    "values ('"+autonum+"','"+ getrefno +"','"+ companycode +"','"+ itemcode +"','"+ Double.parseDouble(qty) +"','"+ Double.parseDouble(price) +"'," +
                    "'"+ discount +"','"+ amount +"','"+ dft.format(cgst) +"','"+ dft.format(sgst) +"','"+ dft.format(igst)+"'," +
                    "'"+ dft.format(cgstamt) +"','"+ dft.format(sgstamt) +"','"+ dft.format(igstamt) +"','"+ freeitemstatus +"','"+getweight+"')";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }

    //Insert into Sales
    public String InsertSales(String vancode,String billdate,String customercode,String billtypecode,
                              String gstin,String schedulecode,String subtotal,String discount,String
                                      grandtotal,String financialyearcode,String remarks,String bookingno,
                              String Transactionno,String getrefno,String billcopystatus,String getcashpaidstatus)
    {
        try{
            String Gencode= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String getcurtime = GetDateTime();

            String sql="INSERT INTO tblsales(autonum,companycode,vancode,transactionno,billno,refno,bookingno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                    "schedulecode,subtotal,discount,grandtotal,flag,makerid,createddate,financialyearcode,remarks,syncstatus," +
                    "billcopystatus,cashpaidstatus,salestime,beforeroundoff)" +
                    " select (select coalesce(max(autonum),0)+1 from tblsales),companycode,'"+ vancode +"','"+ Transactionno +"', case when (select Count(*) from tblsales where  companycode=a.companycode  and billtypecode = "+billtypecode+" )=0 " +
                    " then case when (select coalesce(max(refno),0)+1 from tblmaxcode where code=222 " +
                    " and companycode=a.companycode and billtypecode = "+billtypecode+" )=1 then " +
                    "(select prefix || printf('%0'||noofdigit||'d', startingno)||suffix FROM tblvouchersettings " +
                    "where type='sales' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' " +
                    "and companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    "else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from " +
                    "tblmaxcode where code=222 and companycode=a.companycode and billtypecode = "+billtypecode+" ))||suffix FROM tblvouchersettings where type='sales' and " +
                    "billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and companycode=a.companycode " +
                    "and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select prefix || printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblsales " +
                    "where  companycode=a.companycode and billtypecode = "+billtypecode+"  and financialyearcode='"+ financialyearcode +"'))||suffix " +
                    "FROM tblvouchersettings where type='sales' and billtypecode='"+ billtypecode +"' and " +
                    "vancode='"+ vancode +"' and companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    " end as billno," +
                    "case when (select Count(*) from tblsales  where  companycode=a.companycode" +
                    " and billtypecode = "+billtypecode+"  )=0 then case when (select coalesce(max(refno),0)+1 from " +
                    " tblmaxcode where  code=222 and companycode=a.companycode and billtypecode = "+billtypecode+"  )=1 then " +
                    " (select  printf('%0'||noofdigit||'d', startingno) FROM tblvouchersettings where type='sales' " +
                    "and billtypecode='"+billtypecode+"' and vancode='"+vancode+"' and companycode=a.companycode" +
                    " and financialyearcode='"+financialyearcode+"')" +
                    " else " +
                    " (select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblmaxcode where " +
                    " code=222 and companycode=a.companycode and billtypecode = "+billtypecode+"  ))" +
                    " FROM tblvouchersettings where type='sales' and billtypecode='"+ billtypecode +"' and " +
                    "vancode='"+ vancode +"' and companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblsales " +
                    "where  companycode=a.companycode and billtypecode = "+billtypecode+"  and financialyearcode='"+ financialyearcode +"')) FROM tblvouchersettings " +
                    "where type='sales' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and" +
                    " companycode=a.companycode and financialyearcode='"+ financialyearcode +"')" +
                    " end as refno,'"+ bookingno +"',(select prefix FROM tblvouchersettings where type='sales' " +
                    "and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and " +
                    "companycode=a.companycode and financialyearcode='"+ financialyearcode +"') as prefix," +
                    " (select suffix FROM tblvouchersettings where type='sales' and billtypecode='"+ billtypecode +"'" +
                    " and vancode='"+ vancode+"' and companycode=a.companycode and " +
                    " financialyearcode='"+ financialyearcode +"') as suffix,datetime('"+ billdate +"')," +
                    " '"+ customercode +"','"+ billtypecode +"','"+ gstin +"','"+ schedulecode +"', round(sum(amount),0)," +
                    "coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"' " +
                    " and companycode=a.companycode " +
                    " and freeitemstatus<>''),0)," +
                    "  round(round(sum(amount),0)-coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"' " +
                    "and companycode=a.companycode and freeitemstatus<>''),0),0),'1','1',datetime('now', 'localtime')," +
                    " '"+ financialyearcode +"','"+ remarks +"' ,0,'"+billcopystatus+"','"+getcashpaidstatus+"','"+getcurtime+"'," +
                    "sum(amount)-coalesce((select sum(amount) from tbltempsalesitemdetails where refno='"+ getrefno +"' " +
                    "and companycode=a.companycode and freeitemstatus<>''),0) "  +
                    " from tbltempsalesitemdetails as  a where refno='"+ getrefno +"' group by companycode";
            mDb.execSQL(sql);

            String sqlseletecash =  "UPDATE tblnilstocktransaction set flag=3,syncflag=0 where salesitemcode" +
                    " in (SELECT itemcode  from tbltempsalesitemdetails)";
            mDb.execSQL(sqlseletecash);

            String sqlitem="INSERT INTO tblsalesitemdetails(autonum,transactionno,bookingno,financialyearcode,companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst," +
                    "cgstamt,sgstamt,igstamt,freeitemstatus,makerid,createddate,vancode,flag,weight)" +
                    "SELECT (select coalesce(max(autonum),0)+1 from tblsalesitemdetails)+autonum,'"+ Transactionno +"','"+ bookingno +"','"+ financialyearcode +"',companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst,cgstamt,sgstamt,igstamt," +
                    "freeitemstatus,'1',datetime('now', 'localtime'),'"+vancode+"',1,weight from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";
            mDb.execSQL(sqlitem);

            String sqlstock="INSERT INTO tblstocktransaction(transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,createddate,flag,companycode,op,financialyearcode,autonum)" +
                    "SELECT (select coalesce(max(transactionno),0)+1 from tblstocktransaction),datetime('"+ Gencode +"'),'"+ vancode +"',itemcode,0,qty," +
                    "'sales','"+ Transactionno +"',datetime('now', 'localtime'),1,companycode,0,'"+financialyearcode+"',(select coalesce(max(autonum),0)+1 from tblstocktransaction)+autonum from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";

            mDb.execSQL(sqlstock);

            String sqlstock1="INSERT INTO tblappstocktransactiondetails(transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,createddate,flag,companycode,op,financialyearcode,syncstatus)" +
                    "SELECT (select coalesce(max(transactionno),0)+1 from tblappstocktransactiondetails),datetime('"+ Gencode +"'),'"+ vancode +"',itemcode,0,qty," +
                    "'sales','"+ Transactionno +"',datetime('now', 'localtime'),1,companycode,0,'"+financialyearcode+"',0 from tbltempsalesitemdetails as  a where refno='"+ getrefno +"'";

            mDb.execSQL(sqlstock1);


            //Stock conversion
            String sqlstockconversion = "INSERT INTO  'tblstocktransaction' (transactionno,transactiondate,vancode,itemcode,inward,outward,type,refno,createddate,flag,companycode,op,financialyearcode,autonum) " +
                    " SELECT (select coalesce(max(transactionno),0)+1 from tblstocktransaction) ,transactiondate," +
                    " vancode,itemcode,inward,outward,type,'"+ Transactionno +"',createddate,1,0,0,'"+financialyearcode+"',(select coalesce(max(transactionno),0)+1 from tblstocktransaction) from tblstockconversion ";
            mDb.execSQL(sqlstockconversion);

            //Stock conversion
            String sqlsalesstockconversion = "INSERT INTO  'tblsalesstockconversion' (transactiondate,vancode,itemcode,inward,outward,type," +
                    " refno,createddate,flag,companycode,op,financialyearcode,autonum) " +
                    " SELECT transactiondate," +
                    " vancode,itemcode,inward,outward,type,'"+ Transactionno +"',createddate,1,0,0,'"+financialyearcode+"'," +
                    "(select coalesce(max(autonum),0)+1 from tblsalesstockconversion)" +
                    " from tblstockconversion ";
            mDb.execSQL(sqlsalesstockconversion);



            String sqlstockconversion1 = "INSERT INTO  'tblappstocktransactiondetails'  " +
                    " SELECT (select coalesce(max(transactionno),0)+1 from tblappstocktransactiondetails) ,transactiondate," +
                    " vancode,itemcode,inward,outward,type,'"+ Transactionno +"',createddate,1,0,0,'"+financialyearcode+"',0 from tblstockconversion ";
            mDb.execSQL(sqlstockconversion1);

            String sqldeletesales="delete from tbltempsalesitemdetails where refno='"+ getrefno +"'";
            mDb.execSQL(sqldeletesales);

            String sqldeletestockconversion="delete from tblstockconversion ";
            mDb.execSQL(sqldeletestockconversion);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return Transactionno;
    }


    //Insert into Sales
    public String InsertSalesOrder(String vancode,String billdate,String customercode,String billtypecode,
                              String gstin,String schedulecode,String subtotal,String discount,String
                                      grandtotal,String financialyearcode,String remarks,String bookingno,
                              String Transactionno,String getrefno,String billcopystatus,String getcashpaidstatus,
                                   String transportid,String getsalessordervoucherno )
    {
        try{
            String Gencode= GenCreatedDate();
            mDb = mDbHelper.getReadableDatabase();
            String getcurtime = GetDateTime();

            String sql="INSERT INTO tblsalesorder(autonum,companycode,vancode,transactionno,billno,refno,bookingno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                    "schedulecode,subtotal,discount,grandtotal,flag,makerid,createddate,financialyearcode,remarks,syncstatus," +
                    "billcopystatus,cashpaidstatus,salestime,beforeroundoff,transportid)" +
                    " select (select coalesce(max(autonum),0)+1 from tblsalesorder),companycode,'"+ vancode +"'," +
                    " '"+ Transactionno +"', '"+getsalessordervoucherno+"' ," +
                    "case when (select Count(*) from tblsalesorder  where  " +
                    "  billtypecode = "+billtypecode+"  )=0 then case when (select coalesce(max(refno),0)+1 from " +
                    " tblmaxcode where  code=777  and billtypecode = "+billtypecode+"  )=1 then " +
                    " (select  printf('%0'||noofdigit||'d', startingno) FROM tblvouchersettings where type='salesorder' " +
                    "and billtypecode='"+billtypecode+"' and vancode='"+vancode+"' " +
                    " and financialyearcode='"+financialyearcode+"')" +
                    " else " +
                    " (select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblmaxcode where " +
                    " code=777  and billtypecode = "+billtypecode+"  ))" +
                    " FROM tblvouchersettings where type='salesorder' and billtypecode='"+ billtypecode +"' and " +
                    "vancode='"+ vancode +"'  and financialyearcode='"+ financialyearcode +"')" +
                    "end else" +
                    "(select printf('%0'||noofdigit||'d', (select coalesce(max(refno),0)+1 from tblsalesorder " +
                    "where  billtypecode = "+billtypecode+"  and financialyearcode='"+ financialyearcode +"')) FROM tblvouchersettings " +
                    "where type='salesorder' and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and" +
                    " financialyearcode='"+ financialyearcode +"')" +
                    " end as refno,'"+ bookingno +"',(select prefix FROM tblvouchersettings where type='salesorder' " +
                    "and billtypecode='"+ billtypecode +"' and vancode='"+ vancode +"' and " +
                    " financialyearcode='"+ financialyearcode +"') as prefix," +
                    " (select suffix FROM tblvouchersettings where type='salesorder' and billtypecode='"+ billtypecode +"'" +
                    " and vancode='"+ vancode+"'  and " +
                    " financialyearcode='"+ financialyearcode +"') as suffix,datetime('"+ billdate +"')," +
                    " '"+ customercode +"','"+ billtypecode +"','"+ gstin +"','"+ schedulecode +"', round(sum(amount),0)," +
                    "coalesce((select sum(amount) from tbltempsalesorderitemdetails where refno='"+ getrefno +"' " +
                    " " +
                    " and freeitemstatus<>''),0)," +
                    "  round(round(sum(amount),0)-coalesce((select sum(amount) from tbltempsalesorderitemdetails where refno='"+ getrefno +"' " +
                    " and freeitemstatus<>''),0),0),'1','1',datetime('now', 'localtime')," +
                    " '"+ financialyearcode +"','"+ remarks +"' ,0,'"+billcopystatus+"','"+getcashpaidstatus+"','"+getcurtime+"'," +
                    "sum(amount)-coalesce((select sum(amount) from tbltempsalesorderitemdetails where refno='"+ getrefno +"' " +
                    " and freeitemstatus<>''),0),'"+transportid+"' "  +
                    " from tbltempsalesorderitemdetails as  a where refno='"+ getrefno +"' ";
            mDb.execSQL(sql);

            String sqlitem="INSERT INTO tblsalesorderitemdetails(autonum,transactionno,bookingno,financialyearcode,companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst," +
                    "cgstamt,sgstamt,igstamt,freeitemstatus,makerid,createddate,vancode,flag,weight)" +
                    "SELECT (select coalesce(max(autonum),0)+1 from tblsalesorderitemdetails)+autonum,'"+ Transactionno +"','"+ bookingno +"','"+ financialyearcode +"',companycode,itemcode,qty,price,discount,amount,cgst,sgst,igst,cgstamt,sgstamt,igstamt," +
                    "freeitemstatus,'1',datetime('now', 'localtime'),'"+vancode+"',1,weight from tbltempsalesorderitemdetails as  a where refno='"+ getrefno +"'";
            mDb.execSQL(sqlitem);





            String sqldeletesales="delete from tbltempsalesorderitemdetails where refno='"+ getrefno +"'";
            mDb.execSQL(sqldeletesales);


        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return Transactionno;
    }
    //Update sales receipt
    public String UpdateSalesReceipt(String gettransactionno,String getbillcopystatus ,String getpaymentstatus)
    {
        try{
            String sql = "update tblsales set billcopystatus='"+getbillcopystatus+"' ," +
                    " cashpaidstatus = '"+getpaymentstatus+"' where transactionno='"+gettransactionno+"' " +
                    "and financialyearcode ='"+LoginActivity.getfinanceyrcode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  "success";
    }

    //Find and insert nil stock
    public String InsertnilStock(String getvancode,String getschedulecode,String getsalestransactionno,String getsalesbookingno,
                                String getsalesfinacialyearcode,String getsalescustomercode )
    {
        try{
            String getdate = GenCreatedDateTime();
            String sql = "INSERT INTO tblnilstocktransaction (vancode,schedulecode,salestransactionno,salesbookingno,salesfinacialyearcode," +
                    "salescustomercode,salesitemcode,createddate,flag,syncflag) " +
                    "select '"+getvancode+"','"+getschedulecode+"','"+getsalestransactionno+"'," +
                    " '"+getsalesbookingno+"','"+getsalesfinacialyearcode+"','"+getsalescustomercode+"'," +
                    " dev.itemcode,datetime('"+getdate+"') ,1,0 from (select a.itemcode,coalesce((sum(b.op)+sum(b.inward)-sum(b.outward)),0) as stock" +
                    "  from tblsalesitemdetails as a inner join tblstocktransaction as b on a.itemcode=b.itemcode " +
                    " where a.transactionno ='"+getsalestransactionno+"' and a.financialyearcode='"+getsalesfinacialyearcode+"'" +
                    "  and a.bookingno='"+getsalesbookingno+"' and datetime(transactiondate)<= " +
                    "datetime('"+getdate+"')  and b.flag!=3   group by a.itemcode ) as dev where dev.stock = 0";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  "success";
    }

    //update nil stock
    public String UpdateNilStock(String getvancode,String getschedulecode,String getsalestransactionno,
                                 String getsalesfinacialyearcode )
    {
        try{
            String getdate = GenCreatedDate();
            String sql = "UPDATE tblnilstocktransaction set  flag=3,syncflag=0  where vancode='"+getvancode+"'" +
                    " and schedulecode='"+getschedulecode+"' and salestransactionno='"+getsalestransactionno+"'" +
                    " and salesfinacialyearcode='"+getsalesfinacialyearcode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  "success";
    }
    public String updateSalesImageData(String gettransactionno, String getfinancialyr,
                                        String getbitmapimagedata)
    {
        Cursor mCurs =null;
        try{
            if(!(gettransactionno.equals(""))) {

                String exequery = "UPDATE tblsales set bitmapimage='"+getbitmapimagedata+"'," +
                        " imgflag=0 where transactionno='"+gettransactionno+"' and" +
                        " financialyearcode ='"+getfinancialyr+"' ";
                mDb.execSQL(exequery);
            }
            String sqls = "SELECT count(*) from 'tblsales'  where transactionno='"+gettransactionno+"' and " +
                    " financialyearcode ='"+getfinancialyr+"' and imgflag=0 ";
            mCurs = mDb.rawQuery(sqls, null);
            mCurs.moveToFirst();
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return (mCurs.moveToFirst())?mCurs.getString(0):"0";
    }
    public Cursor GetSalesImageDetails() {
        Cursor mCur = null;
        try{
            String sql = "select transactionno,bitmapimage,financialyearcode," +
                    " (select 'V' || substr('00'||vancode, -2, 2) || substr('0000'||transactionno, -4, 4) || '-' ||" +
                    " substr('0000'||financialyearcode, -3, 3) as imagecode " +
                    " ) from tblsales where imgflag=0;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public Cursor GetSalesImageData(String transno,String finayr) {
        Cursor mCur =null;
        try{
            String sql = "select bitmapimage from tblsales where transactionno='"+transno+"' " +
                    " and financialyearcode = '"+finayr+"' ;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor GetServerurllistdata() {
        Cursor mCur =null;
        try{
            String sql = "select serverid,internetip,status from tblserversettings ;";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0) {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public void SalesImageSetFlag(String gettransactionno,String getfinancialyrcode)
    {
        try{
            String sql = "update tblsales set imgflag=1 where transactionno='"+gettransactionno+"' and" +
                    " financialyearcode='"+getfinancialyrcode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    public void UpdateSalesBitmapImage(String transno,String finayr)
    {
        try{
            String sql = "update tblsales set bitmapimage='BLOB',imgflag=2 where transactionno='"+transno+"' " +
                    " and financialyearcode = '"+finayr+"' ";
            mDb.execSQL(sql);
            String sqls1 = "select bitmapimage from tblsales where transactionno='"+transno+"' " +
                    " and financialyearcode = '"+finayr+"' ";
            Cursor mCur1 = mDb.rawQuery(sqls1, null);
            String getbitmapimg = (mCur1.moveToFirst())?mCur1.getString(0):"0";
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


    }
    //Update sales List receipt
    //Flag 4 means updated sales receipt
    public String UpdateSalesListReceipt(String gettransactionno,String getfinanicialyear,String getbillcopystatus ,String getpaymentstatus)
    {
        try{
            String sql = "update tblsales set billcopystatus='"+getbillcopystatus+"' ," +
                    " cashpaidstatus = '"+getpaymentstatus+"',flag = 4  where transactionno='"+gettransactionno+"' and" +
                    " financialyearcode = '"+getfinanicialyear+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  "success";
    }
    public void DeleteOrderDetails(){
        try{
            String sql1 = "delete from tblorderdetails where " +
                    " orderdate=datetime('"+ LoginActivity.getformatdate +"') " +
                    "  and schedulecode='"+MenuActivity.getschedulecode+"'  and vancode='"+LoginActivity.getvancode+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }
    public String  InsertOrderDetails(String itemcode,String qty,String status) {
        try{
            mDb = mDbHelper.getReadableDatabase();

            String sql1 = "select COALESCE(count(*),0) from tblorderdetails where " +
                    " orderdate=datetime('"+ LoginActivity.getformatdate +"') and  itemcode='"+itemcode+"'" +
                    "  and schedulecode='"+MenuActivity.getschedulecode+"' ";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            String getcount= (mCur.moveToFirst())?mCur.getString(0):"0";
            if(getcount.equals("0")) {
                String sql = "insert into tblorderdetails (autonum,vancode,schedulecode,itemcode,qty,makerid,createddate,orderdate,flag,status) " +
                        "select coalesce(max(autonum),0)+1 ,'" + LoginActivity.getvancode + "','" + MenuActivity.getschedulecode + "','" + itemcode + "','" + Double.parseDouble(qty) + "'," +
                        "'0',datetime('now', 'localtime'),datetime('" + LoginActivity.getformatdate + "'),1 ,'"+status+"' from tblorderdetails";
                mDb.execSQL(sql);
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";

    }

    public String  InsertExpensesDetails(String getexpensesheadcode,String getamount,String getremarks) {
        try{
            mDb = mDbHelper.getReadableDatabase();


            String sqlc = "select  count(*) from tblexpenses " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
            String gettransactionno= "1";

            if(getcount.equals("0")){
                String sql1 = "select coalesce(refno,0) from tblmaxcode where code=5";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                gettransactionno = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
                if(gettransactionno.equals("0")){
                    gettransactionno ="1";
                }
            }else {
                String sql1 = "select coalesce(max(transactionno),0)+1 from tblexpenses";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                gettransactionno = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
            }
            String sql = "insert into tblexpenses (autonum,transactionno,transactiondate,expensesheadcode," +
                    "amount,remarks,makerid,createdate,schedulecode," +
                    " financialyearcode,vancode,flag,syncstatus) select coalesce(max(autonum),0)+1 ,'" + gettransactionno + "',datetime('" + LoginActivity.getformatdate + "')," +
                    "'" + getexpensesheadcode + "','" + Double.parseDouble(getamount) + "'," +
                    " '"+getremarks+"','0',datetime('now', 'localtime'),'" +MenuActivity.getschedulecode+ "'" +
                    " ,'"+LoginActivity.getfinanceyrcode+"','"+LoginActivity.getvancode+"',1 ,0 from tblexpenses";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }
    //Cash Reoprt denomination
    public String  InsertDenomination(String getschedulecode,String getcurrencycode,
                                      String getqty,String getamount) {
        try{
            mDb = mDbHelper.getReadableDatabase();

            String sql = "insert into tbldenomination (autonum,vancode,schedulecode,currencycode,qty,amount,flag)  " +
                    " select coalesce(max(autonum),0)+1 ,'" + LoginActivity.getvancode + "','" + getschedulecode + "'," +
                    "'" + getcurrencycode + "','" + Double.parseDouble(getqty) + "'," +
                    " '"+getamount+"',1 from tbldenomination";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }

    //InsertServerSettings
    public String  InsertServerSettings(String getipaddress) {
        try{
            String sqlc = "select  count(*) from tblserversettings where  internetip = '"+getipaddress+"' " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
            if(getcount.equals("0")){
                String sql = "insert into tblserversettings (serverid,internetip,status)  " +
                        "  select coalesce(max(serverid),0)+1 ,'"+getipaddress+"','inactive' from tblserversettings ";
                mDb.execSQL(sql);
            }else {
                String sql = "Update tblserversettings set internetip = '"+getipaddress+"' ";
                mDb.execSQL(sql);
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return "success";

    }
    //InsertServerSettings
    public String  UpdateServerSettings(String getstatus,String getserverid) {
        try{
            String sql = "Update tblserversettings set status = '"+getstatus+"' where serverid='"+getserverid+"' ";
            mDb.execSQL(sql);

            String sql1 = "Update tblserversettings set status = 'inactive' where serverid!='"+getserverid+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        // mDb = mDbHelper.getReadableDatabase();
        // getdate= GenCreatedDate();



        return "success";

    }

    //DeleteServerSettings
    public String  DeleteServerSettings(String getserverid) {
        try{
            String sql = "delete from tblserversettings  where serverid='"+getserverid+"' ";
            mDb.execSQL(sql);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return "success";

    }


    //Insert sales lauch start time
    public String  InsertLaunchtime(String getschedulecode) {
        try{
             mDb = mDbHelper.getReadableDatabase();
             getdate= GenCreatedDateTime();
                String sql = "update tblsalesschedule set lunch_start_time = '"+getdate+"' ,flag = 0 where schedulecode='"+getschedulecode+"' ";
                mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return "success";

    }


    //Insert sales lauch start time
    public String  InsertLaunchEndtime(String getschedulecode) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            getdate= GenCreatedDateTime();
            String sql = "update tblsalesschedule set lunch_end_time = '"+getdate+"' ,flag = 0 where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return "success";

    }
    //Cash  Close
    public String  InsertCashClose(String getschedulecode,String getendingkm,String getpaidparties,String getexpenseentries) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            getdate= GenCreatedDate();
            String sql1 = "update tblsalesschedule set endingkm='"+getendingkm+"' where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql1);

            String sql2 = "delete from tblclosecash where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql2);

            String sql = "insert into tblclosecash (autonum,closedate,vancode,schedulecode,status,flag,paidparties,expenseentries,createddate)  " +
                    " select coalesce(max(autonum),0)+1 ,datetime('"+getdate+"'),'" + LoginActivity.getvancode + "','" + getschedulecode + "'," +
                    "1,1,'"+getpaidparties+"','"+getexpenseentries+"',datetime('now', 'localtime') from tblclosecash";
            mDb.execSQL(sql);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";

    }

    //Cash  Close
    public String  UpdateCashClose(String getschedulecode) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            getdate= GenCreatedDate();
            String sql1 = "update tblclosecash set status='2' where schedulecode='"+getschedulecode+"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }
    //Cash  Close
    public String  InsertSalesClose(String getschedulecode) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            getdate= GenCreatedDate();
            String sqlc = "select  coalesce(count(*),0) from tblclosesales where schedulecode= '"+getschedulecode+"' " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
            if(!getcount.equals("0")){
                String sqldelete = "DELETE from tblclosesales where schedulecode= '"+getschedulecode+"' ";
                mDb.execSQL(sqldelete);
            }
            String sql = "insert into tblclosesales (autonum,closedate,vancode,schedulecode,flag,createddate)  " +
                    " select coalesce(max(autonum),0)+1 ,datetime('"+getdate+"'),'" + LoginActivity.getvancode + "','" + getschedulecode + "'," +
                    "1,datetime('now', 'localtime') from tblclosesales";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }

    //Cash  Close
    public String  InsertOrderSalesClose(String getschedulecode) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            getdate= GenCreatedDate();
            String sqlc = "select  coalesce(count(*),0) from tblclosesales where schedulecode= '"+getschedulecode+"' " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
            if(!getcount.equals("0")){
                String sqldelete = "DELETE from tblclosesales where schedulecode= '"+getschedulecode+"' ";
                mDb.execSQL(sqldelete);
            }
            String sql = "insert into tblclosesales (autonum,closedate,vancode,schedulecode,flag,createddate)  " +
                    " select coalesce(max(autonum),0)+1 ,datetime('"+getdate+"'),'" + LoginActivity.getvancode + "','" + getschedulecode + "'," +
                    "1,datetime('now', 'localtime') from tblclosesales";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }
    //Delete Cash Reoprt denomination
    public String  DeleteDenomination(String getschedulecode) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql = "delete from tbldenomination where schedulecode='" + getschedulecode + "' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";
    }
    //Cash Reoprt denomination
    public String  InsertCashReport(String getschedulecode,String getsalescash,String getsalesreturn,
                                    String getadvance,String getreceiptcash,String getexpense,String getcashinhand,
                                    String getdenominationcash) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "delete from tblcashreport where schedulecode='" + getschedulecode + "' ";
            mDb.execSQL(sql1);
            String sql = "insert into tblcashreport (autonum,schedulecode,vancode,sales,salesreturn,advance,receipt," +
                    " expenses,cash,denominationcash,flag,createddate)  " +
                    " select coalesce(max(autonum),0)+1 ,'" + getschedulecode + "','" + LoginActivity.getvancode + "'," +
                    "'" + getsalescash + "','" + getsalesreturn + "'," +
                    " '"+getadvance+"' ,'"+getreceiptcash+"' ,'"+getexpense+"','"+getcashinhand+"'" +
                    ",'"+getdenominationcash+"',1,datetime('now', 'localtime')   from tblcashreport";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }
    //Check customer already exists
    public String DeleteItemInCart(String getitemcode)
    {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql2 = "delete from tblsalescartdatas  where" +
                    " itemcode='"+getitemcode+"' and  freeflag='' ";
            mDb.execSQL(sql2);

            String sql1= "delete from tblsalescartdatas   where" +
                    " purchaseitemcode='"+getitemcode+"' and  freeflag='freeitem' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "Success";
    }

    //Check customer already exists
    public String DeleteOrderItemInCart(String getitemcode)
    {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql2 = "delete from tblsalesordercartdatas  where" +
                    " itemcode='"+getitemcode+"' and  freeflag='' ";
            mDb.execSQL(sql2);

            String sql1= "delete from tblsalesordercartdatas   where" +
                    " purchaseitemcode='"+getitemcode+"' and  freeflag='freeitem' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "Success";
    }
    //Check customer already exists
    public String DeleteItemOrderInCart(String getitemcode)
    {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql2 = "delete from tblsalesordercartdatas  where" +
                    " itemcode='"+getitemcode+"' and  freeflag='' ";
            mDb.execSQL(sql2);

            String sql1= "delete from tblsalesordercartdatas   where" +
                    " purchaseitemcode='"+getitemcode+"' and  freeflag='freeitem' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "Success";
    }


    //Check customer already exists
    public String CheckCustomerAlreadyExistsCount(String getareacode,String getcustomername)
    {
        String returnval="";
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql1 = "select coalesce(count(*),0) from tblcustomer where areacode='"+getareacode+"' and " +
                    "lower(customername) =lower('"+getcustomername.replaceAll("'","''")+"')  ";
            Cursor mCur = mDb.rawQuery(sql1, null);
            mCur.moveToFirst();
            if(mCur.getString(0).equals("0")){
                returnval=  "Success";
            }
            else
            {
                returnval= "Exists";
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return returnval;
    }
    //Insert Customer Details
    public String  InsertCustomerDetails(String getcustomername,String getcustomernametamil,String getaddress,
                                         String getareacode,String getemailid,String getmobileno,String gettelephoneno,
                                         String getaadharno,String getgstin) {
        String generatecustomercode="";
        try{
            mDb = mDbHelper.getReadableDatabase();
            String getmaxcustomercode= "1";
            String GetDate= GenCreatedDate();
            String sqlc = "select  count(*) from tblcustomer " ;
            Cursor mCurc = mDb.rawQuery(sqlc, null);
            mCurc.moveToFirst();
            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";

            if(getcount.equals("0")){
                String sql1 = "select coalesce(refno,0) from tblmaxcode where code=6";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                getmaxcustomercode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
                if(getmaxcustomercode.equals("0")){
                    getmaxcustomercode ="1";
                }
            }else {
                String sql1 = "select coalesce(max(refno),0)+1 from tblcustomer";
                Cursor mCur = mDb.rawQuery(sql1, null);
                mCur.moveToFirst();
                getmaxcustomercode = (mCur.moveToFirst()) ? mCur.getString(0) : "0";
            }
            String sql2 = "select 'VC' || substr('00'||'"+LoginActivity.getvancode+"', -2, 2) || substr('00000'||'"+getmaxcustomercode+"', -5, 5) ";
            Cursor mCur1 = mDb.rawQuery(sql2, null);
            mCur1.moveToFirst();
            generatecustomercode= (mCur1.moveToFirst())?mCur1.getString(0):"0";

            String businesstype = "1";
            if(LoginActivity.getbusiness_type.equals("2")){
                businesstype = "2";
            }else if(LoginActivity.getbusiness_type.equals("1")){
                businesstype = "1";
            }else{
                businesstype = "3";
            }
            String sql = "insert into tblcustomer (autonum,customercode,customername,customernametamil," +
                    "address,areacode,emailid,mobileno,telephoneno,aadharno,gstin," +
                    " status,makerid,createddate,updateddate,latitude,longitude,flag,schemeapplicable,uploaddocument,refno,business_type) " +
                    " select coalesce(max(autonum),0)+1 ,'" + generatecustomercode + "',('" + getcustomername.replaceAll("'","''") + "')," +
                    "('" + getcustomernametamil.replaceAll("'","''") + "'),'" + getaddress + "'," +
                    " '"+getareacode+"','"+getemailid+"','" + getmobileno + "','" +gettelephoneno+ "'" +
                    " ,'"+getaadharno+"','"+getgstin+"','Active',0,datetime('now', 'localtime')," +
                    "datetime('now', 'localtime'),'0','0',1,'no','','"+getmaxcustomercode+"','"+businesstype+"' from tblcustomer";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return generatecustomercode;

    }
    //Update Customer Details
    public String UpdateCustomerDetails(String getcustomername,String getcustomernametamil,String getaddress,
                                        String getareacode,String getemailid,String getmobileno,String gettelephoneno,
                                        String getaadharno,String getgstin,String getcustomercode){
        try{
            String sql1 = "UPDATE 'tblcustomer' SET " +
                    " emailid='" +  getemailid +"'," +
                    "mobileno='" + getmobileno +"',telephoneno='" + gettelephoneno +"'" +
                    ",aadharno='" + getaadharno +"',gstin='" + getgstin +"',flag=1 " +
                    " WHERE customercode='" + getcustomercode +"' ";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return  "success";
    }
    //Update expense flag
    public String  UpdateExpenseFlag(String gettranasactionno) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql = "update tblexpenses set flag=3,syncstatus=0 where transactionno = '"+gettranasactionno+"' ";
            mDb.execSQL(sql);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return "success";

    }

    //Update Receipt flag
    public String  UpdateReceiptFlag(String gettranasactionno) {
        try{
            mDb = mDbHelper.getReadableDatabase();
            String sql = "update tblreceipt set flag=3,syncstatus=0 where transactionno = '"+gettranasactionno+"'" +
                    "and vancode='"+LoginActivity.getvancode+"' and financialyearcode='"+LoginActivity.getfinanceyrcode+"' ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return "success";

    }
    /*************************************END INSERT UPDATE FUNCTIONALITY******************************/


    /*******************REPORT QUERYS***********************/
    public Cursor GetVanStockCompany(String companycode,String itemtype,String itemsubgroupcode)
    {
        Cursor mCur =null;
        try{
            String getcompanycode="";
            if(companycode.equals("0")){
                getcompanycode = "1=1";
            }else{
                getcompanycode = "b.companycode='"+companycode+"'";
            }


            String getitemsubgroupcode="";
            if(itemsubgroupcode.equals("0")){
                getitemsubgroupcode = "1=1";
            }else{
                getitemsubgroupcode = "d.itemsubgroupcode='"+itemsubgroupcode+"'";
            }

            String getitemtype="";
            if(itemtype.equals("All Items")){
                getitemtype = "1=1";
            }else{
                if(itemtype.equals("Parent")){
                    itemtype = "parent";
                }else{
                    itemtype = "child";
                }
                getitemtype = "b.itemcategory='"+itemtype+"' ";
            }

            String sql="";
            getdate = GenCreatedDate();
            sql = " select b.companycode,f.companyname, f.companynametamil, f.shortname, f.street, f.area, f.mobileno, " +
                    " f.gstin, f.city, f.telephone, f.panno, f.pincode  " +
                    " from " +
                    " tblstocktransaction as a inner join tblitemmaster as b on " +
                    " a.itemcode=b.itemcode inner join tblunitmaster as c on b.unitcode=c.unitcode " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    " inner join tblbrandmaster as e on b.brandcode=e.brandcode  inner join tblcompanymaster as f on f.companycode=b.companycode " +
                    " where "+getcompanycode+" and  "+getitemtype+" and "+getitemsubgroupcode+" and a.flag!=3  "  +
                    " group by b.companycode  ";
            //parentcode,itemorder,b.itemname

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }


        return mCur;
    }
    public Cursor GetVanStock(String companycode,String itemtype,String itemsubgroupcode)
    {
        Cursor mCur =null;
        try{
            String getcompanycode="";
            if(companycode.equals("0")){
                getcompanycode = "1=1";
            }else{
                getcompanycode = "b.companycode='"+companycode+"'";
            }


            String getitemsubgroupcode="";
            if(itemsubgroupcode.equals("0")){
                getitemsubgroupcode = "1=1";
            }else{
                getitemsubgroupcode = "d.itemsubgroupcode='"+itemsubgroupcode+"'";
            }

            String getitemtype="";
            if(itemtype.equals("All Items")){
                getitemtype = "1=1";
            }else{
                if(itemtype.equals("Parent")){
                    itemtype = "parent";
                }else{
                    itemtype = "child";
                }
                getitemtype = "b.itemcategory='"+itemtype+"' ";
            }

            String sql="";
            getdate = GenCreatedDate();
            sql = " select  * from  (select b.itemnametamil,c.unitname,coalesce((select Sum(op)+Sum(inward)-sum(outward)" +
                    " from tblstocktransaction where itemcode=a.itemcode " +
                    " and datetime(transactiondate)<datetime('" + getdate + "') and flag!=3),0) as op," +
                    " coalesce((select Sum(inward) from tblstocktransaction where itemcode=a.itemcode " +
                    " and datetime(transactiondate)=datetime('" + getdate + "')  and flag!=3 ),0) as inward, " +
                    " coalesce((select Sum(outward) from tblstocktransaction where itemcode=a.itemcode " +
                    " and datetime(transactiondate)=datetime('" + getdate + "') and type!='sales' and  type!='salescancel'  and flag!=3  ),0) as outward," +
                    " coalesce((select sum(op)+sum(inward)-sum(outward) from tblstocktransaction" +
                    " where itemcode=a.itemcode " +
                    " and datetime(transactiondate)<=datetime('" + getdate + "')  and flag!=3 ),0) as closing,c.noofdecimals," +
                    " case when parentitemcode=0 then b.itemcode else b.parentitemcode " +
                    " end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder," +
                    " d.itemsubgroupname,e.brandname," +
                    " coalesce((Select colourcode from tblcompanymaster where companycode=b.companycode),'#000000') as colourcode," +
                    " coalesce((select Sum(outward) from tblstocktransaction where itemcode=a.itemcode " +
                    " and datetime(transactiondate)=datetime('" + getdate + "') and (type='sales' or type='salescancel') and flag!=3 ),0) as sales " +
                    " from " +
                    " tblstocktransaction as a inner join tblitemmaster as b on " +
                    " a.itemcode=b.itemcode inner join tblunitmaster as c on b.unitcode=c.unitcode " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    " inner join tblbrandmaster as e on b.brandcode=e.brandcode " +
                    " where "+getcompanycode+"  and "+getitemtype+" and "+getitemsubgroupcode+" and a.flag!=3  "  +
                    " group by b.itemname,c.unitname" +
                    " order by d.itemgroupcode,d.itemsubgroupcode,e.brandname,b.itemcategory desc ) as dev where dev.op!=0 " +
                    " or dev.inward!=0 or dev.outward!=0 or dev.sales!=0";
            //parentcode,itemorder,b.itemname

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    public Cursor Getcompanydetails(String companycode,String fromdate,String todate)
    {

        Cursor mCur =null;
        try{
            String sql,getcompany;

            if(companycode.equals("0") || companycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="d.companycode in ('"+companycode+"') ";
            }


            sql="select distinct a.companycode, a.companyname, a.companynametamil, a.shortname, a.street, a.area, a.mobileno," +
                    "  a.gstin, a.city, a.telephone, a.panno, a.pincode,d.schedulecode from tblcompanymaster as a inner join " +
                    " tblsales as d on d.companycode=a.companycode where datetime(d.billdate) = datetime('"+fromdate+"') "  +
                    "    and d.flag!=3 and d.flag!=6" +
                    "  and a.status='"+statusvar+"' and "+ getcompany+" order by a.companycode asc";

            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor Getsalesreturncompanydetails(String companycode,String fromdate,String todate)
    {
        Cursor mCur =null;
        try{
            String sql,getcompany;

            if(companycode.equals("0") || companycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="d.companycode in ('"+companycode+"') ";
            }


            sql="select distinct a.companycode, a.companyname, a.companynametamil, a.shortname, a.street, a.area, a.mobileno," +
                    "  a.gstin, a.city, a.telephone, a.panno, a.pincode,d.schedulecode from tblcompanymaster as a inner join " +
                    " tblsalesreturn as d on d.companycode=a.companycode where datetime(d.billdate) = datetime('"+fromdate+"') "  +
                    "  and d.flag!=3 and d.flag!=6" +
                    "  and a.status='"+statusvar+"' and "+ getcompany+" order by a.companycode asc ";

             mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor Getsalesordercompanydetails(String fromdate,String todate)
    {
        Cursor mCur =null;
        try{
            String sql,getcompany;

          /*  if(companycode.equals("0") || companycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="d.companycode in ('"+companycode+"') ";
            }*/


            sql="select distinct a.companycode, a.companyname, a.companynametamil, a.shortname, a.street, a.area, a.mobileno," +
                    "  a.gstin, a.city, a.telephone, a.panno, a.pincode,c.schedulecode from tblcompanymaster as a inner join " +
                    " tblsalesreturn as d on d.companycode=a.companycode  inner join tblsalesorder as c on c.transactionno = d.transactionno" +
                    " where datetime(c.billdate) = datetime('"+fromdate+"') "  +
                    "  and c.flag!=3 and c.flag!=6" +
                    "  and a.status='"+statusvar+"'   order by a.companycode asc ";

            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    public Cursor GetSalesItemWiseReport_Date(String fromdate,String getcompanycode)
    {
        Cursor mCur =null;
        try{
            String sql,getcompany;

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="d.companycode='"+getcompanycode+"'";
            }

            sql="SELECT a.itemcode,COALESCE(itemnametamil,itemname) as itemname,COALESCE(sum(qty),0) " +
                    " as quantity,u.unitname,cast(sum(COALESCE(amount,0)) as decimal(32,2)) " +
                    "as totalamt, case when parentitemcode=0 then i.itemcode else i.parentitemcode " +
                    "  end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  e.itemsubgroupname,g.brandname," +
                    " coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " FROM tblsalesitemdetails as a inner join tblitemmaster " +
                    " as i on i.itemcode=a.itemcode  inner join tblunitmaster as u " +
                    " on u.unitcode=i.unitcode inner join tblsales as d on d.transactionno=a.transactionno" +
                    " and d.companycode=a.companycode inner join tblitemsubgroupmaster as e on  " +
                    " e.itemsubgroupcode=i.itemsubgroupcode inner join tblbrandmaster as g on g.brandcode=i.brandcode  " +
                    " where "+ getcompany +" and  datetime(d.billdate) = datetime('"+fromdate+"') " +
                    "  and d.flag!=3 and d.flag!=6 group by a.itemcode  " +
                    " order by  e.itemgroupcode,e.itemsubgroupcode,g.brandname,i.itemcategory desc";
            //group by a.itemcode ,itemname,itemnametamil,u.unitname
            //,parentcode,itemorder,i.itemname
            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor GetSalesReturnItemWiseReport_Date(String fromdate,String getcompanycode)
    {
        Cursor mCur =null;
        try{
            String sql,getcompany;

            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="d.companycode='"+getcompanycode+"'";
            }

            sql="SELECT a.itemcode,COALESCE(itemnametamil,itemname) as itemname,COALESCE(sum(qty),0) as quantity," +
                    " u.unitname,cast(sum(COALESCE(amount,0)) as decimal(32,2)) " +
                    "as totalamt , case when parentitemcode=0 then i.itemcode else i.parentitemcode " +
                    "  end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  e.itemsubgroupname,g.brandname," +
                    "  coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " FROM tblsalesreturnitemdetails as a inner join " +
                    " tblitemmaster as i on i.itemcode=a.itemcode  inner join tblunitmaster as " +
                    " u on u.unitcode=i.unitcode inner join tblsalesreturn as d on d.transactionno=a.transactionno " +
                    " and d.companycode=a.companycode inner join tblitemsubgroupmaster as e on " +
                    " e.itemsubgroupcode=i.itemsubgroupcode inner join tblbrandmaster as g on g.brandcode=i.brandcode  " +
                    " where "+ getcompany +" and  datetime(d.billdate) = datetime('"+fromdate+"')" +
                    "  and d.flag!=3 and d.flag!=6 group by a.itemcode " +
                    " order by  e.itemgroupcode,e.itemsubgroupcode,g.brandname,i.itemcategory desc";

            //parentcode,itemorder,i.itemname

            //group by a.itemcode,itemname,itemnametamil,u.unitname
            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    public Cursor GetSalesOrderItemWiseReport_Date(String fromdate)
    {
        Cursor mCur =null;
        try{
            String sql;


            sql="SELECT a.itemcode,COALESCE(itemnametamil,itemname) as itemname,COALESCE(sum(qty),0) as quantity," +
                    " u.unitname,cast(sum(COALESCE(amount,0)) as decimal(32,2)) " +
                    "as totalamt , case when parentitemcode=0 then i.itemcode else i.parentitemcode " +
                    "  end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  e.itemsubgroupname,g.brandname," +
                    "  coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " FROM tblsalesorderitemdetails as a inner join " +
                    " tblitemmaster as i on i.itemcode=a.itemcode  inner join tblunitmaster as " +
                    " u on u.unitcode=i.unitcode inner join tblsalesorder as d on d.transactionno=a.transactionno " +
                    " inner join tblitemsubgroupmaster as e on " +
                    " e.itemsubgroupcode=i.itemsubgroupcode inner join tblbrandmaster as g on g.brandcode=i.brandcode  " +
                    " where    datetime(d.billdate) = datetime('"+fromdate+"')" +
                    "  and d.flag!=3 and d.flag!=6 group by a.itemcode " +
                    " order by  e.itemgroupcode,e.itemsubgroupcode,g.brandname,i.itemcategory desc";

            //parentcode,itemorder,i.itemname

            //group by a.itemcode,itemname,itemnametamil,u.unitname
            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    public Cursor GetSalesOrderItemCompanyWiseReport_Date(String fromdate,String getcompanycode)
    {
        Cursor mCur =null;
        try{
            String sql,getcompany;


            if(getcompanycode.equals("0") || getcompanycode.equals("")) {
                getcompany = "1=1";
            }else{
                getcompany="a.companycode='"+getcompanycode+"'";
            }
            sql="SELECT a.itemcode,COALESCE(itemnametamil,itemname) as itemname,COALESCE(sum(qty),0) as quantity," +
                    " u.unitname,cast(sum(COALESCE(amount,0)) as decimal(32,2)) " +
                    "as totalamt , case when parentitemcode=0 then i.itemcode else i.parentitemcode " +
                    "  end as parentcode,case when itemcategory='parent' then 1 else  2 end as itemorder, " +
                    "  e.itemsubgroupname,g.brandname," +
                    "  coalesce((Select colourcode from tblcompanymaster where companycode=a.companycode),'#000000') as colourcode" +
                    " FROM tblsalesorderitemdetails as a inner join " +
                    " tblitemmaster as i on i.itemcode=a.itemcode  inner join tblunitmaster as " +
                    " u on u.unitcode=i.unitcode inner join tblsalesorder as d on d.transactionno=a.transactionno " +
                    " inner join tblitemsubgroupmaster as e on " +
                    " e.itemsubgroupcode=i.itemsubgroupcode inner join tblbrandmaster as g on g.brandcode=i.brandcode  " +
                    " where  "+ getcompany +" and   datetime(d.billdate) = datetime('"+fromdate+"')" +
                    "  and d.flag!=3 and d.flag!=6 group by a.itemcode " +
                    " order by  e.itemgroupcode,e.itemsubgroupcode,g.brandname,i.itemcategory desc";

            //parentcode,itemorder,i.itemname

            //group by a.itemcode,itemname,itemnametamil,u.unitname
            mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }
    /*******************END REPORT QUERYS***********************/
    //Backup DB
    public String udfnBackupdb(Context context)
    {
        String filename="";
        try{
            filename=mDbHelper.udfnBackupdb(context);

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return filename;
    }



    /*******************SYNCH DETAILES*****************************/

    //Sync van master to sqllite table
    //column name
    //"autonum"
    //"vancode"
    //"vanname"
    //"imeino"
    //"pin"
    //"createddate"
    //"updateddate"
    //"makerid"
    //"status"
    public void syncvanmaster (JSONObject object)
    {
        try{

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblvanmaster'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                           // if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblvanmaster' WHERE vancode=" + obj.getInt("vancode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblvanmaster' VALUES(" + Integer.toString(gc)
                                            + ",'" + obj.getInt("vancode") + "','" + obj.getString("vanname").replaceAll("'","''") + "','"+obj.getString("imeino")+"'," +
                                            " '" + obj.getString("pin") + "','" + obj.getString("createddate") + "' ,'" + obj.getString("updateddate") + "' ," +
                                            " '" + obj.getString("makerid") + "','" + obj.getString("status") + "','" + obj.getString("business_type") + "','" + obj.getString("orderprint") + "')";
                                    mDb.execSQL(sql);
                                }

                            //}
                            /*else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblvanmaster' SET autonum='" +
                                        gc + "', vanname='" + obj.getString("vanname") + "'," +
                                        "imeino='" + obj.getString("imeino") + "',pin='" + obj.getString("pin") + "' ," +
                                        "createddate='" + obj.getString("createddate") + "' ," +
                                        "updateddate='" + obj.getString("updateddate") + "', " +
                                        "makerid='" + obj.getString("makerid") + "' ," +
                                        "status='" + obj.getString("status") + "' " +
                                        " WHERE vancode=" + obj.getInt("vancode");
                                mDb.execSQL(sql1);
                            }*/
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    public void deletevanmaster ()
    {
        try{
            String sql1="DELETE FROM 'tblvanmaster'";
            mDb.execSQL(sql1);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //Sync barnd master to sqlite
    //column name
//    "autonum"
//    "brandcode"
//    "brandname"
//    "brandnametamil"
//    "status"
//    "createddate"
//    "updateddate"
//    "makerid"
    public void syncbrandmaster (JSONObject object)
    {

        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblbrandmaster' WHERE brandcode=" + obj.getInt("brandcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblbrandmaster' VALUES(" + Integer.toString(gc)
                                            + ",'" + obj.getInt("brandcode") + "','" + obj.getString("brandname").replaceAll("'","''") + "','"+obj.getString("brandnametamil").replaceAll("'","''")+"', " +
                                            " '" + obj.getString("status") + "','" + obj.getString("createddate") + "' ,'" + obj.getString("updateddate") + "' ," +
                                            " '" + obj.getString("makerid") + "')";
                                    mDb.execSQL(sql);
                                }
                                else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblbrandmaster' SET autonum='" +
                                            gc + "', brandname='" + obj.getString("brandname").replaceAll("'","''") + "'," +
                                            "brandnametamil='" + obj.getString("brandnametamil").replaceAll("'","''") + "',status='" + obj.getString("status") + "' ," +
                                            "createddate='" + obj.getString("createddate") + "' ," +
                                            "updateddate='" + obj.getString("updateddate") + "', " +
                                            "makerid='" + obj.getString("makerid") + "'  " +
                                            " WHERE brandcode=" + obj.getInt("brandcode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblbrandmaster' SET autonum='" +
                                        gc + "', brandname='" + obj.getString("brandname").replaceAll("'","''") + "'," +
                                        "brandnametamil='" + obj.getString("brandnametamil").replaceAll("'","''") + "',status='" + obj.getString("status") + "' ," +
                                        "createddate='" + obj.getString("createddate") + "' ," +
                                        "updateddate='" + obj.getString("updateddate") + "', " +
                                        "makerid='" + obj.getString("makerid") + "'  " +
                                        " WHERE brandcode=" + obj.getInt("brandcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Sync area mater to sqlite
    //column name
//        "autonum"
//        "citycode"
//        "areacode"
//        "areaname"
//        "areanametamil"
//        "noofkm"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"

    public void syncareamaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {

                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblareamaster' WHERE areacode=" + obj.getInt("areacode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblareamaster' VALUES(" + Integer.toString(gc)
                                            + ",'" + obj.getString("citycode") + "','" + obj.getString("areacode") + "','" + obj.getString("areaname").replaceAll("'","''") + "','"+obj.getString("areanametamil").replaceAll("'","''")+"','"+obj.getString("noofkm")+"', " +
                                            " '" + obj.getString("status") + "','" + obj.getString("makerid") + "' ,'" + obj.getString("createddate") + "' ," +
                                            " '" + obj.getString("updateddate") + "')";
                                    mDb.execSQL(sql);
                                }else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblareamaster' SET autonum='" +
                                            gc + "', citycode='" + obj.getString("citycode") + "'," +
                                            "areaname='" + obj.getString("areaname").replaceAll("'","''") + "'," +
                                            " areanametamil='" + obj.getString("areanametamil").replaceAll("'","''") + "'," +
                                            "noofkm='" + obj.getString("noofkm") + "',status='" + obj.getString("status") + "' ," +
                                            "createddate='" + obj.getString("createddate") + "' ," +
                                            "updateddate='" + obj.getString("updateddate") + "', " +
                                            "makerid='" + obj.getString("makerid") + "'  " +
                                            " WHERE areacode=" + obj.getInt("areacode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblareamaster' SET autonum='" +
                                        gc + "', citycode='" + obj.getString("citycode") + "'," +
                                        "areaname='" + obj.getString("areaname").replaceAll("'","''") + "'," +
                                        " areanametamil='" + obj.getString("areanametamil").replaceAll("'","''") + "'," +
                                        "noofkm='" + obj.getString("noofkm") + "',status='" + obj.getString("status") + "' ," +
                                        "createddate='" + obj.getString("createddate") + "' ," +
                                        "updateddate='" + obj.getString("updateddate") + "', " +
                                        "makerid='" + obj.getString("makerid") + "'  " +
                                        " WHERE areacode=" + obj.getInt("areacode");
                                mDb.execSQL(sql1);
                            }
                        } catch (Exception ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync currency to sqlite
    //column name

//    "autonum"
//    "currencycode"
//    "currency"

    public void synccurrency (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblcurrency'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblcurrency' VALUES(" + Integer.toString(gc)
                                    + ",'" + obj.getString("currencycode") + "','" + obj.getString("currency") + "')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Sync Remarks
    public void syncreceiptremarks (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblreceiptremarks'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblreceiptremarks' VALUES(" + Integer.toString(gc)
                                    + ",'" + obj.getString("receiptremarks").replaceAll("'","''") + "','" + obj.getString("receiptremarkscode") + "')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Sync Remarks
    public void synctax (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tbltax'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tbltax' VALUES(" + Integer.toString(gc)
                                    + ",'" + obj.getString("tax") + "','" + obj.getString("status") + "'," +
                                    "'" + obj.getString("makerid") + "','" + obj.getString("createddate") + "'," +
                                    "'" + obj.getString("updateddate") + "')";
                            mDb.execSQL(sql);


                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Sync Remarks
    public void syncbilltype (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblbilltype'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblbilltype' VALUES(" + Integer.toString(gc)
                                    + ",'" + obj.getString("billtype").replaceAll("'","''") + "','" + obj.getString("billtypecode") + "')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //Sync employeemaster to sqlite
    //column name
//    "autonum"
//    "employeecategorycode"
//    "employeecode"
//    "employeename"
//    "employeenametamil"
//    "mobileno"
//    "emailid"
//    "aadharno"
//    "documentupload"
//    "status"
//    "createddate"
//    "updateddate"
//    "makeid"
    public void syncemployeemaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblemployeemaster' WHERE employeecode=" + obj.getInt("employeecode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblemployeemaster' VALUES(" + Integer.toString(gc)
                                            + ",'" + obj.getString("employeecategorycode") + "','" + obj.getString("employeecode") + "','" + obj.getString("employeename").replaceAll("'","''") + "','"+obj.getString("employeenametamil").replaceAll("'","''")+"','"+obj.getString("mobileno")+"', " +
                                            " '" + obj.getString("emailid") + "','" + obj.getString("aadharno") + "','" + obj.getString("documentupload") + "','" + obj.getString("status") + "','" + obj.getString("createddate") + "' ," +
                                            " '" + obj.getString("updateddate") + "','" + obj.getString("makerid") + "' )";
                                    mDb.execSQL(sql);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblemployeemaster' SET autonum='" +
                                        gc + "', employeecategorycode='" + obj.getString("employeecategorycode") + "'," +
                                        "employeename='" + obj.getString("employeename").replaceAll("'","''") + "',employeenametamil='" + obj.getString("employeenametamil").replaceAll("'","''") + "'," +
                                        "mobileno='" + obj.getString("mobileno") + "',emailid='" + obj.getString("emailid") + "',aadharno='" + obj.getString("aadharno") + "'" +
                                        ",documentupload='" + obj.getString("documentupload") + "',status='" + obj.getString("status") + "' ," +
                                        "createddate='" + obj.getString("createddate") + "' ," +
                                        "updateddate='" + obj.getString("updateddate") + "', " +
                                        "makerid='" + obj.getString("makerid") + "'  " +
                                        " WHERE employeecode=" + obj.getInt("employeecode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync employee category to sqlite
    //column name
//    "autonum"
//    "employeecategorycode"
//    "employeecategoryname"

    public void syncemployeecategory (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblemployeecategory'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblemployeecategory' VALUES(" + Integer.toString(gc)
                                    + ",'" + obj.getString("employeecategorycode") + "'," +
                                    " '" + obj.getString("employeecategoryname").replaceAll("'","''") + "')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Sync Customer to sqlite
    //column name
//        "autonum"
//        "customercode"
//        "customername"
//        "customernametamil"
//        "address"
//        "areacode"
//        "emailid"
//        "mobileno"
//        "telephoneno"
//        "aadharno"
//        "gstin"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"
//        "latitude"
//        "longitude","flag","schemeapplicable","uploaddocument"


    public void synccustomer (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblcustomer' WHERE customercode='" + obj.getString("customercode")+"' ";
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblcustomer' (autonum,customercode,refno, customername,customernametamil,address,areacode,emailid,mobileno,telephoneno," +
                                            "aadharno,gstin,status,makerid,createddate,updateddate,latitude,longitude,flag,schemeapplicable,uploaddocument,gstinverificationstatus," +
                                            "customertypecode,business_type)" +
                                            " VALUES('" + gc +"','" + obj.getString("customercode")+"'," +
                                            "'" + obj.getString("refno")+"'," +
                                            "'" + obj.getString("customername").replaceAll("'","''")+"'," +
                                            " '" + obj.getString("customernametamil").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("address").replaceAll("'","''")+"','" + obj.getString("areacode")+"'," +
                                            "'" + obj.getString("emailid")+"','" + obj.getString("mobileno")+"'," +
                                            "'" + obj.getString("telephoneno")+"','" + obj.getString("aadharno")+"'," +
                                            "'" + obj.getString("gstin")+"','" + obj.getString("status")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"','" + obj.getString("latitude")+"'," +
                                            "'" + obj.getString("longitude")+"','2'," +
                                            "'" + obj.getString("schemeapplicable")+"','" + obj.getString("uploaddocument")+"'," +
                                            "'" + obj.getString("gstinverificationstatus")+"','" + obj.getString("customertypecode")+"'," +
                                            " '"+obj.getString("business_type")+"')";
                                    mDb.execSQL(sql);
                                }
                                else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblcustomer' SET autonum='" + gc +"'," +
                                            "customercode='" + obj.getString("customercode")+"'," +
                                            "refno='" + obj.getString("refno")+"'," +
                                            "customername='" + obj.getString("customername").replaceAll("'","''")+"'," +
                                            "customernametamil='" + obj.getString("customernametamil").replaceAll("'","''")+"'," +
                                            "address='" + obj.getString("address").replaceAll("'","''")+"'," +
                                            "areacode='" + obj.getString("areacode")+"',emailid='" + obj.getString("emailid")+"'," +
                                            "mobileno='" + obj.getString("mobileno")+"',telephoneno='" + obj.getString("telephoneno")+"'" +
                                            ",aadharno='" + obj.getString("aadharno")+"',gstin='" + obj.getString("gstin")+"'," +
                                            "status='" + obj.getString("status")+"',makerid='" + obj.getString("makerid")+"'," +
                                            "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"'," +
                                            "latitude='" + obj.getString("latitude")+"',longitude='" + obj.getString("longitude")+"'," +
                                            "schemeapplicable='" + obj.getString("schemeapplicable")+"'," +
                                            "uploaddocument='" + obj.getString("uploaddocument")+"'," +
                                            "customertypecode='"+obj.getString("customertypecode")+"' ," +
                                            "business_type='"+obj.getString("business_type")+"'  " +
                                            " WHERE customercode='" + obj.getString("customercode")+"' ";
                                    mDb.execSQL(sql1);
                                }
                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblcustomer' SET autonum='" + gc +"'," +
                                        "customercode='" + obj.getString("customercode")+"'," +
                                        "refno='" + obj.getString("refno")+"'," +
                                        "customername='" + obj.getString("customername").replaceAll("'","''")+"'," +
                                        "customernametamil='" + obj.getString("customernametamil").replaceAll("'","''")+"'," +
                                        "address='" + obj.getString("address").replaceAll("'","''")+"'," +
                                        "areacode='" + obj.getString("areacode")+"',emailid='" + obj.getString("emailid")+"'," +
                                        "mobileno='" + obj.getString("mobileno")+"',telephoneno='" + obj.getString("telephoneno")+"'" +
                                        ",aadharno='" + obj.getString("aadharno")+"',gstin='" + obj.getString("gstin")+"'," +
                                        "status='" + obj.getString("status")+"',makerid='" + obj.getString("makerid")+"'," +
                                        "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"'," +
                                        "latitude='" + obj.getString("latitude")+"',longitude='" + obj.getString("longitude")+"'," +
                                        "schemeapplicable='" + obj.getString("schemeapplicable")+"'," +
                                        "uploaddocument='" + obj.getString("uploaddocument")+"' ," +
                                        " gstinverificationstatus =  '" + obj.getString("gstinverificationstatus")+"',customertypecode='"+obj.getString("customertypecode")+"' " +
                                        " WHERE customercode='" + obj.getString("customercode")+"' ";
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //Sync company master to sqlite
    //column name
//    "autonum","companycode"
//    "companyname"
//    "shortname"
//    "street"
//    "emailid"
//    "fssaino"
//    "area"
//    "mobileno"
//    "gstin"
//    "city"
//    "telephone"
//    "panno"
//    "pincode"
//    "statecode"
//    "website"
//    "gstcertificateupload"
//    "colourcode"
//    "status"
//    "makerid"
//    "createddate"
//    "updateddate"

    public void synccompanymaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblcompanymaster' WHERE companycode=" + obj.getInt("companycode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblcompanymaster' VALUES('" + gc +"', " +
                                            "'" + obj.getString("companycode")+"'," +
                                            "'" + obj.getString("companyname").replaceAll("'","''")+"','" + obj.getString("companynametamil").replaceAll("'","''")+"','" + obj.getString("shortname").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("street").replaceAll("'","''")+"','" + obj.getString("emailid")+"'," +
                                            "'" + obj.getString("fssaino")+"','" + obj.getString("area")+"'," +
                                            "'" + obj.getString("mobileno")+"','" + obj.getString("gstin")+"'," +
                                            "'" + obj.getString("city")+"','" + obj.getString("telephone")+"'," +
                                            "'" + obj.getString("panno")+"','" + obj.getString("pincode")+"','" + obj.getString("statecode")+"'," +
                                            "'" + obj.getString("website")+"','" + obj.getString("gstcertificateupload")+"'," +
                                            "'" + obj.getString("colourcode")+"','" + obj.getString("status")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                } else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblcompanymaster' SET autonum='" + gc +"',companycode='" + obj.getString("companycode")+"'," +
                                            "companyname='" + obj.getString("companyname").replaceAll("'","''")+"',companynametamil='" + obj.getString("companynametamil").replaceAll("'","''")+"',shortname='" + obj.getString("shortname").replaceAll("'","''")+"'," +
                                            "street='" + obj.getString("street").replaceAll("'","''")+"',emailid='" + obj.getString("emailid")+"'," +
                                            "fssaino='" + obj.getString("fssaino")+"',area='" + obj.getString("area")+"'," +
                                            "mobileno='" + obj.getString("mobileno")+"',gstin='" + obj.getString("gstin")+"'," +
                                            "city='" + obj.getString("city")+"',telephone='" + obj.getString("telephone")+"'," +
                                            "panno='" + obj.getString("panno")+"',pincode='" + obj.getString("pincode")+"'," +
                                            "statecode='" + obj.getString("statecode")+"',website='" + obj.getString("website")+"'," +
                                            "gstcertificateupload='" + obj.getString("gstcertificateupload")+"'," +
                                            "colourcode='" + obj.getString("colourcode")+"',status='" + obj.getString("status")+"'," +
                                            "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                            "updateddate='" + obj.getString("updateddate")+"'  " +
                                            " WHERE companycode=" + obj.getInt("companycode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblcompanymaster' SET autonum='" + gc +"',companycode='" + obj.getString("companycode")+"'," +
                                        "companyname='" + obj.getString("companyname").replaceAll("'","''")+"',companynametamil='" + obj.getString("companynametamil").replaceAll("'","''")+"',shortname='" + obj.getString("shortname").replaceAll("'","''")+"'," +
                                        "street='" + obj.getString("street").replaceAll("'","''")+"',emailid='" + obj.getString("emailid")+"'," +
                                        "fssaino='" + obj.getString("fssaino")+"',area='" + obj.getString("area")+"'," +
                                        "mobileno='" + obj.getString("mobileno")+"',gstin='" + obj.getString("gstin")+"'," +
                                        "city='" + obj.getString("city")+"',telephone='" + obj.getString("telephone")+"'," +
                                        "panno='" + obj.getString("panno")+"',pincode='" + obj.getString("pincode")+"'," +
                                        "statecode='" + obj.getString("statecode")+"',website='" + obj.getString("website")+"'," +
                                        "gstcertificateupload='" + obj.getString("gstcertificateupload")+"'," +
                                        "colourcode='" + obj.getString("colourcode")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"'  " +
                                        " WHERE companycode=" + obj.getInt("companycode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync city master to sqlite
    //column name
//        "autonum"
//        "citycode"
//        "cityname"
//        "citynametamil"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"
    public void synccitymaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblcitymaster' WHERE citycode=" + obj.getInt("citycode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblcitymaster' VALUES('" + gc +"','" + obj.getString("citycode")+"'," +
                                            "'" + obj.getString("cityname").replaceAll("'","''")+"','" + obj.getString("citynametamil").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("status")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                } else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblcitymaster' SET autonum='" + gc +"'," +
                                            "citycode='" + obj.getString("citycode")+"',cityname='" + obj.getString("cityname").replaceAll("'","''")+"'," +
                                            "citynametamil='" + obj.getString("citynametamil").replaceAll("'","''")+"',status='" + obj.getString("status")+"'," +
                                            "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                            "updateddate='" + obj.getString("updateddate")+"'  " +
                                            " WHERE citycode=" + obj.getInt("citycode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblcitymaster' SET autonum='" + gc +"'," +
                                        "citycode='" + obj.getString("citycode")+"',cityname='" + obj.getString("cityname").replaceAll("'","''")+"'," +
                                        "citynametamil='" + obj.getString("citynametamil").replaceAll("'","''")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"'  " +
                                        " WHERE citycode=" + obj.getInt("citycode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    // sync expenses head to sqlite
    //column name

    //        "autonum"
//        "expensesheadcode"
//        "expensesgroupcode"
//        "expenseshead"
//        "expensesheadtamil"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"
    public void syncexpenseshead (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblexpenseshead' WHERE expensesheadcode=" + obj.getInt("expensesheadcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblexpenseshead' VALUES('" + gc +"', " +
                                            "'" + obj.getString("expensesheadcode")+"','" + obj.getString("expensesgroupcode")+"'," +
                                            "'" + obj.getString("expenseshead").replaceAll("'","''")+"','" + obj.getString("expensesheadtamil").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("status")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblexpenseshead' SET autonum='" + gc +"',expensesheadcode='" + obj.getString("expensesheadcode")+"'," +
                                        "expensesgroupcode='" + obj.getString("expensesgroupcode")+"'," +
                                        "expenseshead='" + obj.getString("expenseshead").replaceAll("'","''")+"'," +
                                        "expensesheadtamil='" + obj.getString("expensesheadtamil").replaceAll("'","''")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"' " +
                                        " WHERE expensesheadcode=" + obj.getString("expensesheadcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync financial year
    // column name
//    "autonum"
//    "financialyearcode"
//    "fromdate"
//    "todate"
//    "financialyear"
//    "makerid"
//    "createddate"
//    "updateddate"

    public void syncfinancialyear (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblfinancialyear' WHERE financialyearcode=" + obj.getString("financialyearcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblfinancialyear' VALUES('" + gc +"','" + obj.getString("financialyearcode")+"'," +
                                            "'" + obj.getString("fromdate")+"','" + obj.getString("todate")+"'," +
                                            "'" + obj.getString("financialyear")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                } else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblfinancialyear' SET autonum='" + gc +"'," +
                                            "financialyearcode='" + obj.getString("financialyearcode")+"'," +
                                            "fromdate='" + obj.getString("fromdate")+"',todate='" + obj.getString("todate")+"'," +
                                            "financialyear='" + obj.getString("financialyear")+"',makerid='" + obj.getString("makerid")+"'," +
                                            "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"' " +
                                            " WHERE financialyearcode=" + obj.getString("financialyearcode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblfinancialyear' SET autonum='" + gc +"'," +
                                        "financialyearcode='" + obj.getString("financialyearcode")+"'," +
                                        "fromdate='" + obj.getString("fromdate")+"',todate='" + obj.getString("todate")+"'," +
                                        "financialyear='" + obj.getString("financialyear")+"',makerid='" + obj.getString("makerid")+"'," +
                                        "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"' " +
                                        " WHERE financialyearcode=" + obj.getString("financialyearcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync general settings
    //column namne
//        "autonum"
//        "restrictmobileappdays"
//        "allowedithsn"
//        "allowedittax"
//        "enablebillwisediscount"
//        "enablegpstracking"
//        "internetip"
//        "intranetip"
//        "enableallcustomersmobileapp"
//        "salesschedulemobileapp"
//        "billcopypopup"
//        "drilldownitem"
    public void syncgeneralsettings (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            String sqlc = "select  count(*) from tblgeneralsettings " ;
                            Cursor mCurc = mDb.rawQuery(sqlc, null);
                            mCurc.moveToFirst();
                            String getcount= (mCurc.moveToFirst())?mCurc.getString(0):"0";
                            if(getcount.equals("0")){
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblgeneralsettings' (autonum,restrictmobileappdays,allowedithsn,allowedittax,enablebillwisediscount,enablegpstracking" +
                                        " ,enableallcustomersmobileapp,salesschedulemobileapp,billcopypopup,drilldownitem,wishmsg) VALUES('" + gc +"'," +
                                        "'" + obj.getString("restrictmobileappdays")+"','" + obj.getString("allowedithsn")+"'," +
                                        "'" + obj.getString("allowedittax")+"','" + obj.getString("enablebillwisediscount")+"'," +
                                        "'" + obj.getString("enablegpstracking")+"','" + obj.getString("enableallcustomersmobileapp")+"'," +
                                        "'" + obj.getString("salesschedulemobileapp")+"','" + obj.getString("billcopypopup")+"'," +
                                        "'" + obj.getString("drilldownitem")+"','"+obj.getString("wishmsg")+"' ) ";
                                mDb.execSQL(sql);
                            }else{
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "UPDATE 'tblgeneralsettings' set autonum='"+gc+"'," +
                                        " restrictmobileappdays='" + obj.getString("restrictmobileappdays")+"'," +
                                        " allowedithsn='"+obj.getString("allowedithsn")+"'," +
                                        " allowedittax='"+ obj.getString("allowedittax")+"'," +
                                        " enablebillwisediscount='"+obj.getString("enablebillwisediscount")+"'," +
                                        " enablegpstracking='"+obj.getString("enablegpstracking")+"', " +
                                        " enableallcustomersmobileapp='"+ obj.getString("enableallcustomersmobileapp")+"'," +
                                        " salesschedulemobileapp='"+obj.getString("salesschedulemobileapp")+"'," +
                                        " billcopypopup='"+obj.getString("billcopypopup")+"'," +
                                        " wishmsg='"+obj.getString("wishmsg")+"'," +
                                        " drilldownitem='"+obj.getString("drilldownitem")+"' "  ;
                                mDb.execSQL(sql);
                            }


                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync itemgroup master
    // coumn name
//        "autonum"
//        "itemgroupname"
//        "itemgroupnametamil"
//        "itemgroupcode"
//        "makerid"
//        "createddate"
//        "updateddate"
//        "status"

    public void syncitemgroupmaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblitemgroupmaster' WHERE itemgroupcode=" + obj.getString("itemgroupcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblitemgroupmaster' VALUES('" + gc +"'," +
                                            "'" + obj.getString("itemgroupname").replaceAll("'","''")+"','" + obj.getString("itemgroupnametamil").replaceAll("'","''")+"', " +
                                            "'" + obj.getString("itemgroupcode")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"'," +
                                            "'" + obj.getString("status")+"')";
                                    mDb.execSQL(sql);
                                }   else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblitemgroupmaster' SET autonum='" + gc +"'," +
                                            "itemgroupname='" + obj.getString("itemgroupname").replaceAll("'","''")+"'," +
                                            "itemgroupnametamil='" + obj.getString("itemgroupnametamil").replaceAll("'","''")+"',itemgroupcode='" + obj.getString("itemgroupcode")+"'," +
                                            "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                            "updateddate='" + obj.getString("updateddate")+"',status='" + obj.getString("status")+"' " +
                                            " WHERE itemgroupcode=" + obj.getString("itemgroupcode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblitemgroupmaster' SET autonum='" + gc +"'," +
                                        "itemgroupname='" + obj.getString("itemgroupname").replaceAll("'","''")+"'," +
                                        "itemgroupnametamil='" + obj.getString("itemgroupnametamil").replaceAll("'","''")+"',itemgroupcode='" + obj.getString("itemgroupcode")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"',status='" + obj.getString("status")+"' " +
                                        " WHERE itemgroupcode=" + obj.getString("itemgroupcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync itemmaster to sqlitre
    //column name
//             "autonum"
//            "itemcode"
//            "companycode"
//            "itemsubgroupcode"
//            "brandcode"
//            "manualitemcode"
//            "itemname"
//            "itemnametamil"
//            "unitcode"
//            "unitweightunitcode"
//            "unitweight"
//            "uppunitcode"
//            "uppweight"
//            "itemcategory"
//            "parentitemcode"
//            "allowpriceedit"
//            "allownegativestock"
//            "allowdiscount"
//            "status"
//            "createddate"
//            "updateddate"
//            "makerid"

    public void syncitemmaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblitemmaster' WHERE itemcode=" + obj.getString("itemcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblitemmaster' VALUES('" + gc +"','" + obj.getString("itemcode")+"','" + obj.getString("companycode")+"'," +
                                            "'" + obj.getString("itemsubgroupcode")+"','" + obj.getString("brandcode")+"'," +
                                            "'" + obj.getString("manualitemcode")+"','" + obj.getString("itemname").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("itemnametamil").replaceAll("'","''")+"','" + obj.getString("unitcode")+"'," +
                                            "'" + obj.getString("unitweightunitcode")+"','" + obj.getString("unitweight")+"'," +
                                            "'" + obj.getString("uppunitcode")+"','" + obj.getString("uppweight")+"'," +
                                            "'" + obj.getString("itemcategory")+"','" + obj.getString("parentitemcode")+"'," +
                                            "'" + obj.getString("allowpriceedit")+"','" + obj.getString("allownegativestock")+"'," +
                                            "'" + obj.getString("allowdiscount")+"','" + obj.getString("status")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("upp")+"'," +
                                            "'" + obj.getString("uppweightunitcode")+"','" + obj.getString("offset")+"'," +
                                            "'" + obj.getString("orderstatus")+"','" + obj.getString("maxorderqty")+"' ," +
                                            "'" + obj.getString("business_type")+"')";
                                    mDb.execSQL(sql);
                                } else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblitemmaster' SET autonum='" + gc +"',itemcode='" + obj.getString("itemcode")+"'," +
                                            "companycode='" + obj.getString("companycode")+"'," +
                                            "itemsubgroupcode='" + obj.getString("itemsubgroupcode")+"'," +
                                            "brandcode='" + obj.getString("brandcode")+"',manualitemcode='" + obj.getString("manualitemcode")+"'," +
                                            "itemname='" + obj.getString("itemname").replaceAll("'","''")+"',itemnametamil='" + obj.getString("itemnametamil").replaceAll("'","''")+"',unitcode='" + obj.getString("unitcode")+"'," +
                                            "unitweightunitcode='" + obj.getString("unitweightunitcode")+"'," +
                                            "unitweight='" + obj.getString("unitweight")+"'," +
                                            "uppunitcode='" + obj.getString("uppunitcode")+"'," +
                                            "uppweight='" + obj.getString("uppweight")+"',itemcategory='" + obj.getString("itemcategory")+"'," +
                                            "parentitemcode='" + obj.getString("parentitemcode")+"'," +
                                            "allowpriceedit='" + obj.getString("allowpriceedit")+"'," +
                                            "allownegativestock='" + obj.getString("allownegativestock")+"'," +
                                            "allowdiscount='" + obj.getString("allowdiscount")+"',status='" + obj.getString("status")+"'," +
                                            "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"'," +
                                            "makerid='" + obj.getString("makerid")+"' ,offset='" + obj.getString("offset")+"'," +
                                            "orderstatus='" + obj.getString("orderstatus")+"' ,maxorderqty='" + obj.getString("maxorderqty")+"' ," +
                                            " business_type='" + obj.getString("business_type")+"'" +
                                            " WHERE itemcode=" + obj.getString("itemcode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblitemmaster' SET autonum='" + gc +"',itemcode='" + obj.getString("itemcode")+"'," +
                                        "companycode='" + obj.getString("companycode")+"'," +
                                        "itemsubgroupcode='" + obj.getString("itemsubgroupcode")+"'," +
                                        "brandcode='" + obj.getString("brandcode")+"',manualitemcode='" + obj.getString("manualitemcode")+"'," +
                                        "itemname='" + obj.getString("itemname").replaceAll("'","''")+"',itemnametamil='" + obj.getString("itemnametamil").replaceAll("'","''")+"',unitcode='" + obj.getString("unitcode")+"'," +
                                        "unitweightunitcode='" + obj.getString("unitweightunitcode")+"'," +
                                        "unitweight='" + obj.getString("unitweight")+"'," +
                                        "uppunitcode='" + obj.getString("uppunitcode")+"'," +
                                        "uppweight='" + obj.getString("uppweight")+"',itemcategory='" + obj.getString("itemcategory")+"'," +
                                        "parentitemcode='" + obj.getString("parentitemcode")+"'," +
                                        "allowpriceedit='" + obj.getString("allowpriceedit")+"'," +
                                        "allownegativestock='" + obj.getString("allownegativestock")+"'," +
                                        "allowdiscount='" + obj.getString("allowdiscount")+"',status='" + obj.getString("status")+"'," +
                                        "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"'," +
                                        "makerid='" + obj.getString("makerid")+"' ,offset='" + obj.getString("offset")+"'," +
                                        "orderstatus='" + obj.getString("orderstatus")+"' ,maxorderqty='" + obj.getString("maxorderqty")+"'," +
                                        " business_type='" + obj.getString("business_type")+"'" +
                                        " WHERE itemcode=" + obj.getString("itemcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    public void syncpricelist_every_five_seconds (JSONObject object)
{
    if(object!=null)
    {
        JSONArray json_category = null;

        try {
            String success = object.getString("success");
            if(success.equals("1"))
            {
                json_category = object.getJSONArray("Value");
                for(int i=0;i<json_category.length();i++)
                {
                    try {
                        JSONObject obj = (JSONObject) json_category.get(i);
                        String sql = "SELECT * FROM 'tblitempricelisttransaction' WHERE itemcode=" + obj.getString("itemcode");
                        if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            sql = "INSERT INTO 'tblitempricelisttransaction'(autonum,itemcode,oldprice," +
                                    " newprice,oldorderprice,neworderprice,createddate,wmsrate) VALUES('" + gc +"'," +
                                    "'" + obj.getString("itemcode")+"'" +
                                    ",'" + obj.getString("oldprice")+"', '" + obj.getString("newprice")+"' " +
                                    ",'" + obj.getString("oldorderprice")+"', '" + obj.getString("neworderprice")+"'," +
                                    "'" + obj.getString("createddate")+"','"+obj.getString("wmsrate")+"')";
                            mDb.execSQL(sql);
                        } else {
                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                            String sql1 = "UPDATE 'tblitempricelisttransaction' SET autonum='" + gc +"'," +
                                    "oldprice='" + obj.getString("oldprice")+"'," +
                                    "newprice='" + obj.getString("newprice")+"'," +
                                    "oldorderprice='" + obj.getString("oldorderprice")+"'," +
                                    "neworderprice='" + obj.getString("neworderprice")+"'," +
                                    "createddate='" + obj.getString("createddate")+"',  " +
                                    "wmsrate='" + obj.getString("wmsrate")+"'  " +
                                    " WHERE itemcode=" + obj.getString("itemcode");
                            mDb.execSQL(sql1);
                        }


                    } catch (JSONException ex) {
                        insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    }
                }
            }
        } catch (JSONException ex) {
            // TODO Auto-generated catch block
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }
}

    public void syncorderstatus_every_five_mints (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            String sql = "SELECT * FROM 'tblsalesorder' WHERE transactionno=" + obj.getString("transactionno");

                            String sql1 = "UPDATE 'tblsalesorder' SET  " +
                                    "status='" + obj.getString("status")+"' " +
                                    " WHERE transactionno='" + obj.getString("transactionno")+"' "+
                                    " and vancode='" + obj.getString("vancode")+"' and " +
                                    " bookingno = '"+obj.getString("bookingno")+"' "+
                                    " and financialyearcode='" + obj.getString("financialyearcode")+"' ";
                            mDb.execSQL(sql1);


                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }
    //sync pricelisttransaction to sqlite
    //column name

//   ```` ```` "autonum"
//            "itemcode"
//            "oldprice"
//            "newprice"
//            "transactionno"
//            "transactiondate"
//            "makerid"
//            "createddate"
//            "updateddate"

    public void syncitempricelisttransaction (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblitempricelisttransaction'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblitempricelisttransaction'(autonum,itemcode,oldprice," +
                                    " newprice,oldorderprice,neworderprice,createddate) VALUES('" + gc +"'," +
                                    "'" + obj.getString("itemcode")+"','" + obj.getString("oldprice")+"'," +
                                    " '" + obj.getString("newprice")+"', '" + obj.getString("oldorderprice")+"'," +
                                    "'" + obj.getString("neworderprice")+"','" + obj.getString("createddate")+"')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync itemsubgroupmaster to sqlite
    //column name
//            "autonum"
//        "itemsubgroupcode"
//        "itemsubgroupname"
//        "itemsubgroupnametamil"
//        "itemgroupcode"
//        "hsn"
//        "tax"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"

    public void syncitemsubgroupmaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblitemsubgroupmaster' WHERE itemsubgroupcode=" + obj.getString("itemsubgroupcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblitemsubgroupmaster' VALUES('" + gc +"'," +
                                            "'" + obj.getString("itemsubgroupcode")+"','" + obj.getString("itemsubgroupname").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("itemsubgroupnametamil").replaceAll("'","''")+"','" + obj.getString("itemgroupcode")+"'," +
                                            "'" + obj.getString("hsn")+"','" + obj.getString("tax")+"'," +
                                            "'" + obj.getString("status")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                }else {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblitemsubgroupmaster' SET autonum='" + gc +"'," +
                                            "itemsubgroupcode='" + obj.getString("itemsubgroupcode")+"'," +
                                            "itemsubgroupname='" + obj.getString("itemsubgroupname").replaceAll("'","''")+"',itemsubgroupnametamil='" + obj.getString("itemsubgroupnametamil").replaceAll("'","''")+"'," +
                                            "itemgroupcode='" + obj.getString("itemgroupcode")+"',hsn='" + obj.getString("hsn")+"'," +
                                            "tax='" + obj.getString("tax")+"',status='" + obj.getString("status")+"'," +
                                            "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                            "updateddate='" + obj.getString("updateddate")+"' " +
                                            " WHERE itemsubgroupcode=" + obj.getString("itemsubgroupcode");
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblitemsubgroupmaster' SET autonum='" + gc +"'," +
                                        "itemsubgroupcode='" + obj.getString("itemsubgroupcode")+"'," +
                                        "itemsubgroupname='" + obj.getString("itemsubgroupname").replaceAll("'","''")+"',itemsubgroupnametamil='" + obj.getString("itemsubgroupnametamil").replaceAll("'","''")+"'," +
                                        "itemgroupcode='" + obj.getString("itemgroupcode")+"',hsn='" + obj.getString("hsn")+"'," +
                                        "tax='" + obj.getString("tax")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"' " +
                                        " WHERE itemsubgroupcode=" + obj.getString("itemsubgroupcode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync route to sqlite
    //column name
//        "autonum"
//        "routecode"
//        "routename"
//        "routenametamil"
//        "routeday"
//        "status"
//        "makerid"
//        "createddate"
//        "updateddate"
    public void syncroute (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblroute' WHERE routecode=" + obj.getString("routecode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblroute' VALUES('" + gc +"','" + obj.getString("routecode")+"'," +
                                            "'" + obj.getString("routename").replaceAll("'","''")+"','" + obj.getString("routenametamil")+"'," +
                                            "'" + obj.getString("routeday")+"','" + obj.getString("status")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"','"+obj.getString("vancode")+"'," +
                                            " '"+obj.getString("business_type")+"')";
                                    mDb.execSQL(sql);
                                    String sqldelete="DELETE FROM 'tblroutedetails' where routecode='"+ obj.getString("routecode")+"'";
                                    mDb.execSQL(sqldelete);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblroute' SET autonum='" + gc +"',routecode='" + obj.getString("routecode")+"'," +
                                        "routename='" + obj.getString("routename").replaceAll("'","''")+"',routenametamil='" + obj.getString("routenametamil").replaceAll("'","''")+"'," +
                                        "routeday='" + obj.getString("routeday")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"', " +
                                        "vancode='" + obj.getString("vancode")+"',business_type='"+obj.getString("business_type")+"' " +
                                        " WHERE routecode=" + obj.getString("routecode");
                                mDb.execSQL(sql1);
                                String sqldelete="DELETE FROM 'tblroutedetails' where routecode='"+ obj.getString("routecode")+"'";
                                mDb.execSQL(sqldelete);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync route details
    // column name
//            "autonum"
//            "routecode"
//            "areacode"
//            "allowpriceedit"
//            "createddate"
//            "updateddate"
    public void syncroutedetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                          //  if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblroutedetails' WHERE routecode=" + obj.getString("routecode");
                               // if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblroutedetails' VALUES('" + gc +"'," +
                                            "'" + obj.getString("routecode")+"','" + obj.getString("areacode")+"'," +
                                            "'" + obj.getString("allowpriceedit")+"'," +
                                            "'" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                //}

                           // }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync transport mode
    public void synctransportmode (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tbltransportmode' WHERE transportmodecode=" + obj.getString("transportmodecode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {

                                    sql = "INSERT INTO 'tbltransportmode' VALUES('" + obj.getString("autonum")+"'," +
                                            "'" + obj.getString("transportmodecode")+"'," +
                                            "'" + obj.getString("transportmodetype")+"')";
                                    mDb.execSQL(sql);
                                }

                            }
                            else {
                                String sql1 = "UPDATE 'tbltransportmode' SET autonum='" + obj.getString("autonum")+"'," +
                                        "transportmodetype='" + obj.getString("transportmodetype")+"' " +
                                        " WHERE transportmodecode=" + obj.getString("transportmodecode");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync transport
    public void synctransport (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tbltransportmaster' WHERE transportid=" + obj.getString("transportid");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {

                                    sql = "INSERT INTO 'tbltransportmaster' VALUES('" + obj.getString("transportid")+"'," +
                                            "'" + obj.getString("transportname").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("vechicle_number")+"'," +
                                            "'" + obj.getString("contact_name")+"','" + obj.getString("contact_number")+"'," +
                                            "'" + obj.getString("city")+"', '"+obj.getString("transportmodecode")+"', " +
                                            "'" + obj.getString("createddate")+"','"+obj.getString("updateddate")+"'," +
                                            " '"+obj.getString("makerid")+"','"+obj.getString("status")+"')";
                                    mDb.execSQL(sql);
                                }

                            }
                            else {
                                String sql1 = "UPDATE 'tbltransportmaster' SET transportname='" + obj.getString("transportname").replaceAll("'","''")+"'," +
                                        "vechicle_number='" + obj.getString("vechicle_number")+"',contact_name='" + obj.getString("contact_name").replaceAll("'","''")+"'," +
                                        "contact_number='" + obj.getString("contact_number")+"',city='" + obj.getString("city")+"'," +
                                        "transportmodecode='" + obj.getString("transportmodecode")+"'," +
                                        "createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"', " +
                                        "makerid='" + obj.getString("makerid")+"',status='"+obj.getString("status")+"' " +
                                        " WHERE transportid=" + obj.getString("transportid");
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync transport
    public void synctransportareamapping (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tbltransportcitymapping' WHERE transportid='" + obj.getString("transportid") +"' and citycode='" + obj.getString("citycode") +"' ";
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {

                                    sql = "INSERT INTO 'tbltransportcitymapping' VALUES('" + obj.getString("citymappingid")+"'," +
                                            "'" + obj.getString("transportid")+"'," +
                                            "'" + obj.getString("citycode")+"','" + obj.getString("day_of_dispatch")+"', " +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);
                                } else {
                                    String sql1 = "UPDATE 'tbltransportcitymapping' SET citymappingid='" + obj.getString("citymappingid")+"'," +
                                            "citycode='" + obj.getString("citycode")+"',day_of_dispatch='" + obj.getString("day_of_dispatch")+"'" +
                                            ",createddate='" + obj.getString("createddate")+"'," +
                                            "updateddate='" + obj.getString("updateddate")+"'  " +
                                            " WHERE transportid='" + obj.getString("transportid") +"' and citycode='" + obj.getString("citycode") +"' ";
                                    mDb.execSQL(sql1);
                                }

                            }
                            else {
                                String sql1 = "UPDATE 'tbltransportcitymapping' SET citymappingid='" + obj.getString("citymappingid")+"'," +
                                        "citycode='" + obj.getString("citycode")+"',day_of_dispatch='" + obj.getString("day_of_dispatch")+"'" +
                                        ",createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"'  " +
                                        " WHERE transportid='" + obj.getString("transportid") +"' and citycode='" + obj.getString("citycode") +"' ";
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }
    //sync sales schedule
    //column name
//        "autonum"
//        "refno"
//        "schedulecode"
//        "scheduledate"
//        "vancode"
//        "routecode"
//        "vehiclecode"
//        "employeecode"
//        "drivercode"
//        "helpername"
//        "tripadvance"
//        "startingkm"
//        "endingkm"
//        "createddate"
//        "updatedate"
//        "makerid"
//        "flag"
    public void syncsalesschedule (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {


                                String sql = "SELECT * FROM 'tblsalesschedule' WHERE schedulecode='" + obj.getString("schedulecode")+"' ";
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String vartripadvance = obj.isNull("tripadvance") ? "0" : obj.getString("tripadvance");
                                    if(vartripadvance.equals("")){
                                        vartripadvance="0";
                                    }
                                    sql = "INSERT INTO 'tblsalesschedule' (autonum, refno,schedulecode, scheduledate,vancode,routecode,vehiclecode,employeecode, drivercode,helpername," +
                                            "tripadvance,startingkm,endingkm,createddate, updateddate,makerid,flag,lunch_start_time,lunch_end_time) VALUES('" + gc +"','" + obj.getString("refno")+"'," +
                                            "'" + obj.getString("schedulecode")+"','" + obj.getString("scheduledate")+"','" + obj.getString("vancode")+"'," +
                                            "'" + obj.getString("routecode")+"','" + obj.getString("vehiclecode")+"','" + obj.getString("employeecode")+"'," +
                                            "'" + obj.getString("drivercode")+"','" + obj.getString("helpername").replaceAll("'","''")+"','" + vartripadvance +"'," +
                                            "'" + obj.getString("startingkm")+"','" + obj.getString("endingkm")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"','" + obj.getString("makerid")+"',1,'" + obj.getString("lunch_start_time")+"','" + obj.getString("lunch_end_time")+"')";
                                    mDb.execSQL(sql);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String vartripadvance = obj.isNull("tripadvance") ? "0" : obj.getString("tripadvance");
                                if(vartripadvance.equals("")){
                                    vartripadvance="0";
                                }
                                String sql1 = "UPDATE 'tblsalesschedule' SET autonum='" + gc +"',schedulecode='" + obj.getString("schedulecode")+"'," +
                                        "refno='" + obj.getString("refno")+"',scheduledate='" + obj.getString("scheduledate")+"'," +
                                        "vancode='" + obj.getString("vancode")+"',routecode='" + obj.getString("routecode")+"'," +
                                        "vehiclecode='" + obj.getString("vehiclecode")+"',employeecode='" + obj.getString("employeecode")+"'," +
                                        "drivercode='" + obj.getString("drivercode")+"',helpername='" + obj.getString("helpername").replaceAll("'","''")+"'," +
                                        "tripadvance='" + vartripadvance +"',startingkm='" + obj.getString("startingkm")+"'," +
                                        "endingkm='" + obj.getString("endingkm")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"',makerid='" + obj.getString("makerid")+"'," +
                                        " lunch_start_time='" + obj.getString("lunch_start_time")+"',lunch_end_time='" + obj.getString("lunch_end_time")+"' " +
                                        " WHERE schedulecode='" + obj.getString("schedulecode")+"' ";
                                mDb.execSQL(sql1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sunv scheme to sqlite
    // column name

//            "autonum"
//            "schemecode"
//            "companycode"
//            "schemename"
//            "multipleroutecode"
//            "validityfrom"
//            "validityto"
//            "schemetype"
//            "status"
//            "makerid"
//            "createddate"
//            "updateddate"

    public void syncscheme (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblscheme' WHERE schemecode=" + obj.getString("schemecode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblscheme' VALUES('" + gc +"','" + obj.getString("schemecode")+"'," +
                                            "'" + obj.getString("companycode")+"','" + obj.getString("schemename").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("multipleroutecode")+"','" + obj.getString("validityfrom")+"'," +
                                            "'" + obj.getString("validityto")+"','" + obj.getString("schemetype")+"'," +
                                            "'" + obj.getString("status")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"'," +
                                            " '" + obj.getString("business_type")+"')";
                                    mDb.execSQL(sql);
                                    String sqldelete="DELETE FROM 'tblschemeitemdetails' WHERE schemecode='"+ obj.getString("schemecode") +"'";
                                    mDb.execSQL(sqldelete);

                                    String sqldelete1="DELETE FROM 'tblschemeratedetails' WHERE schemecode='"+ obj.getString("schemecode") +"'";
                                    mDb.execSQL(sqldelete1);
                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblscheme' SET autonum='" + obj.getString("autonum")+"'," +
                                        "schemecode='" + obj.getString("schemecode")+"',companycode='" + obj.getString("companycode")+"'," +
                                        "schemename='" + obj.getString("schemename").replaceAll("'","''")+"',multipleroutecode='" + obj.getString("multipleroutecode")+"'," +
                                        "validityfrom='" + obj.getString("validityfrom")+"',validityto='" + obj.getString("validityto")+"'," +
                                        "schemetype='" + obj.getString("schemetype")+"',status='" + obj.getString("status")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"', " +
                                        "business_type='" + obj.getString("business_type")+"' " +
                                        " WHERE schemecode=" + obj.getString("schemecode");
                                mDb.execSQL(sql1);

                                String sqldelete="DELETE FROM 'tblschemeitemdetails' WHERE schemecode='"+ obj.getString("schemecode") +"'";
                                mDb.execSQL(sqldelete);

                                String sqldelete1="DELETE FROM 'tblschemeratedetails' WHERE schemecode='"+ obj.getString("schemecode") +"'";
                                mDb.execSQL(sqldelete1);
                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync scheme item details
    // column name

//            "autonum"
//            "schemecode"
//            "purchaseitemcode"
//            "purchaseqty"
//            "freeitemcode"
//            "freeqty"
//            "createddate"
//            "updateddate"

    public void syncschemeitemdetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            //if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblschemeitemdetails' WHERE schemecode=" + obj.getString("schemecode");
                               // if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblschemeitemdetails' VALUES('" + gc +"','" + obj.getString("schemecode")+"'," +
                                            "'" + obj.getString("purchaseitemcode")+"','" + obj.getString("purchaseqty")+"'," +
                                            "'" + obj.getString("freeitemcode")+"','" + obj.getString("freeqty")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);

                              //  }

                            //}
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync schemeratedetails
    //column name

    public void syncschemeratedetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            //if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblschemeratedetails' WHERE schemecode=" + obj.getString("schemecode");
                               // if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblschemeratedetails' VALUES('" + obj.getString("autonum")+"'," +
                                            "'" + obj.getString("schemecode")+"','" + obj.getString("itemcode")+"'," +
                                            "'" + obj.getString("minqty")+"','" + obj.getString("discountamount")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);

                                //}

                            //}
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync unitmaster
    //column name

//            "autonum"
//            "unitname"
//            "unitcode"
//            "unitnametamil"
//            "makerid"
//            "noofdecimals"
//            "status"
//            "createddate"
//            "updateddate"

    public void syncunitmaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblunitmaster' WHERE unitcode=" + obj.getString("unitcode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblunitmaster' VALUES('" + gc +"','" + obj.getString("unitname").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("unitcode")+"','" + obj.getString("unitnametamil").replaceAll("'","''")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("noofdecimals")+"'," +
                                            "'" + obj.getString("status")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);

                                }

                            }
                            else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblunitmaster' SET autonum='" + gc +"',unitname='" + obj.getString("unitname").replaceAll("'","''")+"'," +
                                        "unitcode='" + obj.getString("unitcode")+"',unitnametamil='" + obj.getString("unitnametamil").replaceAll("'","''")+"'," +
                                        "makerid='" + obj.getString("makerid")+"',noofdecimals='" + obj.getString("noofdecimals")+"'," +
                                        "status='" + obj.getString("status")+"',createddate='" + obj.getString("createddate")+"'," +
                                        "updateddate='" + obj.getString("updateddate")+"' " +
                                        " WHERE unitcode=" + obj.getString("unitcode");
                                mDb.execSQL(sql1);

                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync vanstock
    //coulmn name
//    ` `"autonum"
//        "transactionno"
//        "transactiondate"
//        "vancode"
//        "itemcode"
//        "inward"
//        "outward"
//        "type"
//        "refno"
//        "createddate"

    public void syncvanstocktransaction (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblstocktransaction'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            int varautonum=i+1;
                            String sql ="";
                            if(obj.getInt("syncautonum")==0){
                                 sql = "INSERT INTO 'tblstocktransaction' (transactionno,transactiondate,vancode,itemcode,inward,outward,type," +
                                        " refno,createddate,flag,companycode,op,financialyearcode,autonum) VALUES('" + obj.getString("transactionno")+"','" + obj.getString("transactiondate")+"'," +
                                        "'" + obj.getString("vancode")+"','" + obj.getString("itemcode")+"'," +
                                        "'" + obj.getString("inward")+"','" + obj.getString("outward")+"','" + obj.getString("type")+"','" + obj.getString("refno")+"'," +
                                        "'" + obj.getString("createddate")+"',1111,'" + obj.getString("companycode")+"','" + obj.getString("op")+"','" + obj.getString("financialyearcode")+"',(select coalesce(max(autonum),0)+1 from tblstocktransaction)+"+varautonum+")";
                            }
                            else{
                                sql = "INSERT INTO 'tblstocktransaction' (transactionno,transactiondate,vancode,itemcode,inward,outward,type," +
                                        " refno,createddate,flag,companycode,op,financialyearcode,autonum) VALUES('" + obj.getString("transactionno")+"','" + obj.getString("transactiondate")+"'," +
                                        "'" + obj.getString("vancode")+"','" + obj.getString("itemcode")+"'," +
                                        "'" + obj.getString("inward")+"','" + obj.getString("outward")+"','" + obj.getString("type")+"','" + obj.getString("refno")+"'," +
                                        "'" + obj.getString("createddate")+"',1111,'" + obj.getString("companycode")+"','" + obj.getString("op")+"','" + obj.getString("financialyearcode")+"','" + obj.getString("syncautonum")+"')";
                            }

                            mDb.execSQL(sql);

                        } catch (JSONException ex) {

                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    public  void  DeleteCashNotPaid(){
        String sql1="DELETE FROM 'tblcashnotpaiddetails'";
        mDb.execSQL(sql1);
    }

    public void synccashnotpaiddetails(JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblcashnotpaiddetails'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            int varautonum=i+1;
                            String sql ="";
                                sql = "INSERT INTO 'tblcashnotpaiddetails' (autonum,transactionno,bookingno,customercode,grandtotal,customernametamil,schedulecode," +
                                        " areanametamil) VALUES('"+varautonum+"','" + obj.getString("transactionno")+"'," +
                                        "'" + obj.getString("bookingno")+"','" + obj.getString("customercode")+"'," +
                                        "'" + obj.getString("grandtotal")+"','" + obj.getString("customernametamil")+"'," +
                                        " '" + obj.getString("schedulecode")+"','" + obj.getString("areanametamil")+"' )";

                            mDb.execSQL(sql);

                        } catch (JSONException ex) {

                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync vehicle master
    // column name
//
//    "autonum"
//            "vehiclecode"
//            "vehiclename"
//            "modelandyear"
//            "registrationno"
//            "capacity"
//            "fc"
//            "permit"
//            "insurance"
//            "documentupload"
//            "status"
//            "makerid"
//            "createddate"
//            "updateddate"

    public void syncvehiclemaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {
                                String sql = "SELECT * FROM 'tblvehiclemaster' WHERE vehiclecode=" + obj.getString("vehiclecode");
                                if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    sql = "INSERT INTO 'tblvehiclemaster' VALUES('" + gc +"','" + obj.getString("vehiclecode")+"'," +
                                            "'" + obj.getString("vehiclename").replaceAll("'","''")+"','" + obj.getString("modelandyear")+"'," +
                                            "'" + obj.getString("registrationno")+"','" + obj.getString("capacity")+"'," +
                                            "'" + obj.getString("fc")+"','" + obj.getString("permit")+"','" + obj.getString("insurance")+"'," +
                                            "'" + obj.getString("documentupload")+"','" + obj.getString("status")+"','" + obj.getString("makerid")+"'," +
                                            "'" + obj.getString("createddate")+"','" + obj.getString("updateddate")+"')";
                                    mDb.execSQL(sql);

                                }

                            } else {
                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                String sql1 = "UPDATE 'tblvehiclemaster' SET autonum='" + gc +"'," +
                                        "vehiclecode='" + obj.getString("vehiclecode")+"',vehiclename='" + obj.getString("vehiclename").replaceAll("'","''")+"'," +
                                        "modelandyear='" + obj.getString("modelandyear")+"'," +
                                        "registrationno='" + obj.getString("registrationno")+"'," +
                                        "capacity='" + obj.getString("capacity")+"'," +
                                        "fc='" + obj.getString("fc")+"',permit='" + obj.getString("permit")+"'," +
                                        "insurance='" + obj.getString("insurance")+"',documentupload='" + obj.getString("documentupload")+"'," +
                                        "status='" + obj.getString("status")+"',makerid='" + obj.getString("makerid")+"'," +
                                        "createddate='" + obj.getString("createddate")+"',updateddate='" + obj.getString("updateddate")+"' " +
                                        " WHERE vehiclecode=" + obj.getString("vehiclecode");
                                mDb.execSQL(sql1);

                            }
                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync voucher setiings
    //column name
//
//    "autonum"
//            "vancode"
//            "companycode"
//            "billtypecode"
//            "prefix"
//            "suffix"
//            "startingno"
//            "noofdigit"
//            "type"
//            "financialyearcode"
//            "createddate"
//            "updateddate"


    public void syncvouchersettings (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblvouchersettings'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblvouchersettings' VALUES('" + gc +"'," +
                                    "'" + obj.getString("vancode")+"','" + obj.getString("companycode")+"'," +
                                    "'" + obj.getString("billtypecode")+"','" + obj.getString("prefix")+"'," +
                                    "'" + obj.getString("suffix")+"','" + obj.getString("startingno")+"'," +
                                    "'" + obj.getString("noofdigit")+"','" + obj.getString("type")+"'," +
                                    "'" + obj.getString("financialyearcode")+"','" + obj.getString("createddate")+"'," +
                                    "'" + obj.getString("updateddate")+"')";
                            mDb.execSQL(sql);

                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    // sync expenses master
    // column name
//            "autonum"
//            "transactionno"
//            "transactiondate"
//            "expensesheadcode"
//            "amount"
//            "remarks"
//            "makerid"
//            "createdate"
//            "schedulecode"
//            "financialyearcode"
//            "vancode"
//            "flag"
    public void syncexpensesmaster (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblexpenses'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblexpenses' (autonum,transactionno,transactiondate,expensesheadcode,amount,remarks," +
                                        "makerid,createdate,schedulecode, financialyearcode,vancode,flag,syncstatus) VALUES('" + gc + "','" + obj.getString("transactionno") + "'," +
                                        "'" + obj.getString("transactiondate") + "'," +
                                        "'" + obj.getString("expensesheadcode") + "','" + obj.getString("amount") + "'," +
                                        "'" + obj.getString("remarks") + "','" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createdate") + "','" + obj.getString("schedulecode") + "'," +
                                        "'" + obj.getString("financialyearcode") + "','" + obj.getString("vancode") + "'," +
                                        "'" + obj.getString("flag") + "',1)";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Syncashclose
    public void synccashclose (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblclosecash'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblclosecash'(autonum,closedate,vancode,schedulecode,makerid,createddate,status,flag,paidparties,expenseentries)" +
                                        " VALUES('" + gc + "','" + obj.getString("closedate") + "'," +
                                        "'" + obj.getString("vancode") + "'," +
                                        "'" + obj.getString("schedulecode") + "','" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "','2','11', " +
                                        "'" + obj.getString("paidparties") + "','" + obj.getString("expenseentries") + "' )";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Synsalesclose
    public void syncsalesclose (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblclosesales'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblclosesales'(autonum,closedate,vancode,schedulecode,makerid,createddate,flag) " +
                                        "VALUES('" + gc + "'," +
                                        " '" + obj.getString("closedate") + "'," +
                                        "'" + obj.getString("vancode") + "'," +
                                        "'" + obj.getString("schedulecode") + "','" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "','11')";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Syncashreport
    public void synccashreport (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblcashreport'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblcashreport'(autonum,schedulecode,vancode,sales,salesreturn,advance,receipt,expenses,cash,denominationcash,makerid,createddate,flag) " +
                                        " VALUES('" + gc + "'," +
                                        " '" + obj.getString("schedulecode") + "'," +
                                        "'" + obj.getString("vancode") + "'," +
                                        "'" + obj.getString("sales") + "','" + obj.getString("salesreturn") + "'," +
                                        "'" + obj.getString("advance") + "'," +
                                        "'" + obj.getString("receipt") + "'," +
                                        "'" + obj.getString("expenses") + "'," +
                                        "'" + obj.getString("cash") + "'," +
                                        "'" + obj.getString("denominationcash") + "'," +
                                        "'" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "'," +
                                        " '11')";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //Syndenomination
    public void syncdenomination (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");

                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tbldenomination'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tbldenomination' VALUES('" + gc + "'," +
                                        " '" + obj.getString("vancode") + "'," +
                                        "'" + obj.getString("schedulecode") + "'," +
                                        "'" + obj.getString("currencycode") + "','" + obj.getString("qty") + "'," +
                                        "'" + obj.getString("amount") + "'," +
                                        "'" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "'," +
                                        " '11')";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync receipt
    // column name

//    "autonum"
//            "transactionno"
//            "receiptdate"
//            "prefix"
//            "suffix"
//            "voucherno"
//            "refno"
//            "companycode"
//            "vancode"
//            "customercode"
//            "schedulecode"
//            "receiptremarkscode"
//            "receiptmode"
//            "chequerefno"
//            "amount"
//            "makerid"
//            "createddate"
//            "financialyearcode"
//            "flag"

    public void syncreceipt (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblreceipt'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);


                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblreceipt' (autonum,transactionno,receiptdate, prefix,suffix,voucherno,refno,companycode,vancode,customercode, " +
                                        "schedulecode,receiptremarkscode,receiptmode,chequerefno,amount, makerid,createddate,financialyearcode,flag,note,syncstatus," +
                                        "receipttime) VALUES('" + gc + "'," +
                                        "'" + obj.getString("transactionno") + "'," +
                                        "'" + obj.getString("receiptdate") + "','" + obj.getString("prefix") + "'," +
                                        "'" + obj.getString("suffix") + "','" + obj.getString("voucherno") + "'," +
                                        "'" + obj.getString("refno") + "','" + obj.getString("companycode") + "'," +
                                        "'" + obj.getString("vancode") + "','" + obj.getString("customercode") + "'," +
                                        "'" + obj.getString("schedulecode") + "','" + obj.getString("receiptremarkscode") + "'," +
                                        "'" + obj.getString("receiptmode") + "','" + obj.getString("chequerefno") + "'," +
                                        "'" + obj.getString("amount") + "','" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "','" + obj.getString("financialyearcode") + "'," +
                                        "'" + obj.getString("flag") + "','" + obj.getString("note") + "',1,'"+obj.getString("receipttime")+"')";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    // sync sales return
    // column name

//    "autonum"
//            "companycode"
//            "vancode"
//            "transactionno"
//            "billno"
//            "refno"
//            "prefix"
//            "suffix"
//            "billdate"
//            "customercode"
//            "billtypecode"
//            "gstin"
//            "schedulecode"
//            "subtotal"
//            "discount"
//            "totaltaxamount"
//            "grandtotal"
//            "billcopystatus"
//            "cashpaidstatus"
//            "flag"
//            "makerid"
//            "createddate"
//            "updateddate"
//            "bitmapimage"
//            "financialyearcode"
//            "remarks"
//            "bookingno"

    public void syncsalesreturn (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesreturn'";

                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                    for(int i=0;i<json_category.length();i++) {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblsalesreturn'(autonum,companycode,vancode,transactionno,billno,refno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                                    "schedulecode,subtotal,discount,totaltaxamount,grandtotal,billcopystatus,cashpaidstatus,flag,makerid,createddate,updateddate,bitmapimage," +
                                    "financialyearcode,remarks,bookingno,syncstatus,salestime,beforeroundoff) VALUES('" + gc + "','" + obj.getString("companycode") + "'," +
                                    "'" + obj.getString("vancode") + "','" + obj.getString("transactionno") + "'," +
                                    "'" + obj.getString("billno") + "','" + obj.getString("refno") + "'," +
                                    "'" + obj.getString("prefix") + "','" + obj.getString("suffix") + "'," +
                                    "'" + obj.getString("billdate") + "','" + obj.getString("customercode") + "'," +
                                    "'" + obj.getString("billtypecode") + "','" + obj.getString("gstin") + "'," +
                                    "'" + obj.getString("schedulecode") + "','" + obj.getString("subtotal") + "'," +
                                    "'" + obj.getString("discount") + "','" + obj.getString("totaltaxamount") + "'," +
                                    "'" + obj.getString("grandtotal") + "','" + obj.getString("billcopystatus") + "'," +
                                    "'" + obj.getString("cashpaidstatus") + "','" + obj.getString("flag") + "'," +
                                    "'" + obj.getString("makerid") + "','" + obj.getString("createddate") + "'," +
                                    "'" + obj.getString("updateddate") + "','" + obj.getString("bitmapimage") + "'," +
                                    "'" + obj.getString("financialyearcode") + "','" + obj.getString("remarks") + "'," +
                                    "'" + obj.getString("bookingno") + "',1,'" + obj.getString("salestime") + "','" + obj.getString("beforeroundoff") + "')";
                            mDb.execSQL(sql);


                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync sales return item details
    //column name

//    "autonum"
//            "transactionno"
//            "companycode"
//            "itemcode"
//            "qty"
//            "price"
//            "discount"
//            "amount"
//            "cgst"
//            "sgst"
//            "igst"
//            "cgstamt"
//            "sgstamt"
//            "igstamt"
//            "freeitemstatus"
//            "makerid"
//            "createddate"
//            "updateddate"

    public void syncsalesreturnitemdetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesreturnitemdetails'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);

                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblsalesreturnitemdetails' VALUES('" + gc + "','" + obj.getString("transactionno") + "'," +
                                        "'" + obj.getString("companycode") + "','" + obj.getString("itemcode") + "','" + obj.getString("qty") + "'," +
                                        "'" + obj.getString("weight") + "','" + obj.getString("price") + "','" + obj.getString("discount") + "'," +
                                        "'" + obj.getString("amount") + "','" + obj.getString("cgst") + "','" + obj.getString("sgst") + "'," +
                                        "'" + obj.getString("igst") + "','" + obj.getString("cgstamt") + "','" + obj.getString("sgstamt") + "'," +
                                        "'" + obj.getString("igstamt") + "','" + obj.getString("freeitemstatus") + "','" + obj.getString("makerid") + "'," +
                                        "'" + obj.getString("createddate") + "','" + obj.getString("updateddate") + "','" + obj.getString("bookingno") + "'," +
                                        " '" + obj.getString("financialyearcode") + "','" + obj.getString("vancode") + "',2)";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {

                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    // sync sales
    // column name
//    "autonum"
//            "companycode"
//            "vancode"
//            "transactionno"
//            "billno"
//            "refno"
//            "prefix"
//            "suffix"
//            "billdate"
//            "customercode"
//            "billtypecode"
//            "gstin"
//            "schedulecode"
//            "subtotal"
//            "discount"
//            "totaltaxamount"
//            "grandtotal"
//            "billcopystatus"
//            "cashpaidstatus"
//            "flag"
//            "makerid"
//            "createddate"
//            "updateddate"
//            "bitmapimage"
//            "financialyearcode"
//            "remarks"
//            "bookingno"
    public void syncsales (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsales'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                    for(int i=0;i<json_category.length();i++) {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblsales' (autonum,companycode,vancode,transactionno,billno,refno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                                    "schedulecode,subtotal,discount,totaltaxamount,grandtotal,billcopystatus,cashpaidstatus,flag,makerid,createddate,updateddate,bitmapimage," +
                                    "financialyearcode,remarks,bookingno,syncstatus,imgflag,salestime,beforeroundoff) VALUES('" + gc + "','" + obj.getString("companycode") + "'," +
                                    "'" + obj.getString("vancode") + "','" + obj.getString("transactionno") + "'," +
                                    "'" + obj.getString("billno") + "','" + obj.getString("refno") + "'," +
                                    "'" + obj.getString("prefix") + "','" + obj.getString("suffix") + "'," +
                                    "'" + obj.getString("billdate") + "','" + obj.getString("customercode") + "'," +
                                    "'" + obj.getString("billtypecode") + "','" + obj.getString("gstin") + "','" + obj.getString("schedulecode") + "'," +
                                    "'" + obj.getString("subtotal") + "','" + obj.getString("discount") + "','" + obj.getString("totaltaxamount") + "'," +
                                    "'" + obj.getString("grandtotal") + "','" + obj.getString("billcopystatus") + "','" + obj.getString("cashpaidstatus") + "'," +
                                    "'" + obj.getString("flag") + "','" + obj.getString("makerid") + "','" + obj.getString("createddate") + "'," +
                                    "'" + obj.getString("updateddate") + "','" + obj.getString("bitmapimage") + "','" + obj.getString("financialyearcode") + "'," +
                                    "'" + obj.getString("remarks") + "','" + obj.getString("bookingno") + "',1,1,'" + obj.getString("salestime") + "','" + obj.getString("beforeroundoff") + "')";
                            mDb.execSQL(sql);


                        } catch (JSONException ex) {

                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //sync sales order
    public void syncsalesorder (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesorder'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for(int i=0;i<json_category.length();i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);

                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblsalesorder' (autonum,companycode,vancode,transactionno,billno,refno,prefix,suffix,billdate,customercode,billtypecode,gstin," +
                                        "schedulecode,subtotal,discount,totaltaxamount,grandtotal,billcopystatus,cashpaidstatus,flag,makerid,createddate,updateddate,bitmapimage," +
                                        "financialyearcode,remarks,bookingno,syncstatus,imgflag,salestime,beforeroundoff,transportid) VALUES('" + gc + "','" + obj.getString("companycode") + "'," +
                                        "'" + obj.getString("vancode") + "','" + obj.getString("transactionno") + "'," +
                                        "'" + obj.getString("billno") + "','" + obj.getString("refno") + "'," +
                                        "'" + obj.getString("prefix") + "','" + obj.getString("suffix") + "'," +
                                        "'" + obj.getString("billdate") + "','" + obj.getString("customercode") + "'," +
                                        "'" + obj.getString("billtypecode") + "','" + obj.getString("gstin") + "','" + obj.getString("schedulecode") + "'," +
                                        "'" + obj.getString("subtotal") + "','" + obj.getString("discount") + "','" + obj.getString("totaltaxamount") + "'," +
                                        "'" + obj.getString("grandtotal") + "','" + obj.getString("billcopystatus") + "','" + obj.getString("cashpaidstatus") + "'," +
                                        "'" + obj.getString("flag") + "','" + obj.getString("makerid") + "','" + obj.getString("createddate") + "'," +
                                        "'" + obj.getString("updateddate") + "','" + obj.getString("bitmapimage") + "','" + obj.getString("financialyearcode") + "'," +
                                        "'" + obj.getString("remarks") + "'," +
                                        "'" + obj.getString("bookingno") + "',1,1," +
                                        "'" + obj.getString("salestime") + "'," +
                                        "'" + obj.getString("beforeroundoff") + "','" + obj.getString("transportid") + "')";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {

                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }
    //sync salesitemdetails
    // column name
//    "autonum"
//            "transactionno"
//            "companycode"
//            "itemcode"
//            "qty"
//            "price"
//            "discount"
//            "amount"
//            "cgst"
//            "sgst"
//            "igst"
//            "cgstamt"
//            "sgstamt"
//            "igstamt"
//            "freeitemstatus"
//            "makerid"
//            "createddate"
//            "updateddate"

    public void syncsalesitemdetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesitemdetails'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                    for(int i=0;i<json_category.length();i++) {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                            String sql = "INSERT INTO 'tblsalesitemdetails' VALUES('" + gc + "'," +
                                    "'" + obj.getString("transactionno") + "','" + obj.getString("companycode") + "','" + obj.getString("itemcode") + "'," +
                                    "'" + obj.getString("qty") + "','" + obj.getString("weight") + "','" + obj.getString("price") + "'," +
                                    "'" + obj.getString("discount") + "','" + obj.getString("amount") + "','" + obj.getString("cgst") + "'," +
                                    "'" + obj.getString("sgst") + "','" + obj.getString("igst") + "','" + obj.getString("cgstamt") + "'," +
                                    "'" + obj.getString("sgstamt") + "','" + obj.getString("igstamt") + "','" + obj.getString("freeitemstatus") + "'," +
                                    "'" + obj.getString("makerid") + "','" + obj.getString("createddate") + "','" + obj.getString("updateddate") + "'" +
                                    ",'" + obj.getString("bookingno") + "','" + obj.getString("financialyearcode") + "','"+obj.getString("vancode")+"',2)";
                            mDb.execSQL(sql);


                        } catch (JSONException ex) {
                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync salesorder
    public void syncsalesorderitemdetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesorderitemdetails'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if (mCur.getInt(0) == 0) {
                        for(int i=0;i<json_category.length();i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);

                                int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                String sql = "INSERT INTO 'tblsalesorderitemdetails' VALUES('" + gc + "'," +
                                        "'" + obj.getString("transactionno") + "','" + obj.getString("companycode") + "','" + obj.getString("itemcode") + "'," +
                                        "'" + obj.getString("qty") + "','" + obj.getString("weight") + "','" + obj.getString("price") + "'," +
                                        "'" + obj.getString("discount") + "','" + obj.getString("amount") + "','" + obj.getString("cgst") + "'," +
                                        "'" + obj.getString("sgst") + "','" + obj.getString("igst") + "','" + obj.getString("cgstamt") + "'," +
                                        "'" + obj.getString("sgstamt") + "','" + obj.getString("igstamt") + "','" + obj.getString("freeitemstatus") + "'," +
                                        "'" + obj.getString("makerid") + "','" + obj.getString("createddate") + "','" + obj.getString("updateddate") + "'" +
                                        ",'" + obj.getString("bookingno") + "','" + obj.getString("financialyearcode") + "','"+obj.getString("vancode")+"',2)";
                                mDb.execSQL(sql);


                            } catch (JSONException ex) {
                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    // sync sales schedule
    //

    public void syncsalesschedulemobile (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                   /* String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblsalesschedule'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }*/
                    for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);

                                //if (obj.getString("process").equals("Insert")) {
                                    String sql = "SELECT * FROM 'tblsalesschedule' WHERE schedulecode='" + obj.getString("schedulecode")+"' ";
                                    if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                        int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                        sql = "INSERT INTO 'tblsalesschedule' (autonum, refno,schedulecode, scheduledate,vancode,routecode,vehiclecode,employeecode, drivercode,helpername," +
                                                "tripadvance,startingkm,endingkm,createddate, updateddate,makerid,flag,lunch_start_time,lunch_end_time) VALUES('" + gc +"','" + obj.getString("refno")+"'," +
                                                "'" + obj.getString("schedulecode")+"','" + obj.getString("scheduledate")+"','" + obj.getString("vancode")+"'," +
                                                "'" + obj.getString("routecode")+"','" + obj.getString("vehiclecode")+"','" + obj.getString("employeecode")+"'," +
                                                "'" + obj.getString("drivercode")+"','" + obj.getString("helpername")+"','" + obj.getString("tripadvance")+"'," +
                                                "'" + obj.getString("startingkm")+"','" + obj.getString("endingkm")+"','" + obj.getString("createddate")+"'," +
                                                "'" + obj.getString("updateddate")+"','" + obj.getString("makerid")+"',1," +
                                                " '" + obj.getString("lunch_start_time")+"','" + obj.getString("lunch_end_time")+"')";
                                        mDb.execSQL(sql);
                                    } else {
                                        int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                        String sql1 = "UPDATE 'tblsalesschedule' SET autonum='" + gc +"',schedulecode='" + obj.getString("schedulecode")+"'," +
                                                "refno='" + obj.getString("refno")+"',scheduledate='" + obj.getString("scheduledate")+"'," +
                                                "vancode='" + obj.getString("vancode")+"',routecode='" + obj.getString("routecode")+"'," +
                                                "vehiclecode='" + obj.getString("vehiclecode")+"',employeecode='" + obj.getString("employeecode")+"'," +
                                                "drivercode='" + obj.getString("drivercode")+"',helpername='" + obj.getString("helpername")+"'," +
                                                "tripadvance='" + obj.getString("tripadvance")+"',startingkm='" + obj.getString("startingkm")+"'," +
                                                "endingkm='" + obj.getString("endingkm")+"',createddate='" + obj.getString("createddate")+"'," +
                                                "updateddate='" + obj.getString("updateddate")+"',makerid='" + obj.getString("makerid")+"', " +
                                                " lunch_start_time='" + obj.getString("lunch_start_time")+"',lunch_end_time='" + obj.getString("lunch_end_time")+"' " +
                                                " WHERE schedulecode='" + obj.getString("schedulecode")+"' ";
                                        mDb.execSQL(sql1);
                                    }

                               // }


                            } catch (JSONException ex) {

                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    //Syncnilstock
    public void syncnilstock (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sqlcount = "SELECT coalesce(count(*),0) as count FROM 'tblnilstocktransaction'";
                    Cursor mCur = mDb.rawQuery(sqlcount, null);
                    if (mCur.getCount() > 0)
                    {
                        mCur.moveToFirst();
                    }
                    if(mCur.getString(0).equals("0")) {
                        for (int i = 0; i < json_category.length(); i++) {
                            try {
                                JSONObject obj = (JSONObject) json_category.get(i);

                                //if (obj.getString("process").equals("Insert")) {
                               // String sql = "SELECT * FROM 'tblnilstocktransaction' WHERE schedulecode='" + obj.getString("schedulecode") + "' ";
                                //if (!((mDb.rawQuery(sql, null)).moveToFirst())) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    String sql = "INSERT INTO 'tblnilstocktransaction' (autonum, vancode,schedulecode, salestransactionno,salesbookingno,salesfinacialyearcode" +
                                            " ,salescustomercode,salesitemcode, createddate,flag," +
                                            "syncflag) VALUES('" + gc + "','" + obj.getString("vancode") + "'," +
                                            "'" + obj.getString("schedulecode") + "','" + obj.getString("salestransactionno") + "'," +
                                            " '" + obj.getString("salesbookingno") + "'," +
                                            "'" + obj.getString("salesfinacialyearcode") + "','" + obj.getString("salescustomercode") + "'," +
                                            " '" + obj.getString("salesitemcode") + "'," +
                                            "'" + obj.getString("createddate") + "','" + obj.getString("flag") + "' ,1 )";
                                    mDb.execSQL(sql);
                                //} else {
                                   /* int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");
                                    String sql1 = "UPDATE 'tblnilstocktransaction' SET autonum='" + gc + "',schedulecode='" + obj.getString("schedulecode") + "'," +
                                            "refno='" + obj.getString("refno") + "',scheduledate='" + obj.getString("scheduledate") + "'," +
                                            "vancode='" + obj.getString("vancode") + "',routecode='" + obj.getString("routecode") + "'," +
                                            "vehiclecode='" + obj.getString("vehiclecode") + "',employeecode='" + obj.getString("employeecode") + "'," +
                                            "drivercode='" + obj.getString("drivercode") + "',helpername='" + obj.getString("helpername") + "'," +
                                            "tripadvance='" + obj.getString("tripadvance") + "',startingkm='" + obj.getString("startingkm") + "'," +
                                            "endingkm='" + obj.getString("endingkm") + "',createddate='" + obj.getString("createddate") + "'," +
                                            "updateddate='" + obj.getString("updateddate") + "',makerid='" + obj.getString("makerid") + "', " +
                                            " lunch_start_time='" + obj.getString("lunch_start_time") + "',lunch_end_time='" + obj.getString("lunch_end_time") + "' " +
                                            " WHERE schedulecode='" + obj.getString("schedulecode") + "' ";
                                    mDb.execSQL(sql1);
                                }*/

                                // }


                            } catch (JSONException ex) {

                                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            }
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }

    //sync order details

    // sync sales schedule
    //

    public void syncorderdetails (JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);
                            if (obj.getString("process").equals("Insert")) {


                                String sqlcount = "SELECT coalesce(count(*),0) FROM 'tblorderdetails'";
                                Cursor mCur = mDb.rawQuery(sqlcount, null);
                                if (mCur.getCount() > 0)
                                {
                                    mCur.moveToFirst();
                                }
                                if (mCur.getInt(0) == 0) {
                                    int gc = obj.isNull("autonum") ? 0 : obj.getInt("autonum");

                                    String sql = "INSERT INTO 'tblorderdetails'(autonum,vancode,schedulecode,itemcode,qty,makerid,createddate,orderdate,flag,status) VALUES('" + obj.getString("autonum")+"'," +
                                            "'" + obj.getString("vancode")+"','" + obj.getString("schedulecode")+"'," +
                                            "'" + obj.getString("itemcode")+"','" + obj.getString("qty")+"'," +
                                            "'" + obj.getString("makerid")+"','" + obj.getString("createddate")+"'," +
                                            "'" + obj.getString("orderdate") +"',1,1)";
                                    mDb.execSQL(sql);

                                }

                            }
                        } catch (JSONException ex) {

                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }
    //delete error logs in sqlite tabel
    public void DeleteErrorLogDays()
    {
        try{
            String sql = "DELETE FROM tblerrorlogdetails where date <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day')" +
                    " FROM tblgeneralsettings  where restrictmobileappdays<>0 ) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //delete expenses in sqlite tabel
    public void DeleteExpensesDays()
    {
        try{
            String sql = "DELETE FROM tblexpenses where transactiondate <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day')" +
                    " FROM tblgeneralsettings  where restrictmobileappdays<>0 ) " +
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales)";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //delete receipt in sqlite tabel
    public void DeleteReceiptDays()
    {
        try{
            String sql = "DELETE FROM tblreceipt where receiptdate <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') " +
                    "FROM tblgeneralsettings  where restrictmobileappdays<>0) " +
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //delete salesitemdetails in sqlite table
    public void DeleteSalesItemDetailsDays()
    {
        try{
            String sql = "DELETE FROM tblsalesitemdetails  where transactionno in " +
                    " (select transactionno from tblsales where companycode=tblsalesitemdetails.companycode " +
                    " and billdate <= (SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') " +
                    " FROM tblgeneralsettings  where restrictmobileappdays<>0 ) and " +
                    " schedulecode in (select schedulecode from tblclosecash where status='2') and " +
                    " schedulecode in (select schedulecode from tblclosesales) )";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //delete salesdetails in sqlite table
    public void DeleteSalesDays()
    {
        try{
            String sql = "DELETE FROM tblsales where billdate <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') FROM " +
                    "tblgeneralsettings  where restrictmobileappdays<>0) "+
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //delete salesreturnitemdetails in sqlite table
    public void DeleteSalesReturnItemDetailsDays()
    {
        try{
            String sql = "DELETE FROM tblsalesreturnitemdetails  where transactionno in " +
                    "(select transactionno from tblsalesreturn where companycode=tblsalesreturnitemdetails.companycode " +
                    "and billdate <= (SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays " +
                    "|| ' day') FROM tblgeneralsettings  where restrictmobileappdays<>0) " +
                    " and schedulecode in (select schedulecode from tblclosecash where status='2') " +
                    " and schedulecode in (select schedulecode from tblclosesales))";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    //delete salesreturn in sqlite table
    public void DeleteSalesReturnDays()
    {
        try{
            String sql = "DELETE FROM tblsalesreturn where billdate <=  " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') " +
                    "FROM tblgeneralsettings  where restrictmobileappdays<>0) "+
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //delete sales schedule
    public void DeleteSalesSchedule()
    {
        try{
            String sql = "DELETE FROM tblsalesschedule where scheduledate <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') " +
                    "FROM tblgeneralsettings  where restrictmobileappdays<>0) "+
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //delete order details

    public void DeleteorderDetails()
    {
        try{
            String sql = "DELETE FROM tblorderdetails where orderdate <= " +
                    "(SELECT  date('"+ LoginActivity.getformatdate +"','-' ||restrictmobileappdays || ' day') " +
                    "FROM tblgeneralsettings  where restrictmobileappdays<>0) "+
                    " and schedulecode in (select schedulecode from tblclosecash where status='2')" +
                    " and schedulecode in (select schedulecode from tblclosesales) ";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }


    //Sync MAxrefNo

    public void syncmaxrefno(JSONObject object)
    {
        if(object!=null)
        {
            JSONArray json_category = null;

            try {
                String success = object.getString("success");
                if(success.equals("1"))
                {
                    json_category = object.getJSONArray("Value");
                    String sql1="DELETE FROM 'tblmaxcode'";
                    mDb.execSQL(sql1);
                    for(int i=0;i<json_category.length();i++)
                    {
                        try {
                            JSONObject obj = (JSONObject) json_category.get(i);

                            String sql = "SELECT * FROM 'tblmaxcode1' WHERE code="+obj.getInt("code");
                            /*if(!((mDb.rawQuery(sql, null)).moveToFirst()))
                            {*/

                                sql = "INSERT INTO 'tblmaxcode' VALUES("+obj.getInt("code")+"," +
                                        " '" + obj.getString("process")+"'," + obj.getInt("refno")+"," +
                                        "" + obj.getInt("bookingno")+"," +
                                        "" + obj.getInt("transactionno")+"," +
                                        " " + obj.getInt("companycode")+"," +
                                        " " + obj.getInt("billtypecode")+"," +
                                        " '" + obj.getString("transactiondate")+"')";
                                mDb.execSQL(sql);
                            //}
                            /*else{
                                String sql1 = "UPDATE 'tblmaxcode' SET  process='" + obj.getString("process")+
                                        "',refno='" + obj.getString("refno")+"' ,bookingno='" + obj.getString("bookingno")+"' " +
                                        " ,transactionno='" + obj.getString("transactionno")+"'" +
                                        " WHERE code="+obj.getInt("code")+" ";
                                mDb.execSQL(sql1);
                            }*/


                        } catch (JSONException ex) {

                            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        }
                    }
                }
            } catch (JSONException ex) {
                // TODO Auto-generated catch block
                insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
        }
    }


    /********************PRINT FUNVTIONALITY*******************/
    //Get Sales Rep
    public Cursor GetReceiptPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.shortname,b.companyname,coalesce(b.street,'') as street,coalesce(b.area,'') as area, " +
                    "coalesce(b.mobileno,'') as mobileno,coalesce(b.telephone,'') as telephone," +
                    " coalesce(b.gstin,'') as gstin, " +
                    "coalesce(b.city,'') as city,coalesce(b.pincode,'') as pincode, coalesce(b.panno,'') as panno," +
                    "a.voucherno,strftime('%d-%m-%Y',a.receiptdate) as receiptdate,a.customercode,(select customernametamil " +
                    " from tblcustomer where customercode=a.customercode) as customername," +
                    "a.vancode,(select vanname from tblvanmaster where vancode=a.vancode) as vanname, " +
                    "(select gstin from tblcustomer where customercode=a.customercode) as gstin, " +
                    "(select mobileno from tblcustomer where customercode=a.customercode) as mobileno,a.receiptmode," +
                    " a.chequerefno,a.amount,note," +
                    "(select employeenametamil from tblemployeemaster where employeecode=c.employeecode) as employeenametamil," +
                    "(select employeenametamil from tblemployeemaster where employeecode=c.drivercode) as " +
                    " drivercode,c.helpername,receipttime," +
                    " (select receiptremarks from tblreceiptremarks where receiptremarkscode=a.receiptremarkscode ) as remarks " +
                    " from tblreceipt as a inner join tblcompanymaster as b on a.companycode=b.companycode " +
                    " inner join tblsalesschedule as c " +
                    "on c.schedulecode = a.schedulecode " +
                    " where transactionno='"+gettransactionno+"' and financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get SAles Schedule Details
    public Cursor GetSalesScheduleDetails(String getschedulecode)
    {
        Cursor mCur=null;
        try{
            String sql ="select vancode,(select vanname from tblvanmaster where vancode=a.vancode) as vanname,\n" +
                    "employeecode,(select employeenametamil from tblemployeemaster where employeecode=a.employeecode) as employeename,\n" +
                    "drivercode, (select employeenametamil from tblemployeemaster where employeecode=a.drivercode) as drivername,helpername\n" +
                    " from tblsalesschedule as a where schedulecode='"+getschedulecode+"'  ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetSalesPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,a.billno,e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.billdate) as date,a.companycode,b.shortname,a.grandtotal,a.bookingno," +
                    " a.billtypecode,a.salestime from tblsales AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetSalesOrderPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,a.billno,e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.billdate) as date,a.companycode,b.shortname,a.grandtotal,a.bookingno," +
                    " a.billtypecode,a.salestime," +
                    " coalesce((SELECT transportname FROM tbltransportmaster where transportid=a.transportid),'') as transportname," +
                    "coalesce((select day_of_dispatch from tbltransportcitymapping where transportid=a.transportid and citycode=" +
                    "(select citycode from tblareamaster where areacode=(select areacode from tblcustomer where " +
                    " customercode=a.customercode ))),'') as day_of_dispatch,(select areanametamil from tblareamaster  " +
                    "where areacode=(select areacode from tblcustomer where customercode=a.customercode ) ) as areaname from tblsalesorder AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    public Cursor GetSalesReturnPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,a.billno,e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.billdate) as date,a.companycode,b.shortname,a.grandtotal,a.bookingno," +
                    " a.billtypecode,a.salestime from tblsalesreturn AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetDCSalesPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,GROUP_CONCAT(a.billno),e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.createddate) as date,a.companycode,b.shortname,a.grandtotal,a.bookingno," +
                    " a.billtypecode,a.salestime from tblsales AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }


    //Get Sales bills for print
    public Cursor GetDCSalesReturnPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,GROUP_CONCAT(a.billno),e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.createddate) as date,a.companycode,b.shortname,a.grandtotal,a.bookingno," +
                    " a.billtypecode,a.salestime from tblsalesreturn AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetSalesPaymentVoucherPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{
            String sql ="select b.companyname,b.street,b.area,b.city,b.pincode,b.telephone,b.mobileno,b.gstin," +
                    "b.fssaino,b.panno, c.vanname,d.customernametamil,a.billno,e.billtype,a.gstin,d.mobileno as cusmobile," +
                    " strftime('%d-%m-%Y', a.createddate) as date,a.companycode,b.shortname,sum(a.grandtotal) as total,a.bookingno," +
                    " a.billtypecode,a.salestime from tblsales AS a  inner join tblcompanymaster as b on " +
                    "a.companycode=b.companycode   inner join tblvanmaster as c on a.vancode=c.vancode INNER JOIN " +
                    "tblcustomer as d   on a.customercode=d.customercode inner join tblbilltype   " +
                    "   as e on a.billtypecode=e.billtypecode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' group by a.transactionno ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    public Cursor GetSalesPaymentVoucherDetailsPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{

            String sql ="select billno,companycode,grandtotal,(Select shortname from tblcompanymaster where companycode=a.companycode)" +
                    " as shortname from tblsales as a " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }


    public Cursor GetSalesOrderPaymentVoucherDetailsPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{

            String sql ="select billno,companycode,grandtotal,(Select shortname from tblcompanymaster " +
                    " where companycode=a.companycode)" +
                    " as shortname from tblsalesorder as a " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }
    public Cursor GetSalesReturnPaymentVoucherDetailsPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{

            String sql ="select billno,companycode,grandtotal,(Select shortname from tblcompanymaster where companycode=a.companycode)" +
                    " as shortname from tblsalesreturn as a " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    public Cursor GetSalesDCDetailsPrint(String gettransactionno,String getfinancialyrcode)
    {
        Cursor mCur=null;
        try{

            String sql ="select billno,companycode,grandtotal,(Select shortname from tblcompanymaster where companycode=a.companycode)" +
                    " as shortname from tblsales as a " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetSalesItemPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{

            String sql ="select b.itemnametamil,a.qty ,a.amount,a.price,c.unitname as unit," +
                    "d.hsn,a.cgst+a.sgst+a.igst as tax from tblsalesitemdetails as a inner join tblitemmaster " +
                    "as b on a.itemcode=b.itemcode  inner join tblunitmaster as c on b.unitcode=c.unitcode  " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    "where a.transactionno='"+gettransactionno+"'" +
                    " and a.financialyearcode='"+getfinancialyrcode+"' and a.companycode='"+companycode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }



    //Get Sales bills for print
    public Cursor GetSalesOrderItemPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{

            String sql ="select b.itemnametamil,a.qty ,a.amount,a.price,c.unitname as unit," +
                    "d.hsn,a.cgst+a.sgst+a.igst as tax from tblsalesorderitemdetails as a inner join tblitemmaster " +
                    "as b on a.itemcode=b.itemcode  inner join tblunitmaster as c on b.unitcode=c.unitcode  " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    "where a.transactionno='"+gettransactionno+"'" +
                    " and a.financialyearcode='"+getfinancialyrcode+"'  ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }
    //Get Sales Return bills for print
    public Cursor GetSalesReturnItemPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{

            String sql ="select b.itemnametamil,a.qty ,a.amount,a.price,c.unitname as unit," +
                    "d.hsn,a.cgst+a.sgst+a.igst as tax from tblsalesreturnitemdetails as a inner join tblitemmaster " +
                    "as b on a.itemcode=b.itemcode  inner join tblunitmaster as c on b.unitcode=c.unitcode  " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' and a.companycode='"+companycode+"' ; ";
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetDCSalesItemPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{

            String sql ="select b.itemnametamil,a.qty ,a.amount,a.price,c.unitname as unit," +
                    "d.hsn,a.cgst+a.sgst+a.igst as tax from tblsalesitemdetails as a inner join tblitemmaster " +
                    "as b on a.itemcode=b.itemcode  inner join tblunitmaster as c on b.unitcode=c.unitcode  " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' order by a.companycode; ";

            //and a.companycode='"+companycode+"'
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales bills for print
    public Cursor GetDCSalesReturnItemPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{

            String sql ="select b.itemnametamil,a.qty ,a.amount,a.price,c.unitname as unit," +
                    "d.hsn,a.cgst+a.sgst+a.igst as tax from tblsalesreturnitemdetails as a inner join tblitemmaster " +
                    "as b on a.itemcode=b.itemcode  inner join tblunitmaster as c on b.unitcode=c.unitcode  " +
                    " inner join tblitemsubgroupmaster as d on  d.itemsubgroupcode=b.itemsubgroupcode " +
                    "where a.transactionno='"+gettransactionno+"' and a.financialyearcode='"+getfinancialyrcode+"' order by a.companycode; ";

            //and a.companycode='"+companycode+"'
            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }


    //Get Sales tax for print
    public Cursor GetSalestaxPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select a.tax,coalesce(taxablevalue,0) as TaxableValue,coalesce(cgst,0) as cgst,coalesce(sgst,0) as sgst" +
                    " from tbltax as a left outer join  ( select GST as GST ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST,coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT b.tax as GST,cast(price/(1+(b.tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(b.tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(b.tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " +
                    " group by GST ) as e on a.tax=e.gst where TaxableValue > 0 order by a.tax";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales tax for print
    public Cursor GetSalesOrdertaxPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select tax,coalesce(taxablevalue,0) as TaxableValue,coalesce(cgst,0) as cgst,coalesce(sgst,0) as sgst from tbltax as " +
                    "a left outer join  ( select GST as GST ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST," +
                    "coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT tax as GST,cast(price/(1+(tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesorderitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " +
                    " group by GST ) as e on a.tax=e.gst order by a.tax";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }


    //Get Sales tax for print
    public Cursor GetSalesReturntaxPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select tax,coalesce(taxablevalue,0) as TaxableValue,coalesce(cgst,0) as cgst,coalesce(sgst,0) as sgst from tbltax as a left outer join  ( select GST as GST ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST,coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT tax as GST,cast(price/(1+(tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesreturnitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " +
                    " group by GST ) as e on a.tax=e.gst order by a.tax";

            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales tax for print
    public Cursor GetSalestaxtotalPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select GST as 'GST %' ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST,coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT 'Total' as GST,cast(price/(1+(b.tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(b.tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(b.tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }


    //Get Sales tax for print
    public Cursor GetSalesOrdertaxtotalPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select GST as 'GST %' ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST,coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT 'Total' as GST,cast(price/(1+(tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesorderitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    //Get Sales tax for print
    public Cursor GetSalesReturntaxtotalPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select GST as 'GST %' ,coalesce(sum(taxablevalue),0) as TaxableValue,coalesce(sum(cgst),0) as CGST,coalesce(Sum(sgst),0) as SGST from " +
                    "(SELECT 'Total' as GST,cast(price/(1+(tax/100))*qty as decimal(38,2)) as TaxableValue," +
                    "cast((price/(1+(tax/100))*qty)*cgst/100 as decimal(38,2)) as cgst," +
                    "cast((price/(1+(tax/100))*qty)*sgst/100 as decimal(38,2)) as sgst" +
                    " FROM tbltax" +
                    " as b left outer join tblsalesreturnitemdetails as a on a.cgst+a.sgst+a.igst=b.tax" +
                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"') as derv " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales schedule for print
    public Cursor GetSalesschedulePrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select c.vanname,(select employeenametamil from tblemployeemaster where employeecode=b.employeecode) as employeename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=b.drivercode) as drivername,helpername " +
                    " from tblsales as a inner join tblsalesschedule as b " +
                    "on a.schedulecode=b.schedulecode inner join tblvanmaster as c on a.vancode=c.vancode " +

                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }



    //Get Sales schedule for print
    public Cursor GetSalesOrderschedulePrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select c.vanname,(select employeenametamil from tblemployeemaster where employeecode=b.employeecode) as employeename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=b.drivercode) as drivername,helpername " +
                    " from tblsalesorder as a inner join tblsalesschedule as b " +
                    "on a.schedulecode=b.schedulecode inner join tblvanmaster as c on a.vancode=c.vancode " +

                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales schedule for print
    public Cursor GetSalesReturnSchPrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select c.vanname,(select employeenametamil from tblemployeemaster where employeecode=b.employeecode) as employeename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=b.drivercode) as drivername,helpername " +
                    " from tblsalesreturn as a inner join tblsalesschedule as b " +
                    "on a.schedulecode=b.schedulecode inner join tblvanmaster as c on a.vancode=c.vancode " +

                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }

    //Get Sales schedule for print
    public Cursor GetSalesReturnschedulePrint(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        Cursor mCur=null;
        try{
            String sql ="select c.vanname,(select employeenametamil from tblemployeemaster where employeecode=b.employeecode) as employeename," +
                    "(select employeenametamil from tblemployeemaster where employeecode=b.drivercode) as drivername,helpername " +
                    " from tblsalesreturn as a inner join tblsalesschedule as b " +
                    "on a.schedulecode=b.schedulecode inner join tblvanmaster as c on a.vancode=c.vancode " +

                    " where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' " ;


            mCur = mDb.rawQuery(sql, null);
            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return mCur;
    }


    //Get SAles Discount
    public double GetSalesDiscount(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        double getcount = 0;
        try{
            String sql ="select coalesce(discount,0) from tblsales as a where a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"' and a.companycode='"+ companycode +"'";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcount = mCur.getFloat(0);
            }
            if(mCur != null && !mCur.isClosed()){
                mCur.close();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcount;
    }

    //Get SAles Discount
    public double GetSalesOrderDiscount(String gettransactionno,String getfinancialyrcode,String companycode)
    {
        double getcount = 0;
        try{
            String sql ="select coalesce(discount,0) from tblsalesorder as a where " +
                    " a.transactionno='"+ gettransactionno +"' and a.financialyearcode='"+ getfinancialyrcode +"'" +
                    " and a.companycode='"+ companycode +"'";
            Cursor mCur = mDb.rawQuery(sql, null);

            if (mCur.getCount() > 0)
            {
                mCur.moveToFirst();
                getcount = mCur.getFloat(0);
            }
            if(mCur != null && !mCur.isClosed()){
                mCur.close();
            }
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

        return getcount;
    }

    public Cursor udfngetdevicedetails(String varDeviceID)
    {
        Cursor mCur=null;
        try{
            String sql="SELECT UserName,CompanyName from 'tblActivation' where status='Activated' AND DeviceID='"+ varDeviceID +"' ORDER BY Autonum desc LIMIT 1";// and status='Activated'
            mCur = mDb.rawQuery(sql, null);
            if(mCur.getCount() > 0)
                mCur.moveToFirst();

        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return mCur;
    }

    public void insertActivationDetails(String CompanyName,String UserName,String City,String MobileNumber,String EmailID,String RegistrationKey,String Status,String DeviceID,String Activationcode)
    {
        try{
            String sql = "INSERT INTO  'tblActivation'(CompanyName,UserName,City,MobileNumber,EmailID,RegistrationKey,Status,DeviceID,ActivationCode,SyncFlag,CreatedDate) VALUES('"+
                    ReplaceQuotes(CompanyName.toUpperCase()) +"','"+UserName.toUpperCase() +"','"+City.toUpperCase()+"','"+MobileNumber+"','"+EmailID.toUpperCase() +"','"+RegistrationKey+"','"+Status+"','"+ DeviceID +"','"+ Activationcode+"',1,datetime('now', 'localtime'))";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

    public String ReplaceQuotes(String strValue)
    {
        strValue = strValue.replace("'", "''");
        return strValue;
    }

    public void updateActivationDetails(String RegistrationKey,String DeviceID,String Activationcode)
    {
        try{
            String sql = "UPDATE  'tblActivation' SET Status='Activated',ActivationCode='"+ Activationcode+"' where RegistrationKey='"+RegistrationKey+"' and DeviceID='"+ DeviceID +"'";
            mDb.execSQL(sql);
        }catch (Exception ex){
            insertErrorLog(ex.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }

    }

}
