package thanjavurvansales.sss;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.jeevandeshmukh.glidetoastlib.GlideToast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SalesActivity extends AppCompatActivity implements View.OnClickListener,View.OnTouchListener {
    private static final long START_TIME_IN_MILLIS = 600000;
    private PopupWindow window;
    FloatingActionButton fabgroupitem,addsalescart;
    private Boolean isFabOpen = false;
    private Animation rotate_forward,rotate_backward;
    Context context;
    boolean isopenpopup;
    ViewGroup view_root;
    private int _xDelta;
    private int _yDelta;
    ImageView salegoback,salelogout;
    float dX;
    float dY;
    int lastAction;
    public DecimalFormat df;

    private ExpandableAdapter expandableAdapter;
    private ExpandableListView expList;

    private List<String> listDataHEader;
    private HashMap<String,List<String>> listhash;

    TextView billisttotalamount,salesreview;
    ToggleButton togglegstin;
    static RadioButton radio_cash,radio_credit;

    ListView lv_sales_items,lv_AreaList,lv_CustomerList,lv_subgroup,lv_CustomerAreaList,lv_CityList;

    TextView txtroutename;
    public  static TextView txtcustomername,txtareaname,totalcartitems,txtsalesdate;
    String[] AreaCode,AreaName,AreaNameTamil,NoOfKm,CityCode,CityName,CustomerCount;
    String[] SubGroupCode,SubGroupName,SubGroupNameTamil;
    String[] CustomerCode,CustomerName,CustomerNameTamil,Address,CustomerAreaCode,MobileNo,
            TelephoneNo,GSTN,SchemeApplicable,customertypecode;
    Dialog areadialog,customerdialog;
    static public String  customercode="",gstnnumber="",
            getschemeapplicable="",getstaticsubcode="",getstaticchilditemcode="",getstaticgetchildqty="";
    public static ArrayList<SalesItemDetails> salesitems = new ArrayList<SalesItemDetails>();
    ArrayList<SalesItemDetails> freeitems = new ArrayList<SalesItemDetails>();
    static ArrayList<SalesItemDetails> staticreviewsalesitems = new ArrayList<SalesItemDetails>();
    Dialog stockconvertdialog,dialog,citydialog;
    public static boolean paymenttype;
    ImageView btnaddcustomer;
    TextView txtpopupustomername,txtcustomernametamil,txtaddress,txtcityname,
            txtarea,txtphoneno,txtlandlineno,txtemailid,txtgstin,txtadhar;
    Button btnSaveCustomer;
    String getcitycode,getareacode;
    String[] areacode,areaname,areanametamil,customercount;
    String[] citycode,cityname,citynametamil;
    public static boolean ifsavedsales = false;
    public static final String GSTINFORMAT_REGEX = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
    public static final String GSTN_CODEPOINT_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static String getitemsfromcode = "0";
    boolean networkstate;
    boolean isopenshowpopup=false;
    boolean cartflag =false;
    boolean cartpriceflag =false;
    boolean cartcheckflag =false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales);
        try {
            context = this;

            //Declare All ListView,TextView,Edit Text ,Fab Buttons
            fabgroupitem = (FloatingActionButton) findViewById(R.id.fabgroupitem);
            lv_sales_items = (ListView) findViewById(R.id.lv_sales_items);
            rotate_forward = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_forward);
            rotate_backward = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_backward);
            billisttotalamount = (TextView) findViewById(R.id.billisttotalamount);
            view_root = (ViewGroup) findViewById(R.id.view_root);
            togglegstin = (ToggleButton) findViewById(R.id.togglegstin);
            salesreview = (TextView) findViewById(R.id.salesreview);
            salegoback = (ImageView) findViewById(R.id.salegoback);
            salelogout = (ImageView) findViewById(R.id.salelogout);
            txtareaname = (TextView) findViewById(R.id.txtareaname);
            txtcustomername = (TextView) findViewById(R.id.txtcustomername);
            txtroutename = (TextView) findViewById(R.id.txtroutename);
            txtsalesdate = (TextView) findViewById(R.id.txtsalesdate);
            radio_cash = (RadioButton) findViewById(R.id.radio_cash);
            radio_credit = (RadioButton) findViewById(R.id.radio_credit);
            totalcartitems = (TextView) findViewById(R.id.totalcartitems);
            addsalescart = (FloatingActionButton) findViewById(R.id.addsalescart);
            btnaddcustomer = (ImageView) findViewById(R.id.btnaddcustomer);

            ifsavedsales = false;

            final View dragView = findViewById(R.id.movecart);
            dragView.setOnTouchListener(this);


            //Get Current date
            DataBaseAdapter objdatabaseadapter = null;
            try {
                objdatabaseadapter = new DataBaseAdapter(context);
                objdatabaseadapter.open();
                LoginActivity.getformatdate = objdatabaseadapter.GenCreatedDate();
                LoginActivity.getcurrentdatetime = objdatabaseadapter.GenCurrentCreatedDate();
            } catch (Exception e) {
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            } finally {
                // this gets called even if there is an exception somewhere above
                if (objdatabaseadapter != null)
                    objdatabaseadapter.close();
            }
            //Set values for corresponding values
            txtareaname.setText(LoginActivity.getareaname);

            //salesfabclickoption
            fabgroupitem.setOnClickListener(this);

            //Set total cart item value
            totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));

            CheckToggleButton();
            togglegstin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (radio_cash.isChecked()) {
                        CheckToggleButton();
                    }
                }
            });
            togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));


            //if check credit automatic gstin button as green
            radio_credit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    togglegstin.setTextOn("GSTIN \n " + gstnnumber);
                    togglegstin.setBackgroundColor(getResources().getColor(R.color.green));
                    if (gstnnumber.equals("")) {
                        togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                    }
                }
            });

            //open Review Screen
            salesreview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (staticreviewsalesitems.size() > 0) {
                        boolean checkquantityflag = true;
                        if (salesitems.size() > 0) {
                        /*for (int i = 0; i < salesitems.size(); i++) {
                            if (!salesitems.get(i).getItemqty().equals("")
                                    && !salesitems.get(i).getItemqty().equals(null)
                                    && !salesitems.get(i).getItemqty().equals("0")
                                    && !salesitems.get(i).getNewprice().equals(null)
                                    && !salesitems.get(i).getNewprice().equals("")) {
                                if (Double.parseDouble(salesitems.get(i).getItemqty()) > 0
                                        && Double.parseDouble(salesitems.get(i).getSubtotal()) > 0) {
                                    checkquantityflag = true;
                                } else {
                                    checkquantityflag = false;
                                }

                            }
                        }*/
                            for (int i = 0; i < lv_sales_items.getChildCount(); i++) {
                                View listRow = lv_sales_items.getChildAt(i);
                                EditText getlistqty = (EditText) listRow.findViewById(R.id.listitemqty);
                                TextView getlisttotal = (TextView) listRow.findViewById(R.id.listitemtotal);
                                String getitemlistqty = getlistqty.getText().toString();
                                String getitemlisttotal = getlisttotal.getText().toString();
                                if (!getitemlistqty.equals("") && !getitemlistqty.equals(null)) {
                                    if (Double.parseDouble(getitemlistqty) > 0 && Double.parseDouble(getitemlisttotal) <= 0.0) {
                                        getlistqty.requestFocus();
                                        Toast toast = Toast.makeText(getApplicationContext(), "Please enter valid total amount", Toast.LENGTH_LONG);
                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                        toast.show();
                                        return;
                                    }
                                }
                            }
                        }
                        salesitems.clear();
                        SalesItemAdapter adapter = new SalesItemAdapter(context, salesitems);
                        lv_sales_items.setAdapter(adapter);
                        Intent i = new Intent(context, ReviewActivity.class);
                        startActivity(i);
                    } else {
                        Toast toast = Toast.makeText(getApplicationContext(), "Cart is empty", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(),"Cart is empty",Toast.LENGTH_SHORT).show();
                        return;
                    }

                }
            });

            //Logout process
            salelogout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // HomeActivity.logoutprocess = "True";
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Confirmation");
                    builder.setMessage("Are you sure you want to logout?")
                            .setCancelable(false)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent i = new Intent(context, LoginActivity.class);
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    startActivity(i);
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();

                }
            });


            //Goback process
            salegoback.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goBack(null);
                }
            });

            /*******FILTER FUNCTIONALITY********/
            txtareaname.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GetArea(MenuActivity.getroutecode);
                }
            });
            txtcustomername.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GetCustomer(LoginActivity.getareacode);
                }
            });


            /*******END FILTER FUNCTIONALITY******/
            //Set Routename and current date
            txtroutename.setText(MenuActivity.getroutename);
            txtsalesdate.setText(LoginActivity.getcurrentdatetime);

            //Set total cart items
            totalcartitems.setText("0");


            btnaddcustomer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GetCustomerPopup();
                }
            });
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    /************OPEN CUSTOMR POPUP*********************/
    public void GetCustomerPopup(){
        try {
            dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.addcustomer);
            ImageView closepopup = (ImageView) dialog.findViewById(R.id.closepopup);
            txtpopupustomername = (TextView) dialog.findViewById(R.id.txtcustomername);
            txtcustomernametamil = (TextView) dialog.findViewById(R.id.txtcustomernametamil);
            txtaddress = (TextView) dialog.findViewById(R.id.txtaddress);
            txtcityname = (TextView) dialog.findViewById(R.id.txtcityname);
            txtarea = (TextView) dialog.findViewById(R.id.txtarea);
            txtphoneno = (TextView) dialog.findViewById(R.id.txtphoneno);
            txtlandlineno = (TextView) dialog.findViewById(R.id.txtlandlineno);
            txtemailid = (TextView) dialog.findViewById(R.id.txtemailid);
            txtgstin = (TextView) dialog.findViewById(R.id.txtgstin);
            txtadhar = (TextView) dialog.findViewById(R.id.txtadhar);
            btnSaveCustomer = (Button) dialog.findViewById(R.id.btnSaveCustomer);

            btnSaveCustomer.setEnabled(true);
            btnSaveCustomer.setText("Save");


            txtcityname.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GetCity(MenuActivity.getroutecode);
                }
            });
            txtarea.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GetCustomerArea(getcitycode);
                }
            });
            btnSaveCustomer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String getcustomername = txtpopupustomername.getText().toString();
                    String getcustomernametamil = txtcustomernametamil.getText().toString();
                    String getaddress = txtaddress.getText().toString();
                    String getcityname = txtcityname.getText().toString();
                    String getarea = txtarea.getText().toString();
                    String getphoneno = txtphoneno.getText().toString();
                    String getlandlineno = txtlandlineno.getText().toString();
                    String getemailid = txtemailid.getText().toString();
                    String getgstin = txtgstin.getText().toString();
                    String getaadharno = txtadhar.getText().toString();

                    if (getcustomername.equals("") || getcustomername.equals("null")
                            || getcustomername.equals(null)) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please enter customer name", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        // Toast.makeText(getApplicationContext(),"Please enter customer name",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (getcityname.equals("") || getcityname.equals("null")
                            || getcityname.equals(null) || getcitycode.equals("") || getcitycode.equals(null)) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please select city name", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //  Toast.makeText(getApplicationContext(),"Please select city name",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (getarea.equals("") || getarea.equals("null")
                            || getarea.equals(null) || getareacode.equals("") || getareacode.equals(null)) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please select area name", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(),"Please select area name",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if ((getphoneno.equals("") || getphoneno.equals("null")
                            || getphoneno.equals(null)) && (getgstin.equals("") || getgstin.equals("null")
                            || getgstin.equals(null))) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please enter Mobile No. or GSTIN", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Please enter Mobile No. or GSTIN", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!getphoneno.equals("") && !getphoneno.equals("null")
                            && !getphoneno.equals(null)) {
                        if (getphoneno.length() < 10) {
                            Toast toast = Toast.makeText(getApplicationContext(), "Mobile No. should contain 10 digits", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            //Toast.makeText(getApplicationContext(), "Mobile No. should contain 10 digits", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }

                    if (!getgstin.equals("") && !getgstin.equals("null")
                            && !getgstin.equals(null)) {
                        if (getgstin.length() > 0) {
                            try {
                                if (!validGSTIN(getgstin)) {
                                    Toast toast = Toast.makeText(getApplicationContext(), "Please enter valid GSTIN", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    // Toast.makeText(getApplicationContext(), "Please enter valid GSTIN", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (!getaadharno.equals("") && !getaadharno.equals("null")
                            && !getaadharno.equals(null)) {
                        if (getaadharno.length() < 16) {
                            Toast toast = Toast.makeText(getApplicationContext(), "Aadhar No. should contain 12 digits", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            //Toast.makeText(getApplicationContext(), "Aadhar No. should contain 12 digits", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }


                    btnSaveCustomer.setEnabled(false);
                    DataBaseAdapter objdatabaseadapter = null;
                    try {
                        if (getcustomernametamil.equals("") || getcustomernametamil.equals(null)
                                || getcustomernametamil.equals("null")) {
                            getcustomernametamil = getcustomername;
                        }
                        //Order item details
                        objdatabaseadapter = new DataBaseAdapter(context);
                        objdatabaseadapter.open();
                        String getresult = "";
                        String getretailercount = objdatabaseadapter.CheckCustomerAlreadyExistsCount(getareacode, getcustomername);
                        if (getretailercount.equals("Success")) {
                            getresult = objdatabaseadapter.InsertCustomerDetails(getcustomername, getcustomernametamil,
                                    getaddress, getareacode, getemailid, getphoneno, getlandlineno, getaadharno, getgstin);
                            if (!getresult.equals("")) {
                                Toast toast = Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                LoginActivity.getareacode = getareacode;
                                LoginActivity.getareaname = getcityname + " - " + getarea;
                                txtareaname.setText(LoginActivity.getareaname);
                                txtcustomername.setText(getcustomernametamil);
                                customercode = getresult;
                                gstnnumber = getgstin.trim();
                                if(getgstin.trim().equals("")||getgstin.equals(null)||getgstin.equals("0")){
                                    togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                                }else{
                                    togglegstin.setBackgroundColor(getResources().getColor(R.color.green));
                                }
                                radio_cash.setChecked(true);
                                radio_credit.setEnabled(false);
                                radio_cash.setEnabled(false);


                                togglegstin.setText("GSTIN \n "+getgstin.trim());
                                togglegstin.setTextOn("GSTIN \n "+getgstin.trim());
                                togglegstin.setTextOff("GSTIN \n "+getgstin.trim());
                                //Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                                btnSaveCustomer.setEnabled(true);
                            }
                        } else {
                            Toast toast = Toast.makeText(getApplicationContext(), "Customer name already exists", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            // Toast.makeText(context, "Customer name already exists", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        networkstate = isNetworkAvailable();
                        if (networkstate == true) {
                            new AsyncCustomerDetails().execute();
                        }

                    } catch (Exception e) {
                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                        mDbErrHelper.open();
                        String geterrror = e.toString();
                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        mDbErrHelper.close();
                    } finally {
                        if (objdatabaseadapter != null)
                            objdatabaseadapter.close();
                    }

                }
            });

            closepopup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialog.show();
        } catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    //Checking internet connection
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }
    /*******FILTER FUNCTIONALITY********/

    //Get Area name
    public  void GetCustomerArea(String citycode){

        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetAreaCityDB(citycode,MenuActivity.getroutecode);
            if(Cur.getCount()>0) {
                areacode = new String[Cur.getCount()];
                areaname = new String[Cur.getCount()];
                areanametamil = new String[Cur.getCount()];
                customercount = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    areacode[i] = Cur.getString(0);
                    areaname[i] = Cur.getString(1);
                    areanametamil[i] = Cur.getString(2);
                    customercount[i] = Cur.getString(6);
                    Cur.moveToNext();
                }

                areadialog = new Dialog(context);
                areadialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                areadialog.setContentView(R.layout.areapopup);
                lv_CustomerAreaList = (ListView) areadialog.findViewById(R.id.lv_AreaList);
                ImageView close = (ImageView) areadialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        areadialog.dismiss();
                    }
                });
                AreaAdapter adapter = new AreaAdapter(context);
                lv_CustomerAreaList.setAdapter(adapter);
                areadialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Area in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Area in this route",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    //Get city name
    public  void GetCity(String routecode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCityDB(routecode);
            if(Cur.getCount()>0) {
                citycode = new String[Cur.getCount()];
                cityname = new String[Cur.getCount()];
                citynametamil = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    citycode[i] = Cur.getString(0);
                    cityname[i] = Cur.getString(1);
                    citynametamil[i] = Cur.getString(2);
                    Cur.moveToNext();
                }

                citydialog = new Dialog(context);
                citydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                citydialog.setContentView(R.layout.citypopup);
                lv_CityList = (ListView) citydialog.findViewById(R.id.lv_CityList);
                ImageView close = (ImageView) citydialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        citydialog.dismiss();
                    }
                });
                CityAdapter adapter = new CityAdapter(context);
                lv_CityList.setAdapter(adapter);
                citydialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No city in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
               // Toast.makeText(getApplicationContext(),"No city in this route",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }


    public  void GetArea(String routecode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetAreaDB(routecode);
            if(Cur.getCount()>0) {
                AreaCode = new String[Cur.getCount()];
                AreaName = new String[Cur.getCount()];
                AreaNameTamil = new String[Cur.getCount()];
                NoOfKm = new String[Cur.getCount()];
                CityCode = new String[Cur.getCount()];
                CityName = new String[Cur.getCount()];
                CustomerCount = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    AreaCode[i] = Cur.getString(0);
                    AreaName[i] = Cur.getString(1);
                    AreaNameTamil[i] = Cur.getString(2);
                    NoOfKm[i] = Cur.getString(3);
                    CityCode[i] = Cur.getString(4);
                    CityName[i] = Cur.getString(5);
                    CustomerCount[i] = Cur.getString(6);
                    Cur.moveToNext();
                }

                areadialog = new Dialog(context);
                areadialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                areadialog.setContentView(R.layout.areapopup);
                lv_AreaList = (ListView) areadialog.findViewById(R.id.lv_AreaList);
                ImageView close = (ImageView) areadialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        areadialog.dismiss();
                    }
                });
                SalesAreaAdapter adapter = new SalesAreaAdapter(context);
                lv_AreaList.setAdapter(adapter);
                areadialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Area in this route", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Area in this route",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }


    public  void GetCustomer(String areacode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCustomerDB(areacode);
            if(Cur.getCount()>0) {
                CustomerCode = new String[Cur.getCount()];
                CustomerName = new String[Cur.getCount()];
                CustomerNameTamil = new String[Cur.getCount()];
                Address = new String[Cur.getCount()];
                CustomerAreaCode = new String[Cur.getCount()];
                MobileNo = new String[Cur.getCount()];
                TelephoneNo = new String[Cur.getCount()];
                GSTN = new String[Cur.getCount()];
                SchemeApplicable = new String[Cur.getCount()];
                customertypecode = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    CustomerCode[i] = Cur.getString(0);
                    CustomerName[i] = Cur.getString(1);
                    CustomerNameTamil[i] = Cur.getString(2);
                    Address[i] = Cur.getString(3);
                    CustomerAreaCode[i] = Cur.getString(4);
                    MobileNo[i] = Cur.getString(6);
                    TelephoneNo[i] = Cur.getString(7);
                    GSTN[i] = Cur.getString(9);
                    SchemeApplicable[i] = Cur.getString(10);
                    customertypecode[i] = Cur.getString(11);
                    Cur.moveToNext();
                }

                customerdialog = new Dialog(context);
                customerdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customerdialog.setContentView(R.layout.customerpopup);
                lv_CustomerList = (ListView) customerdialog.findViewById(R.id.lv_CustomerList);
                ImageView close = (ImageView) customerdialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customerdialog.dismiss();
                    }
                });
                SalesCustomerAdapter adapter = new SalesCustomerAdapter(context);
                lv_CustomerList.setAdapter(adapter);
                customerdialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Customer in this area", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Customer in this area",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    /*********CLOSE FILTER FUNCTIONALITY********/

    //Check gstin functionality

    //cHECK GSTIN FORMAT
    private   boolean validGSTIN(String gstin) throws Exception {
        boolean isValidFormat = false;
        if (checkPattern(gstin, GSTINFORMAT_REGEX)) {
            isValidFormat = verifyCheckDigit(gstin);
        }
        return isValidFormat;

    }
    private   boolean verifyCheckDigit(String gstinWCheckDigit) throws Exception {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));

        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        }
        return isCDValid;
    }
    public static boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }
    public   String getGSTINWithCheckDigit(String gstinWOCheckDigit) throws Exception {
        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        try {
            if (gstinWOCheckDigit == null) {
                throw new Exception("GSTIN supplied for checkdigit calculation is null");
            }
            cpChars = GSTN_CODEPOINT_CHARS.toCharArray();
            inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

            int mod = cpChars.length;
            for (int i = inputChars.length - 1; i >= 0; i--) {
                int codePoint = -1;
                for (int j = 0; j < cpChars.length; j++) {
                    if (cpChars[j] == inputChars[i]) {
                        codePoint = j;
                    }
                }
                int digit = factor * codePoint;
                factor = (factor == 2) ? 1 : 2;
                digit = (digit / mod) + (digit % mod);
                sum += digit;
            }
            checkCodePoint = (mod - (sum % mod)) % mod;
            return gstinWOCheckDigit + cpChars[checkCodePoint];
        } finally {
            inputChars = null;
            cpChars = null;
        }
    }

    /********POPUP GROUP FUNCTIONALITY********/


    public  void GetSubGroupList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetSubGroupDB();
            if(Cur.getCount()>0) {
                SubGroupCode = new String[Cur.getCount()];
                SubGroupName = new String[Cur.getCount()];
                SubGroupNameTamil = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    SubGroupCode[i] = Cur.getString(0);
                    SubGroupName[i] = Cur.getString(1);
                    SubGroupNameTamil[i] = Cur.getString(2);
                    Cur.moveToNext();
                }

                SalesSubGroupAdapter adapter = new SalesSubGroupAdapter(context);
                lv_subgroup.setAdapter(adapter);
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"Van out of stock", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
               // Toast.makeText(getApplicationContext(),"Van out of stock",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    public  void GetItems(String itemsubgroupcode){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            lv_sales_items.setAdapter(null);
            Cur = objdatabaseadapter.GetItemsDB(itemsubgroupcode,MenuActivity.getroutecode,LoginActivity.getareacode);
            salesitems.clear();
            if(Cur.getCount()>0) {
                for(int i=0;i<Cur.getCount();i++){
                    salesitems.add(new SalesItemDetails(Cur.getString(0),Cur.getString(1),
                            Cur.getString(2),Cur.getString(3),Cur.getString(4),
                            Cur.getString(5),Cur.getString(6),Cur.getString(7),
                            Cur.getString(8),Cur.getString(9),Cur.getString(10),
                            Cur.getString(11),Cur.getString(12),Cur.getString(13),
                            Cur.getString(14),Cur.getString(15),Cur.getString(16),
                            Cur.getString(17),Cur.getString(18),Cur.getString(19),
                            Cur.getString(20),Cur.getString(21),Cur.getString(22),
                            Cur.getString(23),"0","0",Cur.getString(24),
                            "","","0","",Cur.getString(20),
                            Cur.getString(29),Cur.getString(30)));
                    Cur.moveToNext();
                }
                CalculateTotal();


                SalesItemAdapter adapter = new SalesItemAdapter(context,salesitems);
                lv_sales_items.setAdapter(adapter);
                isopenshowpopup=false;
                //Set ITEMQTY PRICE AND TOTAL
                for (int i = 0; i < staticreviewsalesitems.size(); i++) {
                    for (int j = 0; j < salesitems.size();j++) {
                        if (staticreviewsalesitems.get(i).getItemcode().equals(salesitems.get(j).getItemcode()) &&
                                !(staticreviewsalesitems.get(i).getFreeflag().equals("freeitem"))) {
                            salesitems.get(j).setItemqty(staticreviewsalesitems.get(i).getItemqty());
                            salesitems.get(j).setNewprice(staticreviewsalesitems.get(i).getNewprice());
                            salesitems.get(j).setSubtotal(staticreviewsalesitems.get(i).getSubtotal());
                            isopenshowpopup=true;
                        }
                    }
                }


            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Items Available", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Items Available",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }

    /*****END GROUP FUNCTIONALITY**********/

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dX = view.getX() - event.getRawX();
                dY = view.getY() - event.getRawY();
                lastAction = MotionEvent.ACTION_DOWN;
                break;

            case MotionEvent.ACTION_MOVE:
                view.setY(event.getRawY() + dY);
                view.setX(event.getRawX() + dX);
                lastAction = MotionEvent.ACTION_MOVE;
                break;

            case MotionEvent.ACTION_UP:

                break;

            default:
                return false;
        }
        return true;
    }



    public void CheckToggleButton(){
        try {
            if (togglegstin.isChecked()) {
                paymenttype = false;
                togglegstin.setTextOn("GSTIN \n " + gstnnumber);
                togglegstin.setBackgroundColor(getResources().getColor(R.color.green));
                if (gstnnumber.equals("")) {
                    togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                }
            } else {
                paymenttype = true;
                togglegstin.setTextOff("GSTIN \n " + gstnnumber);
                if (gstnnumber.equals("")) {
                    togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                }
                togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
            }
        } catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }
    private void ShowPopupWindow(){
        try {
            //Get phone imei number
            DataBaseAdapter objdatabaseadapter = null;
            String drilldownitem="subgroup";
            try{
                objdatabaseadapter = new DataBaseAdapter(context);
                objdatabaseadapter.open();
                drilldownitem = objdatabaseadapter.GetDrildownGroupStatusDB();

            }  catch (Exception e){
                Log.i("GetDrildown", e.toString());
            }
            finally {
                // this gets called even if there is an exception somewhere above
                if(objdatabaseadapter != null)
                    objdatabaseadapter.close();
            }

            if(drilldownitem.equals("group")) {
                isopenshowpopup=true;
                LayoutInflater inflater = (LayoutInflater) SalesActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.grouppopup, null);
                window = new PopupWindow(layout, 650, 1000, false);

                expList = (ExpandableListView) layout.findViewById(R.id.expandible_listview);
                ImageView close = (ImageView) layout.findViewById(R.id.close);

                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        window.dismiss();
                        fabgroupitem.startAnimation(rotate_backward);
                        isFabOpen = false;
                        isopenpopup = false;
                    }
                });
                //window.setOutsideTouchable(true);
                window.showAtLocation(layout, Gravity.BOTTOM, 0, 140);
                //setUpAdapter();
                window.setOutsideTouchable(false);
                isopenpopup = true;
                setChildItems();

                expandableAdapter = new ExpandableAdapter(this, listDataHEader, listhash);
                expList.setAdapter(expandableAdapter);

                expList.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
                    int previousGroup = -1;

                    @Override
                    public void onGroupExpand(int groupPosition) {
                        if (groupPosition != previousGroup)
                            expList.collapseGroup(previousGroup);
                        previousGroup = groupPosition;
                    }
                });
            }else{
                isopenshowpopup=true;
                LayoutInflater inflater = (LayoutInflater) SalesActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.subgrouppopup, null);
                window = new PopupWindow(layout, 650, 1000, false);

                lv_subgroup = (ListView) layout.findViewById(R.id.lv_subgroup);
                ImageView close = (ImageView) layout.findViewById(R.id.close);

                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        window.dismiss();
                        fabgroupitem.startAnimation(rotate_backward);
                        isFabOpen = false;
                        isopenpopup = false;
                    }
                });
                //window.setOutsideTouchable(true);
                window.showAtLocation(layout, Gravity.BOTTOM, 0, 140);
                //setUpAdapter();
                window.setOutsideTouchable(false);
                isopenpopup = true;

                //Call Sub group list
                GetSubGroupList();

            }

        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    private  void setChildItems(){
        listDataHEader = new ArrayList<>();
        listhash = new HashMap<>();

        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        Cursor Cur1=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetGroupDB();
            if(Cur.getCount()>0) {
                for(int i=0;i<Cur.getCount();i++){
                    listDataHEader.add(Cur.getString(2));
                    Cur1 = objdatabaseadapter.GetSubGroup_GroupDB(Cur.getString(0));
                    List<String> subgrouplist = new ArrayList<>();
                    List<String> subgrouplistcode = new ArrayList<>();
                    for(int j=0;j<Cur1.getCount();j++){
                        subgrouplist.add(Cur1.getString(2) + "-" +Cur1.getString(0));
                        Cur1.moveToNext();
                    }
                    listhash.put(listDataHEader.get(i),subgrouplist);
                    Cur.moveToNext();
                }

            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"Van out of stock", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"Van out of stock",Toast.LENGTH_SHORT).show();

            }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.fabgroupitem:
                animateFAB();
                break;
        }
    }
    public void animateFAB(){
        try{
        if(txtcustomername.getText().toString().equals("") || txtcustomername.getText().toString().equals(null) ||
                customercode.equals("") ){
            Toast toast = Toast.makeText(getApplicationContext(),"Please select customer", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            //Toast.makeText(getApplicationContext(),"Please select customer",Toast.LENGTH_SHORT).show();
            return;
        }else {
            boolean checkquantityflag = true;
            if(salesitems.size() > 0) {
                /*for (int i = 0; i < salesitems.size(); i++) {
                    if (!salesitems.get(i).getItemqty().equals("")
                            && !salesitems.get(i).getItemqty().equals(null)
                            && !salesitems.get(i).getItemqty().equals("0")
                            && !salesitems.get(i).getNewprice().equals(null)
                            && !salesitems.get(i).getNewprice().equals("")) {
                        if (Double.parseDouble(salesitems.get(i).getItemqty()) > 0
                                && Double.parseDouble(salesitems.get(i).getSubtotal()) > 0) {
                            checkquantityflag = true;
                        } else {
                            checkquantityflag = false;
                        }

                    }
                }*/
                for (int i = 0; i < lv_sales_items.getChildCount(); i++) {
                    View listRow = lv_sales_items.getChildAt(i);
                    EditText getlistqty = (EditText) listRow.findViewById(R.id.listitemqty);
                    TextView getlisttotal = (TextView) listRow.findViewById(R.id.listitemtotal);
                    String getitemlistqty = getlistqty.getText().toString();
                    String getitemlisttotal = getlisttotal.getText().toString();
                    if(!getitemlistqty.equals("") && !getitemlistqty.equals(null)){
                        if(Double.parseDouble(getitemlistqty)>0 && Double.parseDouble(getitemlisttotal)<=0.0){
                            getlistqty.requestFocus();
                            Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid total amount", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            return;
                        }
                    }
                }
            }

            if (isopenpopup) {
                window.dismiss();
                isFabOpen = true;
                isopenpopup = false;
            } else {
                ShowPopupWindow();
            }
            if (isFabOpen) {
                fabgroupitem.startAnimation(rotate_backward);
                isFabOpen = false;
                Log.d("Fab", "close");
            } else {
                fabgroupitem.startAnimation(rotate_forward);
                isFabOpen = true;
                Log.d("Fab", "open");
            }
        }
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }

    public class SalesItemAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;
        ArrayList<SalesItemDetails> salesItemList;
        String isparentopen="";
        final DecimalFormat dft = new DecimalFormat("0.00");
        String getstaticparentitemcode="0";
        String getstaticchilditemname="",getstaticchildunitname = "";
        String getstaticchildcode="";
        String isfreestock="";
        boolean isnillstockconversion=false;

        SalesItemAdapter(Context c,ArrayList<SalesItemDetails> myList) {
            this.salesItemList = myList;
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return salesItemList.size();
        }

        @Override
        public SalesItemDetails getItem(int position) {
            return (SalesItemDetails) salesItemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            if(getCount() > 0){
                return getCount();
            }else{
                return super.getViewTypeCount();
            }
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            final ViewHolder1 mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.salesitemlist, parent, false);
                mHolder = new ViewHolder1();
                try {
                    mHolder.listitemname = (TextView) convertView.findViewById(R.id.listitemname);
                    mHolder.listitemcode = (TextView) convertView.findViewById(R.id.listitemcode);
                    mHolder.listitemqty = (EditText) convertView.findViewById(R.id.listitemqty);
                    mHolder.listitemrate = (EditText) convertView.findViewById(R.id.listitemrate);
                    mHolder.listitemtotal = (TextView) convertView.findViewById(R.id.listitemtotal);
                    mHolder.listitemtax = (TextView) convertView.findViewById(R.id.listitemtax);
                    mHolder.labelstock = (TextView)convertView.findViewById(R.id.labelstock);
                    mHolder.labelhsntax = (TextView)convertView.findViewById(R.id.labelhsntax);
                    mHolder.itemLL = (LinearLayout)convertView.findViewById(R.id.itemLL);
                    mHolder.stockvalueLL = (LinearLayout)convertView.findViewById(R.id.stockvalueLL);
                    mHolder.labelnilstock = (TextView)convertView.findViewById(R.id.labelnilstock);
                    mHolder.labelstockunit = (TextView)convertView.findViewById(R.id.labelstockunit);
                    mHolder.pricearrow = (ImageView)convertView.findViewById(R.id.pricearrow);
                    mHolder.listdiscount = (TextView)convertView.findViewById(R.id.listdiscount);
                    mHolder.schemecount = (TextView)convertView.findViewById(R.id.schemecount);
                    mHolder.dummycount = (TextView)convertView.findViewById(R.id.dummycount);
                    //Item PRice text change Listner
                    mHolder.listitemqty.addTextChangedListener(new TextWatcher() {
                        public void onTextChanged(CharSequence s, int start, int before,
                                                  int count) {
                            if (!(mHolder.listitemqty.getText().toString()).equals("") &&
                                    !(mHolder.listitemqty.getText().toString()).equals(" ")
                                    && !(mHolder.listitemqty.getText().toString()).equals("0")
                                    && !(mHolder.listitemqty.getText().toString()).equals("0.0")
                                    && !(mHolder.listitemqty.getText().toString()).equals(null)
                                    && !(mHolder.listitemrate.getText().toString()).equals("")
                                    && !(mHolder.listitemrate.getText().toString()).equals(0)
                                    && !(mHolder.listitemqty.getText().toString()).equals(".")
                                    && !(mHolder.listitemrate.getText().toString()).equals(".")) {
                                final int pos1 = (Integer) mHolder.listitemrate.getTag();
                                String getqtyval = mHolder.listitemqty.getText().toString();
                                salesItemList.get(pos1).setItemqty(mHolder.listitemqty.getText().toString());
                                if(Double.parseDouble(mHolder.listitemtotal.getText().toString()) >0){
                                    mHolder.listitemtotal.setText("0.00");
                                    mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                    mHolder.listitemtotal.setText("0.00");
                                    mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                    DataBaseAdapter objdatabaseadapter = null;
                                    Cursor getcartdatas = null;
                                    try {
                                        //Order item details
                                        objdatabaseadapter = new DataBaseAdapter(context);
                                        objdatabaseadapter.open();
                                        String getresult = objdatabaseadapter.DeleteItemInCart(salesItemList.get(pos1).getItemcode());
                                        if (getresult.equals("Success")) {
                                            getcartdatas = objdatabaseadapter.GetSalesItemsCart();
                                            if(getcartdatas.getCount()>0){
                                                totalcartitems.setText(String.valueOf(getcartdatas.getCount()));
                                            }else{
                                                totalcartitems.setText(String.valueOf("0"));
                                            }
                                            salesItemList.get(pos1).setItemqty("");
                                            salesItemList.get(pos1).setNewprice("");
                                        }
                                    } catch (Exception e) {
                                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                        mDbErrHelper.open();
                                        String geterrror = e.toString();
                                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                        mDbErrHelper.close();
                                    } finally {
                                        if (objdatabaseadapter != null)
                                            objdatabaseadapter.close();
                                        if (getcartdatas != null)
                                            getcartdatas.close();

                                    }
                                }
                            }
                            else{
                                final int pos1 = (Integer) mHolder.listitemrate.getTag();
                                if(!mHolder.listitemtotal.getText().toString().equals("")
                                        && !mHolder.listitemtotal.getText().toString().equals(null)) {
                                    if (Double.parseDouble(mHolder.listitemtotal.getText().toString()) > 0) {
                                        mHolder.listitemtotal.setText("0.00");
                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                        DataBaseAdapter objdatabaseadapter = null;
                                        Cursor getcartdatas = null;
                                        try {
                                            //Order item details
                                            objdatabaseadapter = new DataBaseAdapter(context);
                                            objdatabaseadapter.open();
                                            String getresult = objdatabaseadapter.DeleteItemInCart(salesItemList.get(pos1).getItemcode());
                                            if (getresult.equals("Success")) {
                                                getcartdatas = objdatabaseadapter.GetSalesItemsCart();
                                                if(getcartdatas.getCount()>0){
                                                    totalcartitems.setText(String.valueOf(getcartdatas.getCount()));
                                                }else{
                                                    totalcartitems.setText(String.valueOf("0"));
                                                }
                                                salesItemList.get(pos1).setItemqty("");
                                                salesItemList.get(pos1).setNewprice("");
                                                salesitems.get(pos1).setItemqty("");
                                                salesitems.get(pos1).setNewprice("");
                                                mHolder.listitemqty.setText("");

                                            }
                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if (objdatabaseadapter != null)
                                                objdatabaseadapter.close();
                                            if (getcartdatas != null)
                                                getcartdatas.close();

                                        }
                                    }
                                }
                            }

                        }
                        public void beforeTextChanged(CharSequence s, int start, int count,
                                                      int after) {
                        }
                        public void afterTextChanged(Editable s) {

                        }
                    });

                    convertView.setTag(mHolder);
                    convertView.setTag(R.id.listitemname, mHolder.listitemname);
                    convertView.setTag(R.id.listitemcode, mHolder.listitemcode);
                    convertView.setTag(R.id.listitemqty, mHolder.listitemqty);
                    convertView.setTag(R.id.listitemrate, mHolder.listitemrate);
                    convertView.setTag(R.id.listitemtotal, mHolder.listitemtotal);
                    convertView.setTag(R.id.listitemtax, mHolder.listitemtax);
                    convertView.setTag(R.id.labelstock, mHolder.labelstock);
                    convertView.setTag(R.id.labelhsntax, mHolder.labelhsntax);
                    convertView.setTag(R.id.labelstockunit, mHolder.labelstockunit);
                    convertView.setTag(R.id.schemecount, mHolder.schemecount);
                    convertView.setTag(R.id.dummycount, mHolder.dummycount);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder1) convertView.getTag();
            }
            mHolder.listitemname.setTag(position);
            mHolder.listitemcode.setTag(position);
            mHolder.listitemqty.setTag(position);
            mHolder.listitemrate.setTag(position);
            mHolder.listitemtotal.setTag(position);
            mHolder.listitemtax.setTag(position);
            mHolder.labelstock.setTag(position);
            mHolder.labelhsntax.setTag(position);
            mHolder.labelstockunit.setTag(position);
            mHolder.schemecount.setTag(position);
            mHolder.dummycount.setTag(position);
            try {

                String getdecimalvalue  = salesItemList.get(position).getNoofdecimals();
                String getnoofdigits = "0";
                if(getdecimalvalue.equals("0")){
                    getnoofdigits = "";
                }
                if(getdecimalvalue.equals("1")){
                    getnoofdigits = "0";
                }
                if(getdecimalvalue.equals("2")){
                    getnoofdigits = "00";
                }
                if(getdecimalvalue.equals("3")){
                    getnoofdigits = "000";
                }

                df = new DecimalFormat("0.00");

                if (!(salesItemList.get(position).getItemnametamil().equals(""))
                        && !(salesItemList.get(position).getItemnametamil()).equals("null")
                        && !((salesItemList.get(position).getItemnametamil()).equals(null))) {
                    mHolder.listitemname.setText(String.valueOf(salesItemList.get(position).getItemnametamil()));
                } else {
                    mHolder.listitemname.setText(String.valueOf(salesItemList.get(position).getItemname()));
                }
                mHolder.listitemcode.setText(String.valueOf(salesItemList.get(position).getItemcode()));

                if(!String.valueOf(salesItemList.get(position).getNewprice()).equals("null")
                        && !String.valueOf(salesItemList.get(position).getNewprice()).equals("")
                        &&!String.valueOf(salesItemList.get(position).getNewprice()).equals(null)) {
                        mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(position).getNewprice())));

                }else{
                    //if(!getnoofdigits.equals("")) {
                        mHolder.listitemrate.setText(dft.format(Double.parseDouble("0")));
                    //}else{
                    //    mHolder.listitemrate.setText(String.valueOf(Double.parseDouble("0")));
                    //}
                }
                mHolder.listitemname.setTextColor(Color.parseColor(salesItemList.get(position).getColourcode()));

                if(Double.parseDouble(salesItemList.get(position).getOldprice()) >
                        Double.parseDouble(salesItemList.get(position).getNewprice()) ){
                    mHolder.pricearrow.setImageResource(R.drawable.ic_arrow_downward);
                }else{
                    mHolder.pricearrow.setImageResource(R.drawable.ic_arrow_upward_black_24dp);
                }
                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                //Stock
                if(salesItemList.get(position).getStockqty().equals("0") || salesItemList.get(position).getStockqty().equals("null")
                        ||  salesItemList.get(position).getStockqty().equals(null) || salesItemList.get(position).getStockqty().equals("") ||
                 Double.parseDouble(salesItemList.get(position).getStockqty())<=0) {
                    mHolder.labelnilstock.setVisibility(View.VISIBLE);
                    mHolder.labelnilstock.setText("Nil Stk");
                    mHolder.stockvalueLL.setVisibility(View.GONE);
                    mHolder.labelstock.setText("0");
                    mHolder.labelstock.setBackgroundColor(getResources().getColor(R.color.red));
                    mHolder.itemLL.setBackgroundColor(getResources().getColor(R.color.lightgray));
                    mHolder.labelstock.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                    mHolder.listitemrate.setBackgroundResource(R.drawable.editbackgroundgray);
                    mHolder.listitemqty.setBackgroundResource(R.drawable.editbackgroundgray);
                    mHolder.listitemrate.setEnabled(false);
                    mHolder.listitemqty.setEnabled(false);

                }else{
                    mHolder.stockvalueLL.setVisibility(View.VISIBLE);
                    mHolder.labelnilstock.setVisibility(View.GONE);
                    mHolder.labelstock.setText(salesItemList.get(position).getStockqty());
                    mHolder.labelstockunit.setText(" "+salesItemList.get(position).getUnitname());
                    mHolder.labelstock.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                    mHolder.labelstock.setBackground(ContextCompat.getDrawable(context, R.color.green));
                    //mHolder.itemLL.setBackgroundColor(getResources().getColor(R.color.white));
                    mHolder.listitemrate.setBackgroundResource(R.drawable.editbackground);
                    mHolder.listitemqty.setBackgroundResource(R.drawable.editbackground);
                    mHolder.listitemrate.setEnabled(true);
                    mHolder.listitemqty.setEnabled(true);
                }
                if (salesItemList.get(position).getAllownegativestock().equals("no")) {
                    if (salesItemList.get(position).getItemcategory().equals("child")) {
                        final int pos = (Integer) mHolder.listitemqty.getTag();
                        double getparentstock = 0.0;
                        DataBaseAdapter objdatabaseadapter = null;
                        Cursor getStockCur = null;
                        try {
                            //Get Stock for parent item
                            objdatabaseadapter = new DataBaseAdapter(context);
                            objdatabaseadapter.open();
                            getStockCur = objdatabaseadapter.GetStockForItem(salesItemList.get(pos).getParentitemcode());
                            if (getStockCur.getCount() > 0) {
                                // for (int i = 0; i < getStockCur.getCount(); i++) {
                                getparentstock = getStockCur.getDouble(0);
                                //}
                            }
                            if (getparentstock > 0) {
                                isfreestock = "";
                                getstaticparentitemcode = salesItemList.get(pos).getParentitemcode();
                                getstaticchilditemname = salesItemList.get(pos).getItemnametamil();
                                getstaticchildunitname = salesItemList.get(pos).getUnitname();
                                isnillstockconversion = true;

                                mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.yellow));
                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                            }/*else{
                                //isnillstockconversion = false;
                            }*/
                        }catch (Exception e) {
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        } finally {
                            if (objdatabaseadapter != null)
                                objdatabaseadapter.close();
                            if (getStockCur != null)
                                getStockCur.close();
                        }

                    }else{
                       // isnillstockconversion=false;
                    }
                }else{
                    isnillstockconversion=false;
                }


                mHolder.labelhsntax.setText(salesItemList.get(position).getHsn() +" @ "+salesItemList.get(position).getTax() +"%");


                //Set Stock Conversion Qty for child item
                if(!getstaticgetchildqty.equals("") && !getstaticgetchildqty.equals(null)
                        && !getstaticgetchildqty.equals("0")){
                    if(salesItemList.get(position).getItemcode().equals(getstaticchilditemcode)){
                        if(Double.parseDouble(salesItemList.get(position).getStockqty())
                                > Double.parseDouble(getstaticgetchildqty)){
                            mHolder.listitemqty.setText(getstaticgetchildqty);
                        }else{
                            mHolder.listitemqty.setText("");
                        }

                    }
                }

                if (getschemeapplicable.equals("yes")) {
                    if(Double.parseDouble(salesItemList.get(position).getRatecount()) >0) {
                        mHolder.schemecount.setVisibility(View.VISIBLE);
                        mHolder.schemecount.setText("R");
                        mHolder.dummycount.setVisibility(View.GONE);
                    }
                    if(Double.parseDouble(salesItemList.get(position).getFreecount()) >0) {
                        mHolder.schemecount.setVisibility(View.VISIBLE);
                        mHolder.schemecount.setText("F");
                        mHolder.dummycount.setVisibility(View.GONE);
                    }

                }else{
                    mHolder.dummycount.setVisibility(View.VISIBLE);
                    mHolder.schemecount.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                Log.i("Item value", e.toString());
            }

            //Allow price Edit
            if(salesItemList.get(position).getAllowpriceedit().equals("yes") &&
                    salesItemList.get(position).getRouteallowpricedit().equals("yes")){
                mHolder.listitemrate.setBackgroundResource(R.drawable.editbackground);
                mHolder.listitemrate.setEnabled(true);
            }else{
                mHolder.listitemrate.setBackgroundResource(R.drawable.editbackgroundgray);
                mHolder.listitemrate.setEnabled(false);
            }

            //Set Discount background
            mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
            mHolder.listdiscount.setText("");


            //Set Quantity,price
            if (!salesItemList.get(position).getItemqty().equals("") &&
                    !salesItemList.get(position).getItemqty().equals("0")
                    && !salesItemList.get(position).getItemqty().equals(null) &&  isopenshowpopup) {
                DataBaseAdapter objdatabaseadapter = null;
                Cursor getItemCur = null;
                try {
                    //Get Stock for parent item
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    getItemCur = objdatabaseadapter.GetCartItemQtyAndPrice(salesItemList.get(position).getItemcode());
                    if (getItemCur.getCount() > 0) {
                        mHolder.listitemrate.setText(String.valueOf(getItemCur.getString(1)));
                        mHolder.listitemqty.setText(String.valueOf(getItemCur.getString(0)));
                        mHolder.listitemtotal.callOnClick();
                    }

                }catch (Exception e) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if (objdatabaseadapter != null)
                        objdatabaseadapter.close();
                    if (getItemCur != null)
                        getItemCur.close();
                }


            }

            //Item PRice text change Listner
            mHolder.listitemrate.addTextChangedListener(new TextWatcher() {
                public void onTextChanged(CharSequence s, int start, int before,
                                          int count) {

                }
                public void beforeTextChanged(CharSequence s, int start, int count,
                                              int after) {
                }
                public void afterTextChanged(Editable s) {
                    if (!(mHolder.listitemqty.getText().toString()).equals("") &&
                            !(mHolder.listitemqty.getText().toString()).equals(" ")
                            && !(mHolder.listitemqty.getText().toString()).equals("0")
                            && !(mHolder.listitemqty.getText().toString()).equals("0.0")
                            && !(mHolder.listitemqty.getText().toString()).equals(null)
                            && !(mHolder.listitemrate.getText().toString()).equals("")
                            && !(mHolder.listitemrate.getText().toString()).equals(0)
                            && !(mHolder.listitemqty.getText().toString()).equals(".")
                            && !(mHolder.listitemrate.getText().toString()).equals(".")) {
                        final int pos1 = (Integer) mHolder.listitemrate.getTag();
                        String getqtyval = salesItemList.get(pos1).getItemqty();
                       // mHolder.listitemqty.setText(getqtyval);
                      //  mHolder.listitemtotal.callOnClick();
                    }/*else{
                        final int pos1 = (Integer) mHolder.listitemrate.getTag();
                        //mHolder.listitemtotal.setText("0.00");
                        //Set Discount background
                        mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.white));
                        mHolder.listdiscount.setText("");
                        salesItemList.get(pos1).setSubtotal(mHolder.listitemtotal.getText().toString());
                    }*/
                }
            });



            /**********************************************************************************/
            //ONCHANGE QUANTITY EVENT

            mHolder.listitemtotal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean addedqty = false;
                        if (!(mHolder.listitemqty.getText().toString()).equals("") &&
                                !(mHolder.listitemqty.getText().toString()).equals(" ")
                                && !(mHolder.listitemqty.getText().toString()).equals("0")
                                && !(mHolder.listitemqty.getText().toString()).equals("0.0")
                                && !(mHolder.listitemqty.getText().toString()).equals(null)
                                && !(mHolder.listitemqty.getText().toString()).equals(".")
                                && Double.parseDouble(mHolder.listitemqty.getText().toString()) > 0) {
                            //mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.white));
                           // isparentopen = "";
                            isfreestock = "";
                            //Delcare variables
                            double getminqty = 0;
                            double getdiscount = 0;
                            double getparentstock = 0;

                            final int pos = (Integer) mHolder.listitemtotal.getTag();



                            /***********CHECK STOCK TRANSACTION******************/
                            if (salesItemList.get(pos).getAllownegativestock().equals("no")) {
                                if (Double.parseDouble(mHolder.listitemqty.getText().toString()) >
                                        Double.parseDouble(mHolder.labelstock.getText().toString())) {
                                    if (salesItemList.get(pos).getItemcategory().equals("child")) {
                                        DataBaseAdapter objdatabaseadapter = null;
                                        Cursor getStockCur = null;
                                        try {
                                            //Get Stock for parent item
                                            objdatabaseadapter = new DataBaseAdapter(context);
                                            objdatabaseadapter.open();
                                            getStockCur = objdatabaseadapter.GetStockForItem(salesItemList.get(pos).getParentitemcode());
                                            if (getStockCur.getCount() > 0) {
                                                // for (int i = 0; i < getStockCur.getCount(); i++) {
                                                getparentstock = getStockCur.getDouble(0);
                                                //}
                                            }
                                            if (getparentstock > 0) {
                                                isfreestock = "";
                                                getstaticparentitemcode = salesItemList.get(pos).getParentitemcode();
                                                getstaticchilditemname = salesItemList.get(pos).getItemnametamil();
                                                getstaticchildunitname = salesItemList.get(pos).getUnitname();
                                                isparentopen = "yes";
                                                Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock..", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.yellow));
                                                mHolder.listitemqty.setText("");
                                                mHolder.listitemtotal.setText("0.00");
                                                salesItemList.get(pos).setSubtotal("0.00");
                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));

                                                String getresult=DeleteItemCart(salesItemList.get(pos).getItemcode());
                                                if(getresult.equals("Success")) {
                                                    salesItemList.get(pos).setItemqty("");
                                                    salesItemList.get(pos).setNewprice("");
                                                }

                                            } else {
                                                //mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.white));
                                                Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock..", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                mHolder.listitemtotal.setText("0.00");
                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                                //Toast.makeText(getApplicationContext(), "Insufficient stock..", Toast.LENGTH_SHORT).show();
                                                mHolder.listitemqty.setText("");
                                                String getresult=DeleteItemCart(salesItemList.get(pos).getItemcode());
                                                if(getresult.equals("Success")) {
                                                    salesItemList.get(pos).setItemqty("");
                                                    salesItemList.get(pos).setNewprice("");
                                                }
                                            }
                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if (objdatabaseadapter != null)
                                                objdatabaseadapter.close();
                                            if (getStockCur != null)
                                                getStockCur.close();
                                        }
                                    } else {
                                        Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock..", Toast.LENGTH_LONG);
                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                        toast.show();
                                        mHolder.listitemtotal.setText("0.00");
                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                        mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                        //Toast.makeText(getApplicationContext(), "Insufficient stock..", Toast.LENGTH_SHORT).show();
                                        mHolder.listitemqty.setText("");
                                        String getresult=DeleteItemCart(salesItemList.get(pos).getItemcode());
                                        if(getresult.equals("Success")) {
                                            salesItemList.get(pos).setItemqty("");
                                            salesItemList.get(pos).setNewprice("");
                                        }
                                    }
                                }
                            }
                            /***********END CHECK STOCK TRANSACTION******************/
                            if (!mHolder.listitemqty.getText().toString().equals("")) {
                                if (Double.parseDouble(mHolder.listitemqty.getText().toString()) >0  ) {
                                    //<=Double.parseDouble(mHolder.labelstock.getText().toString())
                                    DecimalFormat dffor = new DecimalFormat("0.00");
                                    String getdecimalvalue = salesItemList.get(pos).getNoofdecimals();
                                    String getnoofdigits = "0";
                                    if (getdecimalvalue.equals("0")) {
                                        getnoofdigits = "";
                                    }
                                    if (getdecimalvalue.equals("1")) {
                                        getnoofdigits = "0";
                                    }
                                    if (getdecimalvalue.equals("2")) {
                                        getnoofdigits = "00";
                                    }
                                    if (getdecimalvalue.equals("3")) {
                                        getnoofdigits = "000";
                                    }
                                    df = new DecimalFormat("0.'" + getnoofdigits + "'");

                                    /*********SCHEME DETAILS*************/
                                    if (getschemeapplicable.equals("yes")) {

                                        //Get Scheme Rate based
                                        DataBaseAdapter objdatabaseadapter = null;
                                        Cursor getschemeCur = null;
                                        try {
                                            //Scheme Functionality
                                            objdatabaseadapter = new DataBaseAdapter(context);
                                            objdatabaseadapter.open();
                                            getschemeCur = objdatabaseadapter.GetSchemeFORItemDB(salesItemList.get(pos).getItemcode(),
                                                    MenuActivity.getroutecode,mHolder.listitemqty.getText().toString());
                                            if (getschemeCur.getCount() > 0) {
                                                //  for (int i = 0; i < getschemeCur.getCount(); i++) {
                                                getminqty = getschemeCur.getDouble(0);
                                                getdiscount = getschemeCur.getDouble(1);
                                                // }
                                            }
                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if (objdatabaseadapter != null)
                                                objdatabaseadapter.close();
                                            if (getschemeCur != null)
                                                getschemeCur.close();
                                        }

                                        //Get Item based Free Item
                                        //GetFreeItem(salesItemList.get(pos).getItemcode(),mHolder.listitemqty.getText().toString());

                                        /********FREE ITEM******************/

                                        String getitemcode = salesItemList.get(pos).getItemcode();
                                        String getqty = mHolder.listitemqty.getText().toString();
                                        //Get Free Item variable
                                        String getfreeitemname = "";
                                        //Get free and purchase item code
                                        String getpurchaseitemcode = "";
                                        String getpurchaseqty = "";
                                        String getfreeitemcode = "";
                                        String getfreeqty = "";
                                        String getallownegativestock = "";
                                        double getfreestockitem = 0;
                                        String getitemcategory = "";
                                        String getparentcode = "";
                                        String getchilditemname = "";
                                        String getchildunitname = "";

                                        //Get Item based Free Item
                                        DataBaseAdapter objdatabaseadapterfree = null;
                                        Cursor getitemschemeCur = null;
                                        Cursor getFreeStock = null;
                                        try {
                                            //Scheme Functionality
                                            objdatabaseadapterfree = new DataBaseAdapter(context);
                                            objdatabaseadapterfree.open();
                                            getitemschemeCur = objdatabaseadapterfree.GetSchemeFORFreeItemDB(getitemcode, MenuActivity.getroutecode);
                                            if (getitemschemeCur.getCount() > 0) {
                                                //freeitems.clear();
                                                // for (int i = 0; i < getitemschemeCur.getCount(); i++) {
                                                getpurchaseitemcode = getitemschemeCur.getString(0);
                                                getpurchaseqty = getitemschemeCur.getString(1);
                                                getfreeitemcode = getitemschemeCur.getString(2);
                                                getfreeqty = getitemschemeCur.getString(3);
                                                // }
                                                if (Double.parseDouble(getpurchaseqty) <=
                                                        Double.parseDouble(getqty)) {
                                                    try {
                                                        //Get Stock for parent item
                                                        String getmanualfreeitemname = objdatabaseadapterfree.GetFreeitemname(getfreeitemcode);
                                                        getfreeitemname = getmanualfreeitemname;
                                                        getFreeStock = objdatabaseadapterfree.GetPurchaseItems(getfreeitemcode, MenuActivity.getroutecode, LoginActivity.getareacode);
                                                        if (getFreeStock.getCount() > 0) {
                                                            for (int i = 0; i < getFreeStock.getCount(); i++) {
                                                                //getfreeitemstock = getFreeStock.getDouble(0);
                                                                getallownegativestock = getFreeStock.getString(14);
                                                                getfreestockitem = getFreeStock.getDouble(16);
                                                                getitemcategory = getFreeStock.getString(11);
                                                                getparentcode = getFreeStock.getString(12);
                                                                getchilditemname = getFreeStock.getString(5);
                                                                getchildunitname = getFreeStock.getString(17);

                                                            }
                                                        }

                                                        //Calculate Qty with total qty
                                                        Double getactualqty = Double.parseDouble(getqty);
                                                        int getfreeqtyval = (int) (getactualqty / Double.parseDouble(getpurchaseqty));
                                                        int getactualqtyvalue = (int) (getfreeqtyval * Double.parseDouble(getfreeqty));
                                                        String getcartqty = objdatabaseadapter.GetCartItemStock(getfreeitemcode);
                                                        if(getpurchaseitemcode.equals(getfreeitemcode)){
                                                            if(Double.parseDouble(mHolder.labelstock.getText().toString())<(Double.parseDouble(String.valueOf(getactualqtyvalue))+Double.parseDouble(getqty))){
                                                                Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock for " + getfreeitemname , Toast.LENGTH_LONG);
                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                toast.show();
                                                                mHolder.listitemtotal.setText("0.00");
                                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                                return;
                                                            }
                                                        }
                                                        if (getfreestockitem  >= Double.parseDouble(String.valueOf(getactualqtyvalue))) {
                                                            getFreeStock = null;
                                                            //Get Stock for parent item
                                                            getFreeStock = objdatabaseadapterfree.GetPurchaseItems(getfreeitemcode, MenuActivity.getroutecode, LoginActivity.getareacode);

                                                            if (getFreeStock.getCount() > 0) {
                                                                for (int i = 0; i < getFreeStock.getCount(); i++) {
                                                                    double getsubtotal = Double.parseDouble(getFreeStock.getString(20)) * getactualqtyvalue;

                                                                    for (int j = 0; j < freeitems.size(); j++) {
                                                                        if (getpurchaseitemcode.equals(freeitems.get(j).getPurchaseitemcode()) &&
                                                                                getfreeitemcode.equals(freeitems.get(j).getFreeitemcode())) {
                                                                            freeitems.remove(j);
                                                                        }
                                                                    }
                                                                    freeitems.add(new SalesItemDetails(getFreeStock.getString(0), getFreeStock.getString(1),
                                                                            getFreeStock.getString(2)
                                                                            , getFreeStock.getString(3), getFreeStock.getString(4),
                                                                            getFreeStock.getString(5), getFreeStock.getString(6),
                                                                            getFreeStock.getString(7)
                                                                            , getFreeStock.getString(8), getFreeStock.getString(9), getFreeStock.getString(10)
                                                                            , getFreeStock.getString(11), getFreeStock.getString(12)
                                                                            , getFreeStock.getString(13), getFreeStock.getString(14), getFreeStock.getString(15)
                                                                            , getFreeStock.getString(16), getFreeStock.getString(17)
                                                                            , getFreeStock.getString(18), getFreeStock.getString(19),
                                                                            getFreeStock.getString(20)
                                                                            , getFreeStock.getString(21), getFreeStock.getString(22)
                                                                            , getFreeStock.getString(23), String.valueOf(getactualqtyvalue), String.valueOf(getsubtotal),
                                                                            getFreeStock.getString(24), "",
                                                                            "freeitem", getpurchaseitemcode, getfreeitemcode,getFreeStock.getString(20),"",""));

                                                                }
                                                            }
                                                        } else {
                                                           /* Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock for " + getfreeitemname + " this free item", Toast.LENGTH_LONG);
                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                            toast.show();
                                                            mHolder.listitemtotal.setText("0.00");
                                                            mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                            mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                                            return;*/

                                                            //freeitems.clear();
                                                            if (getallownegativestock.equals("no")) {
                                                               // if (Double.parseDouble(getqty) > getfreestockitem) {
                                                                    if (getitemcategory.equals("child")) {
                                                                        DataBaseAdapter objdatabaseadapter1 = null;
                                                                        Cursor getStockCur = null;
                                                                        try {
                                                                            //Get Stock for parent item
                                                                            objdatabaseadapter1 = new DataBaseAdapter(context);
                                                                            objdatabaseadapter1.open();
                                                                            getStockCur = objdatabaseadapter1.GetStockForItem(getparentcode);
                                                                            String getcartparentqty = objdatabaseadapter.GetCartItemStock(getparentcode);
                                                                            if (getStockCur.getCount() > 0) {
                                                                                for (int i = 0; i < getStockCur.getCount(); i++) {
                                                                                    getparentstock = getStockCur.getDouble(0);

                                                                                }
                                                                                getparentstock = getparentstock - (Double.parseDouble(getcartparentqty));
                                                                            }

                                                                            if (getparentstock > 0 ) {

                                                                                //> Double.parseDouble(String.valueOf(getactualqtyvalue))

                                                                                Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock for " + getfreeitemname + " this free item", Toast.LENGTH_LONG);
                                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                toast.show();
                                                                                mHolder.listitemtotal.setText("0.00");
                                                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                                                mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                                                                return;
                                                                                //Stock Conversion
                                                                                /*isfreestock = "yes";
                                                                                getstaticchildcode = getfreeitemcode;
                                                                                getstaticparentitemcode = getparentcode;
                                                                                getstaticchilditemname = getchilditemname;
                                                                                getstaticchildunitname = getchildunitname;
                                                                                isparentopen = "yes";
                                                                                mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.yellow));
                                                                                mHolder.listitemqty.setText("");
                                                                                mHolder.listitemtotal.setText("0.00");
                                                                                salesItemList.get(pos).setSubtotal("0.00");
                                                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));*/

                                                                            } else {
                                                                                Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock for " + getfreeitemname , Toast.LENGTH_LONG);
                                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                toast.show();
                                                                                mHolder.listitemtotal.setText("0.00");
                                                                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                                                mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));

                                                                            }
                                                                        } catch (Exception e) {
                                                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                                                            mDbErrHelper.open();
                                                                            String geterrror = e.toString();
                                                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                                            mDbErrHelper.close();
                                                                        } finally {
                                                                            if (objdatabaseadapter1 != null)
                                                                                objdatabaseadapter1.close();
                                                                            if (getStockCur != null)
                                                                                getStockCur.close();
                                                                        }
                                                                    } else {
                                                                        Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock for " + getfreeitemname + " this free item", Toast.LENGTH_LONG);
                                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                                        toast.show();
                                                                        mHolder.listitemtotal.setText("0.00");
                                                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                                                        mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));

                                                                    }
                                                                //}
                                                            }
                                                        }
                                                    } catch (Exception e) {
                                                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                                        mDbErrHelper.open();
                                                        String geterrror = e.toString();
                                                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                        mDbErrHelper.close();
                                                    }
                                                } /*else {
                                                  *//*  for (int k = 0; k < freeitems.size(); k++) {
                                                        for (int l = 0; l < staticreviewsalesitems.size(); l++) {
                                                            if (freeitems.get(k).getPurchaseitemcode().equals(staticreviewsalesitems.get(l).getPurchaseitemcode()) &&
                                                                    freeitems.get(k).getFreeitemcode().equals(staticreviewsalesitems.get(l).getFreeitemcode())) {
                                                                if (staticreviewsalesitems.get(l).getFreeflag().equals("freeitem")) {
                                                                    staticreviewsalesitems.remove(l);
                                                                }
                                                            }
                                                        }
                                                    }*//*
                                                    //freeitems.clear();
                                                }*/

                                            }
                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if (objdatabaseadapterfree != null)
                                                objdatabaseadapterfree.close();
                                            if (getitemschemeCur != null)
                                                getitemschemeCur.close();
                                            if (getFreeStock != null)
                                                getFreeStock.close();
                                        }

                                    }

                                    /*********END SCHEME DETAILS*************/


                                    String varQty = mHolder.listitemqty.getText().toString();
                                    if (varQty.equals("0") || varQty.equals("") || varQty.equals(null)) {
                                        varQty = "0";
                                    }
                                    //if(!varQty.equals("") && !varQty.equals("null")
                                    //   && !varQty.equals(null) && !varQty.equals("0")) {
                                    salesItemList.get(pos).setItemqty(varQty);
                                    salesItemList.get(pos).setDumyprice(mHolder.listitemrate.getText().toString());
                                    //mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                    salesItemList.get(pos).setNewprice(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                    if (getminqty > 0) {
                                        //do your work here
                                        Double a = Double.parseDouble(mHolder.listitemqty.getText().toString());

                                        Double b = Double.parseDouble(mHolder.listitemrate.getText().toString());
                                        Double res = a * b;

                                        int getdivideqty = (int) (a / getminqty);
                                        Double getactucaldiscount = getdivideqty * getdiscount;
                                       // Double getres = res - getactucaldiscount;

                                        if (getdivideqty > 0) {
                                            double newrate = Double.parseDouble(salesItemList.get(pos).getNewprice());
                                            double getnewrate = newrate - getdiscount ;
                                            mHolder.listitemrate.setText(dft.format(getnewrate));
                                            salesItemList.get(pos).setNewprice(dft.format(getnewrate));
                                            Double getres = getnewrate * Double.parseDouble(varQty);
                                            mHolder.listitemtotal.setText(dft.format(getres));
                                            /*mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.orangecolor));
                                            mHolder.listdiscount.setText("Disc " + dft.format(getactucaldiscount));
                                            salesItemList.get(pos).setDiscount(dft.format(getactucaldiscount));*/
                                            mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
                                            mHolder.listdiscount.setText("");
                                            salesItemList.get(pos).setDiscount("");

                                        } else {
                                            mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
                                            mHolder.listdiscount.setText("");
                                        }


                                        //Set Array value for subtotal
                                        salesItemList.get(pos).setSubtotal(dft.format(Double.parseDouble(mHolder.listitemtotal.getText().toString())));
                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.darkblue));
                                        salesItemList.get(pos).setNewprice(mHolder.listitemrate.getText().toString());
                                    } else {
                                        //do your work here
                                        Double a = Double.parseDouble(mHolder.listitemqty.getText().toString());
                                        Double b = Double.parseDouble(mHolder.listitemrate.getText().toString());
                                        Double res = a * b;
                                        salesItemList.get(pos).setItemqty(mHolder.listitemqty.getText().toString());

                                        mHolder.listitemtotal.setText(dft.format(res));
                                        //Set Array value for subtotal
                                        salesItemList.get(pos).setSubtotal(dft.format(res));
                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.darkblue));
                                        salesItemList.get(pos).setNewprice(mHolder.listitemrate.getText().toString());
                                        mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
                                        mHolder.listdiscount.setText("");
                                    }
                                    addedqty = true;
                                    CalculateTotal();
                                } else {
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid quantity", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                }
                            } else {
                                mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
                                mHolder.listdiscount.setText("");
                                mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                salesItemList.get(pos).setItemqty(mHolder.listitemqty.getText().toString());
                                salesItemList.get(pos).setSubtotal(mHolder.listitemtotal.getText().toString());
                            }


                            if(addedqty) {
                                if(salesItemList.get(pos).getItemqty().equals("") ||
                                        salesItemList.get(pos).getItemqty().equals("0") ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter  quantity", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }
                                if(Double.parseDouble(salesItemList.get(pos).getItemqty())<=0 ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid quantity", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }
                                if(salesItemList.get(pos).getNewprice().equals("") ||
                                        salesItemList.get(pos).getNewprice().equals("0") ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter  price", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }
                                if(Double.parseDouble(salesItemList.get(pos).getNewprice())<=0 ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid price", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }
                                if(salesItemList.get(pos).getSubtotal().equals("") ||
                                        salesItemList.get(pos).getSubtotal().equals("0") ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter  total", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }
                                if(Double.parseDouble(salesItemList.get(pos).getSubtotal())<=0 ){
                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid total", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    return;
                                }

                                //Added to cart
                                boolean addedcart = false;
                                boolean addedpricecart = true;
                                boolean checkfreeitem = false;
                                DataBaseAdapter dataBaseAdapter = null;
                                Cursor getcartdatas = null;
                                String insertcart="";
                                try {
                                    //Cart Add Functionality
                                    dataBaseAdapter = new DataBaseAdapter(context);
                                    dataBaseAdapter.open();
                                    String getcartqty = dataBaseAdapter.GetFreeCartItemStock(salesitems.get(pos).getItemcode());
                                    if(Double.parseDouble(getcartqty) >0) {
                                        double getactualstock = Double.parseDouble(salesitems.get(pos).getStockqty()) - Double.parseDouble(getcartqty);
                                        if ( Double.parseDouble(salesitems.get(pos).getItemqty()) > getactualstock) {
                                            Toast toast = Toast.makeText(getApplicationContext(), "Insufficient stock...This item alredy added to cart", Toast.LENGTH_LONG);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.show();
                                            mHolder.listitemtotal.setText("0.00");
                                            mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                            mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                            salesItemList.get(pos).setItemqty("");
                                            salesItemList.get(pos).setSubtotal("0");
                                            return;
                                        }
                                    }
                                  // for (int i = 0; i < salesitems.size(); i++) {
                                    if(salesitems.size() >0) {
                                         int i = pos;
                                        if (!salesitems.get(i).getItemqty().equals("")
                                                && !salesitems.get(i).getItemqty().equals(null)
                                                && !salesitems.get(i).getNewprice().equals(null)
                                                && !salesitems.get(i).getNewprice().equals("")) {
                                            if (Double.parseDouble(salesitems.get(i).getItemqty()) > 0
                                                    && (Double.parseDouble(salesitems.get(i).getSubtotal())) > 0) {
                                                if (Double.parseDouble(salesitems.get(i).getNewprice()) > 0) {
                                                    double getsubtotal = Double.parseDouble(salesitems.get(i).getNewprice()) *
                                                            Double.parseDouble(salesitems.get(i).getItemqty());
                                                    if (!salesitems.get(i).getDiscount().equals("") && !salesitems.get(i).getDiscount().equals("0")
                                                            && !salesitems.get(i).getDiscount().equals(null)) {
                                                        getsubtotal = getsubtotal - Double.parseDouble(salesitems.get(i).getDiscount());
                                                    } else {
                                                        getsubtotal = getsubtotal;
                                                    }
                                                    salesitems.get(i).setSubtotal(String.valueOf(getsubtotal));
                                                    insertcart = dataBaseAdapter.insertSalesCart(String.valueOf(salesitems.get(i).getItemcode()), String.valueOf(salesitems.get(i).getCompanycode()),
                                                            String.valueOf(salesitems.get(i).getBrandcode()), String.valueOf(salesitems.get(i).getManualitemcode())
                                                            , String.valueOf(salesitems.get(i).getItemname()), String.valueOf(salesitems.get(i).getItemnametamil()),
                                                            String.valueOf(salesitems.get(i).getUnitcode()), String.valueOf(salesitems.get(i).getUnitweightunitcode())
                                                            , String.valueOf(salesitems.get(i).getUnitweight()), String.valueOf(salesitems.get(i).getUppunitcode())
                                                            , String.valueOf(salesitems.get(i).getUppweight()), String.valueOf(salesitems.get(i).getItemcategory()),
                                                            String.valueOf(salesitems.get(i).getParentitemcode()),
                                                            String.valueOf(salesitems.get(i).getAllowpriceedit()), String.valueOf(salesitems.get(i).getAllownegativestock())
                                                            , String.valueOf(salesitems.get(i).getAllowdiscount()),
                                                            String.valueOf(salesitems.get(i).getStockqty()), String.valueOf(salesitems.get(i).getUnitname()),
                                                            String.valueOf(salesitems.get(i).getNoofdecimals()),
                                                            String.valueOf(salesitems.get(i).getOldprice()),
                                                            String.valueOf(salesitems.get(i).getNewprice()), String.valueOf(salesitems.get(i).getColourcode()), String.valueOf(salesitems.get(i).getHsn()),
                                                            String.valueOf(salesitems.get(i).getTax()), String.valueOf(salesitems.get(i).getItemqty()), String.valueOf(getsubtotal)
                                                            , String.valueOf(salesitems.get(i).getRouteallowpricedit()), String.valueOf(salesitems.get(i).getDiscount()), "",
                                                            String.valueOf(salesitems.get(i).getPurchaseitemcode()), String.valueOf(salesitems.get(i).getFreeitemcode()));

                                                }
                                            }

                                        }
                                    }

                                   // }


                                    //Add free item to cart
                                    for (int k = 0; k < freeitems.size(); k++) {
                                        insertcart = dataBaseAdapter.insertFreeSalesCart(String.valueOf(freeitems.get(k).getItemcode()), String.valueOf(freeitems.get(k).getCompanycode()),
                                                String.valueOf(freeitems.get(k).getBrandcode()), String.valueOf(freeitems.get(k).getManualitemcode())
                                                , String.valueOf(freeitems.get(k).getItemname()),String.valueOf( freeitems.get(k).getItemnametamil()),
                                                String.valueOf(freeitems.get(k).getUnitcode()), String.valueOf(freeitems.get(k).getUnitweightunitcode())
                                                , String.valueOf(freeitems.get(k).getUnitweight()), String.valueOf(freeitems.get(k).getUppunitcode())
                                                , String.valueOf(freeitems.get(k).getUppweight()), String.valueOf(freeitems.get(k).getItemcategory()),
                                                String.valueOf(freeitems.get(k).getParentitemcode()),
                                                String.valueOf(freeitems.get(k).getAllowpriceedit()), String.valueOf(freeitems.get(k).getAllownegativestock())
                                                , String.valueOf(freeitems.get(k).getAllowdiscount()),
                                                String.valueOf(freeitems.get(k).getStockqty()), String.valueOf(freeitems.get(k).getUnitname()),
                                                String.valueOf(freeitems.get(k).getNoofdecimals()),
                                                String.valueOf(freeitems.get(k).getOldprice()),
                                                String.valueOf(freeitems.get(k).getNewprice()),String.valueOf(freeitems.get(k).getColourcode()), String.valueOf(freeitems.get(k).getHsn()),
                                                String.valueOf(freeitems.get(k).getTax()), String.valueOf(freeitems.get(k).getItemqty()), String.valueOf(freeitems.get(k).getSubtotal())
                                                , String.valueOf(freeitems.get(k).getRouteallowpricedit()), String.valueOf(freeitems.get(k).getDiscount()), String.valueOf(freeitems.get(k).getFreeflag()),
                                                String.valueOf(freeitems.get(k).getPurchaseitemcode()), String.valueOf(freeitems.get(k).getFreeitemcode()));

                                        checkfreeitem = true;
                                    }

                                    //Get cart datas from database temp table
                                     getcartdatas = dataBaseAdapter.GetSalesItemsCart();
                                    if(getcartdatas.getCount()>0) {
                                        staticreviewsalesitems.clear();
                                        for (int i = 0; i < getcartdatas.getCount(); i++) {
                                            staticreviewsalesitems.add(new SalesItemDetails(getcartdatas.getString(1), getcartdatas.getString(2),
                                                    getcartdatas.getString(3), getcartdatas.getString(4)
                                                    , getcartdatas.getString(5), getcartdatas.getString(6),
                                                    getcartdatas.getString(7), getcartdatas.getString(8)
                                                    , getcartdatas.getString(9),getcartdatas.getString(10)
                                                    , getcartdatas.getString(11), getcartdatas.getString(12), getcartdatas.getString(13),
                                                    getcartdatas.getString(14), getcartdatas.getString(15)
                                                    , getcartdatas.getString(16),
                                                    getcartdatas.getString(17), getcartdatas.getString(18),
                                                    getcartdatas.getString(19), getcartdatas.getString(20),
                                                    getcartdatas.getString(21), getcartdatas.getString(22), getcartdatas.getString(23),
                                                    getcartdatas.getString(24), getcartdatas.getString(25), getcartdatas.getString(26)
                                                    , getcartdatas.getString(27), getcartdatas.getString(28), getcartdatas.getString(29),
                                                    getcartdatas.getString(30), getcartdatas.getString(31) ,getcartdatas.getString(21),"",""));
                                            getcartdatas.moveToNext();
                                        }
                                    }



                                } catch (Exception e) {
                                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                    mDbErrHelper.open();
                                    String geterrror = e.toString();
                                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                    mDbErrHelper.close();
                                } finally {
                                    if (dataBaseAdapter != null)
                                        dataBaseAdapter.close();
                                    if (getcartdatas != null)
                                        getcartdatas.close();
                                }

                                if (checkfreeitem) {
                                    freeitems.clear();
                                }
                                //Collections.sort(staticreviewsalesitems, new SalesItemDetails.SortbyPurchaseItemDesc());
                                totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));
                            }
                        } else {
                            final int pos = (Integer) mHolder.listitemqty.getTag();
                            mHolder.listdiscount.setBackgroundColor(getResources().getColor(R.color.lightbiscuit));
                            mHolder.listdiscount.setText("");
                            isparentopen = "";
                            //mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.white));
                            mHolder.listitemtotal.setText("0.00");
                            mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                            mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                            salesItemList.get(pos).setNewprice(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                            salesItemList.get(pos).setItemqty(mHolder.listitemqty.getText().toString());
                            salesItemList.get(pos).setSubtotal(mHolder.listitemtotal.getText().toString());
                            Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid quantity", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            String getitemcode = salesItemList.get(position).getItemcode();
                            DataBaseAdapter objdatabaseadapter = null;
                            Cursor getcartdatas = null;
                            try {
                                //Order item details
                                objdatabaseadapter = new DataBaseAdapter(context);
                                objdatabaseadapter.open();
                                String getresult = objdatabaseadapter.DeleteItemInCart(getitemcode);
                                if(getresult.equals("Success")){

                                    //Get cart datas from database temp table
                                    getcartdatas = objdatabaseadapter.GetSalesItemsCart();
                                    SalesActivity.staticreviewsalesitems.clear();
                                    if(getcartdatas.getCount()>0) {

                                        for (int i = 0; i < getcartdatas.getCount(); i++) {
                                            SalesActivity.staticreviewsalesitems.add(new SalesItemDetails(getcartdatas.getString(1), getcartdatas.getString(2),
                                                    getcartdatas.getString(3), getcartdatas.getString(4)
                                                    , getcartdatas.getString(5), getcartdatas.getString(6),
                                                    getcartdatas.getString(7), getcartdatas.getString(8)
                                                    , getcartdatas.getString(9),getcartdatas.getString(10)
                                                    , getcartdatas.getString(11), getcartdatas.getString(12), getcartdatas.getString(13),
                                                    getcartdatas.getString(14), getcartdatas.getString(15)
                                                    , getcartdatas.getString(16),
                                                    getcartdatas.getString(17), getcartdatas.getString(18),
                                                    getcartdatas.getString(19), getcartdatas.getString(20),
                                                    getcartdatas.getString(21), getcartdatas.getString(22), getcartdatas.getString(23),
                                                    getcartdatas.getString(24), getcartdatas.getString(25), getcartdatas.getString(26)
                                                    , getcartdatas.getString(27), getcartdatas.getString(28), getcartdatas.getString(29),
                                                    getcartdatas.getString(30), getcartdatas.getString(31),getcartdatas.getString(21),"","" ));
                                            getcartdatas.moveToNext();
                                        }
                                    }
                                }
                                totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));


                            } catch (Exception e) {
                                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                mDbErrHelper.open();
                                String geterrror = e.toString();
                                mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                mDbErrHelper.close();
                            } finally {
                                if(objdatabaseadapter!=null)
                                    objdatabaseadapter.close();
                                if(getcartdatas!=null)
                                    getcartdatas.close();
                            }
                            return;
                        }


               // }
                }
            });

            mHolder.listitemname.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean checkchilditem = false;
                    if(isnillstockconversion) {
                        if (salesItemList.get(position).getAllownegativestock().equals("no")) {
                            if (salesItemList.get(position).getItemcategory().equals("child")) {
                                final int pos = (Integer) mHolder.listitemqty.getTag();
                                double getparentstock = 0.0;
                                DataBaseAdapter objdatabaseadapter = null;
                                Cursor getStockCur = null;
                                try {
                                    //Get Stock for parent item
                                    objdatabaseadapter = new DataBaseAdapter(context);
                                    objdatabaseadapter.open();
                                    getStockCur = objdatabaseadapter.GetStockForItem(salesItemList.get(pos).getParentitemcode());
                                    if (getStockCur.getCount() > 0) {
                                        // for (int i = 0; i < getStockCur.getCount(); i++) {
                                        getparentstock = getStockCur.getDouble(0);
                                        //}
                                    }
                                    if (getparentstock > 0) {
                                        isfreestock = "";
                                        getstaticparentitemcode = salesItemList.get(pos).getParentitemcode();
                                        getstaticchilditemname = salesItemList.get(pos).getItemnametamil();
                                        getstaticchildunitname = salesItemList.get(pos).getUnitname();
                                        checkchilditem = true;

                                        mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.yellow));
                                        mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                    } else {
                                        checkchilditem=false;
                                    }
                                } catch (Exception e) {
                                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                    mDbErrHelper.open();
                                    String geterrror = e.toString();
                                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                    mDbErrHelper.close();
                                } finally {
                                    if (objdatabaseadapter != null)
                                        objdatabaseadapter.close();
                                    if (getStockCur != null)
                                        getStockCur.close();
                                }

                            }
                        }
                        if (checkchilditem) {
                            double getminqty = 0;
                            double getdiscount = 0;
                            double getparentstock = 0;

                            final int pos = (Integer) mHolder.listitemqty.getTag();
                            DataBaseAdapter objdatabaseadapter = null;
                            Cursor getStockCur = null;
                            try {
                                //Get Stock for parent item
                                objdatabaseadapter = new DataBaseAdapter(context);
                                objdatabaseadapter.open();
                                getStockCur = objdatabaseadapter.GetStockForItem(salesItemList.get(pos).getParentitemcode());
                                if (getStockCur.getCount() > 0) {
                                    for (int i = 0; i < getStockCur.getCount(); i++) {
                                        getparentstock = getStockCur.getDouble(0);
                                    }
                                }
                                if (getparentstock > 0) {
                                    isfreestock = "";
                                    getstaticparentitemcode = salesItemList.get(pos).getParentitemcode();
                                    getstaticchilditemname = salesItemList.get(pos).getItemnametamil();
                                    getstaticchildunitname = salesItemList.get(pos).getUnitname();
                                    isparentopen = "yes";
                                    mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.yellow));
                                   // mHolder.listitemqty.setText("");
                                } else {
                                    //mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.white));
                                    Toast toast = Toast.makeText(getApplicationContext(), "Insufficient stock..", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    mHolder.listitemtotal.setText("0.00");
                                    mHolder.listitemtotal.setBackground(ContextCompat.getDrawable(context, R.color.colorPrimaryDark));
                                    mHolder.listitemrate.setText(dft.format(Double.parseDouble(salesItemList.get(pos).getDumyprice())));
                                    //Toast.makeText(getApplicationContext(), "Insufficient stock..", Toast.LENGTH_SHORT).show();
                                    //mHolder.listitemqty.setText("");
                                    String getresult=DeleteItemCart(salesItemList.get(pos).getItemcode());
                                    if(getresult.equals("Success")) {
                                        salesItemList.get(pos).setItemqty("");
                                        salesItemList.get(pos).setNewprice("");
                                    }
                                }
                            } catch (Exception e) {
                                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                mDbErrHelper.open();
                                String geterrror = e.toString();
                                mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                mDbErrHelper.close();
                            } finally {
                                if (objdatabaseadapter != null)
                                    objdatabaseadapter.close();
                                if (getStockCur != null)
                                    getStockCur.close();
                            }
                        }
                    }
                    if(isparentopen.equals("yes"))
                    {
                        double getparentstock = 0;
                        String getparentitemname = "";
                        String getunitname = "";
                        String getupp = "";
                        final int pos = (Integer) mHolder.listitemqty.getTag();
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        DataBaseAdapter objdatabaseadapter = null;
                        Cursor getStockCur = null;
                        try {
                            //Get Stock for parent item
                            objdatabaseadapter = new DataBaseAdapter(context);
                            objdatabaseadapter.open();
                            getStockCur = objdatabaseadapter.GetStockForItem(getstaticparentitemcode);
                            String getcartqty = objdatabaseadapter.GetCartItemStock(salesItemList.get(pos).getParentitemcode());
                            if (getStockCur.getCount() > 0) {
                                for (int i = 0; i < getStockCur.getCount(); i++) {
                                    getparentstock = getStockCur.getDouble(0);
                                    getparentitemname = getStockCur.getString(1);
                                    getunitname = getStockCur.getString(2);
                                    getupp = getStockCur.getString(3);
                                }
                                getparentstock = getparentstock - (Double.parseDouble(getcartqty));
                            }

                        } catch (Exception e) {
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        } finally {
                            if (objdatabaseadapter != null)
                                objdatabaseadapter.close();
                            if (getStockCur != null)
                                getStockCur.close();
                        }
                        final String finalGetparentitemname = getparentitemname;
                        final int finalGetparentstock = (int) getparentstock;
                        final String finalGetunitname = getunitname;
                        final String finalGetupp = getupp;
                        final String getparentcode = getstaticparentitemcode;

                    /*    builder.setMessage("Do you want to convert stock?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(final DialogInterface dialog, int id) {*/
                                        //dialog.dismiss();
                                        stockconvertdialog = new Dialog(context);
                                        stockconvertdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        stockconvertdialog.setContentView(R.layout.stockconversion);
                                        stockconvertdialog.setCanceledOnTouchOutside(false);
                                        ImageView closepopup = (ImageView) stockconvertdialog.findViewById(R.id.closepopup);
                                        closepopup.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                               // isparentopen = "";
                                               // mHolder.listitemname.setBackgroundColor(getResources().getColor(R.color.white));
                                                stockconvertdialog.dismiss();
                                                isparentopen ="";
                                                isnillstockconversion =true;
                                                mHolder.listitemqty.setText("");
                                            }
                                        });
                                        final TextView txtparentitem = (TextView) stockconvertdialog.findViewById(R.id.txtparentitem);
                                        final TextView txtparentstock = (TextView) stockconvertdialog.findViewById(R.id.txtparentstock);
                                        final TextView txtparentunit = (TextView) stockconvertdialog.findViewById(R.id.txtparentunit);
                                        final EditText txtparentqty = (EditText) stockconvertdialog.findViewById(R.id.txtparentqty);
                                        final TextView txtchilditem = (TextView) stockconvertdialog.findViewById(R.id.txtchilditem);
                                        final TextView txtchildqty = (TextView) stockconvertdialog.findViewById(R.id.txtchildqty);
                                        final TextView txtchildconvertunit = (TextView)stockconvertdialog.findViewById(R.id.txtchildconvertunit);
                                        final TextView txtparentconvertunit = (TextView)stockconvertdialog.findViewById(R.id.txtparentconvertunit) ;

                                        txtparentitem.setText(finalGetparentitemname);
                                        txtparentstock.setText(String.valueOf(finalGetparentstock));
                                        txtparentunit.setText(finalGetunitname);
                                        txtparentconvertunit.setText(finalGetunitname);
                                        if(finalGetparentstock >= 1 ){
                                            txtparentqty.setText(String.valueOf("1"));
                                        }else{
                                            txtparentqty.setText(String.valueOf(finalGetparentstock));
                                        }


                                        if (finalGetupp.equals("0") || finalGetupp.equals("")) {
                                            txtchildqty.setText(String.valueOf(finalGetparentstock));
                                        } else {
                                            if(finalGetparentstock >= 1 ){
                                                double getcompleteqty = 1 * Double.parseDouble(finalGetupp);
                                                txtchildqty.setText(String.valueOf(getcompleteqty));
                                            }else{
                                                double getcompleteqty = finalGetparentstock * Double.parseDouble(finalGetupp);
                                                txtchildqty.setText(String.valueOf(getcompleteqty));
                                            }

                                        }
                                        /***********PARENT QTY TEXT CHANGE LISTENER******/
                                        txtparentqty.addTextChangedListener(new TextWatcher() {

                                            @Override
                                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                                // TODO Auto-generated method stub
                                            }

                                            @Override
                                            public void beforeTextChanged(CharSequence s, int start, int count,
                                                                          int after) {
                                                // TODO Auto-generated method stub
                                            }

                                            @Override
                                            public void afterTextChanged(Editable s) {
                                                // TODO Auto-generated method stub
                                                if (!txtparentqty.getText().toString().equals("")) {
                                                    if (finalGetparentstock >= Double.parseDouble(txtparentqty.getText().toString())) {
                                                        if (finalGetupp.equals("0") || finalGetupp.equals("")) {
                                                            txtchildqty.setText(String.valueOf(txtparentqty.getText().toString()));
                                                        } else {
                                                            double getcompleteqty = Double.parseDouble(txtparentqty.getText().toString()) * Double.parseDouble(finalGetupp);
                                                            txtchildqty.setText(String.valueOf(getcompleteqty).toString());
                                                        }
                                                    } else {
                                                        txtchildqty.setText("0");
                                                        Toast toast = Toast.makeText(getApplicationContext(),"Stock exceed with parent qty", Toast.LENGTH_LONG);
                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                        toast.show();
                                                        //Toast.makeText(getApplicationContext(), "Stock exceed with parent qty", Toast.LENGTH_SHORT).show();
                                                    }

                                                }else{
                                                    txtchildqty.setText("");
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid qty", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please enter valid qty", Toast.LENGTH_SHORT).show();
                                                }


                                            }
                                        });
                                        /***********END PARENT QTY TEXT CHANGE LISTENER******/

                                        txtchilditem.setText(getstaticchilditemname);
                                        txtchildconvertunit.setText(getstaticchildunitname);

                                        Button btnConversion = (Button) stockconvertdialog.findViewById(R.id.btnConversion);
                                        btnConversion.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                if (txtparentitem.getText().toString().equals("")
                                                        || txtparentitem.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please select parent item", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please select parent item", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (txtparentstock.getText().toString().equals("")
                                                        || txtparentstock.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter parent stock", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please enter parent stock", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (txtparentunit.getText().toString().equals("")
                                                        || txtparentunit.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter parent unit", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please enter parent unit", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (txtparentqty.getText().toString().equals("")
                                                        || txtparentqty.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please select parent qty", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please select parent qty", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (txtchilditem.getText().toString().equals("")
                                                        || txtchilditem.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please select child item", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                   // Toast.makeText(getApplicationContext(), "Please select child item", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (txtchildqty.getText().toString().equals("")
                                                        || txtchildqty.getText().toString().equals(null)) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter child qty", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please enter child qty", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                if (Double.parseDouble(txtchildqty.getText().toString())<=0) {
                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid child qty", Toast.LENGTH_LONG);
                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                    toast.show();
                                                    //Toast.makeText(getApplicationContext(), "Please enter child qty", Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                String getchilditemcode = salesItemList.get(pos).getItemcode();
                                                DataBaseAdapter stockobjdatabaseadapter = null;
                                                String insertstock = null;
                                                try {
                                                    //Stock Conversion Functionality
                                                    stockobjdatabaseadapter = new DataBaseAdapter(context);
                                                    stockobjdatabaseadapter.open();
                                                    String getitemstockcode= "";
                                                    if(isfreestock.equals("yes")){
                                                        getitemstockcode = getstaticchildcode;
                                                    }else{
                                                        getitemstockcode =  getchilditemcode;
                                                    }
                                                    insertstock = stockobjdatabaseadapter.insertStockConversion(getparentcode, txtchildqty.getText().toString(),
                                                            txtparentqty.getText().toString(),getitemstockcode, MenuActivity.getschedulecode);
                                                    if (insertstock.equals("success")) {
                                                        getstaticchilditemcode = salesItemList.get(pos).getItemcode();
                                                        getstaticgetchildqty = mHolder.listitemqty.getText().toString();
                                                        Toast toast = Toast.makeText(getApplicationContext(),"Stock converted successfully", Toast.LENGTH_LONG);
                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                        toast.show();
                                                       // Toast.makeText(getApplicationContext(), "Saved successfully", Toast.LENGTH_SHORT).show();
                                                        stockconvertdialog.dismiss();

                                                        //dialog.dismiss();
                                                        isfreestock = "";
                                                        getitemsfromcode = getstaticsubcode;


                                                        GetItems(getstaticsubcode);

                                                    }

                                                } catch (Exception e) {
                                                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                                    mDbErrHelper.open();
                                                    String geterrror = e.toString();
                                                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                    mDbErrHelper.close();
                                                } finally {
                                                    if (stockobjdatabaseadapter != null)
                                                        stockobjdatabaseadapter.close();
                                                }

                                            }
                                        });
                                        stockconvertdialog.show();
                                    //}
                                //})
                                /*.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                        mHolder.listitemqty.setText("");
                                        *//*Toast toast = Toast.makeText(getApplicationContext(),"Insufficient stock..", Toast.LENGTH_LONG);
                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                        toast.show();*//*
                                        //Toast.makeText(getApplicationContext(), "Insufficient stock..", Toast.LENGTH_SHORT).show();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();*/
                    }
                }
            });

            mHolder.listitemqty.setTag(position);
            mHolder.listitemrate.setTag(position);
            return convertView;
        }

        private class ViewHolder1 {
            private TextView listitemname,schemecount,dummycount;
            private TextView listitemcode,labelnilstock;
            private EditText listitemqty;
            private EditText listitemrate;
            private TextView listitemtotal,listitemtax,labelstock,labelhsntax,labelstockunit,listdiscount;
            private LinearLayout itemLL,stockvalueLL;
            private  ImageView pricearrow;

        }
    }

    public  String DeleteItemCart(String getitemcode){

        DataBaseAdapter objdatabaseadapter = null;
        Cursor getcartdatas = null;
        String getresult ="";
        try {
            //Order item details
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            getresult = objdatabaseadapter.DeleteItemInCart(getitemcode);
            if (getresult.equals("Success")) {
                getcartdatas = objdatabaseadapter.GetSalesItemsCart();
                if(getcartdatas.getCount()>0){
                    totalcartitems.setText(String.valueOf(getcartdatas.getCount()));
                }else{
                    totalcartitems.setText(String.valueOf("0"));
                }

            }
        } catch (Exception e) {
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        } finally {
            if (objdatabaseadapter != null)
                objdatabaseadapter.close();
            if (getcartdatas != null)
                getcartdatas.close();

        }
        return getresult;
    }

    public void CalculateTotal() {
        try{
        final DecimalFormat dft = new DecimalFormat("0.00");
        double res1 = 0;
        double res2 = 0;
        for (int i = 0; i < salesitems.size(); i++) {
            String saleseqty = salesitems.get(i).getItemqty();
            String salessubtotal = salesitems.get(i).getSubtotal();
            String getsaleseqty;
            if (saleseqty.equals("")) {
                getsaleseqty = "0";
            } else {
                getsaleseqty = saleseqty;
            }
            String getsalessubtotal;
            if (salessubtotal.equals("")) {
                getsalessubtotal = "0";
            } else {
                getsalessubtotal = salessubtotal;
            }

            res1 = res1 + Double.parseDouble(getsalessubtotal);
            res2 = res2 + Double.parseDouble(getsaleseqty);
        }
        billisttotalamount.setText(dft.format(res1));
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }
    }


    /************BASE ADAPTER*************/
    //City Adapter
    public class CityAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        CityAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return citycode.length;
        }

        @Override
        public Object getItem(int position) {
            return citycode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.citypopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listcityname = (TextView) convertView.findViewById(R.id.listcityname);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(String.valueOf(citynametamil[position]).equals("") || String.valueOf(citynametamil[position]).equals("null") ||
                        String.valueOf(citynametamil[position]).equals(null)) {
                    mHolder.listcityname.setText(String.valueOf(cityname[position]));
                }else{
                    mHolder.listcityname.setText(String.valueOf(citynametamil[position]));
                }
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(String.valueOf(citynametamil[position]).equals("") || String.valueOf(citynametamil[position]).equals("null") ||
                            String.valueOf(citynametamil[position]).equals(null)) {
                        txtcityname.setText(String.valueOf(cityname[position]));
                    }else{
                        txtcityname.setText(String.valueOf(citynametamil[position]));
                    }
                    getcitycode = citycode[position];
                    txtarea.setText("");
                    getareacode="0";
                    txtarea.setHint("Area");
                    citydialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listcityname;

        }

    }
    //Area Adapter
    public class AreaAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        AreaAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return areacode.length;
        }

        @Override
        public Object getItem(int position) {
            return areacode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.areapopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listareaname = (TextView) convertView.findViewById(R.id.listareaname);
                    mHolder.listcustomercount = (TextView)convertView.findViewById(R.id.listcustomercount);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(!String.valueOf(areanametamil[position]).equals("")
                        && !String.valueOf(areanametamil[position]).equals("null")
                        && !String.valueOf(areanametamil[position]).equals(null)) {
                    mHolder.listareaname.setText(String.valueOf(areanametamil[position]));
                }else{
                    mHolder.listareaname.setText(String.valueOf(areaname[position]));
                }
                mHolder.listcustomercount.setText(String.valueOf(customercount[position]));

                int getcount = 0;
                for(int i = 0;i<areacode.length;i++){
                    if(!areacode[i].equals("0")){
                        getcount = getcount + Integer.parseInt(customercount[i]);
                    }
                }

                if(areacode[position].equals("0")){
                    mHolder.listcustomercount.setText(String.valueOf(getcount));
                }
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!String.valueOf(areanametamil[position]).equals("")
                            && !String.valueOf(areanametamil[position]).equals("null")
                            && !String.valueOf(areanametamil[position]).equals(null)) {
                        txtarea.setText(String.valueOf(areanametamil[position]));
                    }else{
                        txtarea.setText(String.valueOf(areaname[position]));
                    }
                    getareacode = areacode[position];

                    areadialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listareaname,listcustomercount;

        }

    }
    //Area Adapter
    public class SalesAreaAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        SalesAreaAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return AreaCode.length;
        }

        @Override
        public Object getItem(int position) {
            return AreaCode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.areapopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listareaname = (TextView) convertView.findViewById(R.id.listareaname);
                    mHolder.listcustomercount = (TextView)convertView.findViewById(R.id.listcustomercount);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                mHolder.listareaname.setText(String.valueOf(AreaName[position] +" - "+CityName[position]));

                mHolder.listcustomercount.setText(String.valueOf(CustomerCount[position]));


                int getcount = 0;
                for(int i = 0;i<AreaCode.length;i++){
                    if(!AreaCode[i].equals("0")){
                        getcount = getcount + Integer.parseInt(CustomerCount[i]);
                    }
                }
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    txtareaname.setText(String.valueOf(AreaName[position] +" - "+CityName[position]));
                    LoginActivity.getareaname = String.valueOf(AreaName[position] +" - "+CityName[position]);
                    LoginActivity.getareacode = String.valueOf(AreaCode[position]);
                    radio_credit.setEnabled(true);
                    radio_cash.setEnabled(true);
                    radio_cash.setChecked(true);
                    if(staticreviewsalesitems.size() > 0 ){
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Confirmation");
                        builder.setMessage("Are you sure you want to clear cart?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        txtcustomername.setText("");
                                        customercode = "0";
                                        gstnnumber = "";
                                        getschemeapplicable = "";
                                        togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                                        togglegstin.setText("GSTIN \n ");
                                        togglegstin.setTextOn("GSTIN \n ");
                                        togglegstin.setTextOff("GSTIN \n ");
                                        txtcustomername.setHint("Customer Name");
                                        staticreviewsalesitems.clear();
                                        //Set total cart item value
                                        totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));
                                        salesitems.clear();
                                        DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                                        objdatabaseadapter.open();
                                        objdatabaseadapter.DeleteSalesItemCart();
                                        objdatabaseadapter.close();
                                        SalesItemAdapter adapter = new SalesItemAdapter(context,salesitems);
                                        lv_sales_items.setAdapter(adapter);
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();

                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }else{
                        txtcustomername.setText("");
                        customercode = "0";
                        gstnnumber = "";
                        getschemeapplicable = "";
                        togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                        togglegstin.setText("GSTIN \n ");
                        togglegstin.setTextOn("GSTIN \n ");
                        togglegstin.setTextOff("GSTIN \n ");
                        txtcustomername.setHint("Customer Name");
                        togglegstin.setText("GSTIN \n "+gstnnumber);
                        togglegstin.setTextOn("GSTIN \n "+gstnnumber);
                        togglegstin.setTextOff("GSTIN \n "+gstnnumber);
                        salesitems.clear();
                        SalesItemAdapter adapter = new SalesItemAdapter(context,salesitems);
                        lv_sales_items.setAdapter(adapter);

                    }

                    areadialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listareaname,listcustomercount;

        }

    }
    //Customer Adapter
    public class SalesCustomerAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        SalesCustomerAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return CustomerCode.length;
        }

        @Override
        public Object getItem(int position) {
            return CustomerCode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.customerpopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listcustomername = (TextView) convertView.findViewById(R.id.listcustomername);
                    mHolder.listgstin = (TextView)convertView.findViewById(R.id.listgstin);
                } catch (Exception e) {
                    Log.i("Customer", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                mHolder.listcustomername.setText(String.valueOf(CustomerNameTamil[position]));

                if(GSTN[position].equals("") || GSTN[position].equals("null") ||GSTN[position].equals(null)){
                    mHolder.listgstin.setVisibility(View.GONE);
                }else{
                    mHolder.listgstin.setVisibility(View.VISIBLE);
                }
            } catch (Exception e) {
                Log.i("Customer", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    txtcustomername.setText(String.valueOf(CustomerNameTamil[position]));
                    customercode = CustomerCode[position];
                    gstnnumber = GSTN[position];
                    getschemeapplicable = SchemeApplicable[position];
                    if(gstnnumber.equals("")||gstnnumber.equals(null)||gstnnumber.equals("0")){
                        togglegstin.setBackgroundColor(getResources().getColor(R.color.graycolor));
                    }else{
                        togglegstin.setBackgroundColor(getResources().getColor(R.color.green));
                    }
                    if(customertypecode[position].equals("1")){
                        radio_cash.setChecked(true);
                        radio_credit.setEnabled(false);
                        radio_cash.setEnabled(false);
                    }
                    if(customertypecode[position].equals("2")){
                        radio_credit.setEnabled(true);
                        radio_cash.setEnabled(true);
                        radio_cash.setChecked(true);
                    }


                    togglegstin.setText("GSTIN \n "+gstnnumber);
                    togglegstin.setTextOn("GSTIN \n "+gstnnumber);
                    togglegstin.setTextOff("GSTIN \n "+gstnnumber);
                    salesitems.clear();
                    SalesItemAdapter adapter = new SalesItemAdapter(context,salesitems);
                    lv_sales_items.setAdapter(adapter);
                    if(staticreviewsalesitems.size() > 0 ){
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Confirmation");
                        builder.setMessage("Are you sure you want to clear cart?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        staticreviewsalesitems.clear();
                                        //Set total cart item value
                                        totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));
                                        salesitems.clear();
                                        DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
                                        objdatabaseadapter.open();
                                        objdatabaseadapter.DeleteSalesItemCart();
                                        objdatabaseadapter.close();
                                        SalesItemAdapter adapter = new SalesItemAdapter(context,salesitems);
                                        lv_sales_items.setAdapter(adapter);
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();

                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                    customerdialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listcustomername,listgstin;

        }

    }
    //Subgroup Adapter
    public class SalesSubGroupAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;
        SalesSubGroupAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return SubGroupCode.length;
        }

        @Override
        public Object getItem(int position) {
            return SubGroupCode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.subgrouppopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listsubgroup = (TextView) convertView.findViewById(R.id.listsubgroup);
                } catch (Exception e) {
                    Log.i("Customer", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                mHolder.listsubgroup.setText(String.valueOf(SubGroupNameTamil[position]));
            } catch (Exception e) {
                Log.i("Customer", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getstaticsubcode = SubGroupCode[position];
                    getitemsfromcode = SubGroupCode[position];
                    GetItems(SubGroupCode[position]);
                    window.dismiss();
                    fabgroupitem.startAnimation(rotate_backward);
                    isFabOpen = false;
                    isopenpopup = false;
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listsubgroup;

        }

    }


    //EXPENDABLE ADAPTER

    public class ExpandableAdapter extends BaseExpandableListAdapter {

        Context ctx;
        private List<String> listDataheader;
        private HashMap<String,List<String>> listHashMap;
        SalesActivity objsales = new SalesActivity();
        //public static ArrayList<ArrayList<String>> childList;
        //private String[] parents;
        public ExpandableAdapter(Context ctx, List<String> listDataheader, HashMap<String, List<String>> listHashMap) {
            this.ctx = ctx;
            this.listDataheader = listDataheader;
            this.listHashMap = listHashMap;
        }

        @Override
        public int getGroupCount() {
            return listDataheader.size();
        }

        @Override
        public int getChildrenCount(int i) {
            return listHashMap.get(listDataheader.get(i)).size();
        }

        @Override
        public Object getGroup(int i) {
            return listDataheader.get(i);
        }

        @Override
        public Object getChild(int i, int j) {
            return listHashMap.get(listDataheader.get(i)).get(j);
        }

        @Override
        public long getGroupId(int i) {
            return i;
        }

        @Override
        public long getChildId(int i, int j) {
            return j;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }

        @Override
        public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
            String headertitle = (String)getGroup(i);
            if(view == null){
                LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.parent_layout, null);

            }

            TextView parent_textvew = (TextView) view.findViewById(R.id.parent_txt);
            parent_textvew.setText(headertitle);
            return  view;
        }

        @Override
        public View getChildView(int i, int j, boolean b, View view, ViewGroup viewGroup) {
            String getsubgroupcode="";
            final String childtext = (String)getChild(i,j);
            if(view == null){
                LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.child_layout, null);
            }

            TextView child_textvew = (TextView) view.findViewById(R.id.child_txt);
            getsubgroupcode =  childtext.split("-")[1];
            child_textvew.setText(childtext.split("-")[0]);

            final String finalGetsubgroupcode = getsubgroupcode;
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getstaticsubcode = finalGetsubgroupcode;
                    getitemsfromcode = finalGetsubgroupcode;
                    GetItems(finalGetsubgroupcode);
                    window.dismiss();
                    fabgroupitem.startAnimation(rotate_backward);
                    isFabOpen = false;
                    isopenpopup = false;
                }
            });
            return  view;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return false;
        }
    }
    /************END BASE ADAPTER*********/

    protected  class AsyncCustomerDetails extends
            AsyncTask<String, JSONObject, ArrayList<CustomerDatas>> {
        ArrayList<CustomerDatas> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<CustomerDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetCustomerDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("customercode", mCur2.getString(1));
                        obj.put("refno", mCur2.getString(2));
                        obj.put("customername", mCur2.getString(3));
                        obj.put("customernametamil", mCur2.getString(4));
                        obj.put("address", mCur2.getString(5));
                        obj.put("areacode", mCur2.getString(6));
                        obj.put("emailid", mCur2.getString(7));
                        obj.put("mobileno", mCur2.getString(8));
                        obj.put("telephoneno", mCur2.getString(9));
                        obj.put("aadharno", mCur2.getString(10));
                        obj.put("gstin", mCur2.getString(11));
                        obj.put("status", mCur2.getString(12));
                        obj.put("makerid", mCur2.getString(13));
                        obj.put("createddate", mCur2.getString(14));
                        obj.put("updateddate", mCur2.getString(15));
                        obj.put("latitude", mCur2.getString(16));
                        obj.put("longitude", mCur2.getString(17));
                        obj.put("flag", mCur2.getString(18));
                        obj.put("schemeapplicable", mCur2.getString(19));
                        obj.put("uploaddocument", mCur2.getString(20));
                        obj.put("business_type", mCur2.getString(23));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.CustomerDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseCustomerDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("Customer", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<CustomerDatas> result) {
            // TODO Auto-generated method stub
            if (result.size() >= 1) {
                if(result.get(0).CustomerCode.length>0){
                    for(int j=0;j<result.get(0).CustomerCode.length;j++){
                        DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                        dataBaseAdapter.open();
                        dataBaseAdapter.UpdateCustomerFlag(result.get(0).CustomerCode[j]);
                        dataBaseAdapter.close();
                    }
                }

            }

        }
    }

    public void goBack(View v) {
        if(salesitems.size() > 0) {
            for (int i = 0; i < lv_sales_items.getChildCount(); i++) {
                View listRow = lv_sales_items.getChildAt(i);
                EditText getlistqty = (EditText) listRow.findViewById(R.id.listitemqty);
                TextView getlisttotal = (TextView) listRow.findViewById(R.id.listitemtotal);
                String getitemlistqty = getlistqty.getText().toString();
                String getitemlisttotal = getlisttotal.getText().toString();
                if (!getitemlistqty.equals("") && !getitemlistqty.equals(null)) {
                    if (Double.parseDouble(getitemlistqty) > 0 && Double.parseDouble(getitemlisttotal) <= 0.0) {
                        getlistqty.requestFocus();
                        Toast toast = Toast.makeText(getApplicationContext(), "Please enter valid total amount", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        return;
                    }
                }
            }
        }
        if(staticreviewsalesitems.size() > 0 ){
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Confirmation");
            builder.setMessage("Are you sure you want to clear cart?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            staticreviewsalesitems.clear();
                            //Set total cart item value
                            totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));
                            salesitems.clear();
                            gstnnumber="";

                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.DeleteSalesItemCart();
                            dataBaseAdapter.close();

                            Intent i = new Intent(context, SalesListActivity.class);
                            startActivity(i);
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();

                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }else{
            staticreviewsalesitems.clear();
            //Set total cart item value
            totalcartitems.setText(String.valueOf(staticreviewsalesitems.size()));
            salesitems.clear();
            gstnnumber="";

            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
            dataBaseAdapter.open();
            dataBaseAdapter.DeleteSalesItemCart();
            dataBaseAdapter.close();

            Intent i = new Intent(context, SalesListActivity.class);
            startActivity(i);
        }

    }
    @Override
    public void onBackPressed() {
        goBack(null);
    }



}
