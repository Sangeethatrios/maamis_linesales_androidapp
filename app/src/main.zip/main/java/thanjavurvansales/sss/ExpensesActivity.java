package thanjavurvansales.sss;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ExpensesActivity extends AppCompatActivity {
    public static SwipeMenuListView listView;
    TextView expenseslistdate;
    public static TextView expensestotalamt,expensesremainingamt,expensestripadvance;
    public static String getexpenselistdate ;
    private int year, month, day;
    private Calendar calendar;
    ImageView addexpenses;
    Dialog dialog;
    ArrayList<ExpensesDetails> expenseslist = new ArrayList<ExpensesDetails>();
    ArrayList<ExpensesDetails> getdata;
    public Context context;
    ImageView goback,expenselogout;
    TextView txtexpenseshead,txtamount,txtremarks;
    String[] expenseheadcode,expenseheadname,expenseheadnametamil;
    DecimalFormat dft = new DecimalFormat("0.00");
    Dialog expensedialog;
    ListView lv_expenseheadlist;
    String getexpenseheadcode="";
    Button btnSaveExpenses;
    ExpensesListBaseAdapter adapter=null;
    boolean networkstate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expenses);

        context = this;

        listView = (SwipeMenuListView) findViewById(R.id.expenseslistView);
        addexpenses = (ImageView)findViewById(R.id.addexpenses);
        expenseslistdate = (TextView)findViewById(R.id.expenseslistdate);
        expensestotalamt = (TextView)findViewById(R.id.expensestotalamt);
        expensesremainingamt = (TextView)findViewById(R.id.expensesremainingamt);
        expensestripadvance = (TextView)findViewById(R.id.expensestripadvance);
        goback = (ImageView)findViewById(R.id.goback);
        expenselogout = (ImageView)findViewById(R.id.expenselogout);

        expensestripadvance.setText("0");

        //Get Current date
        DataBaseAdapter objdatabaseadapter = null;
        Cursor getschedulelist=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            LoginActivity.getformatdate = objdatabaseadapter.GenCreatedDate();
            LoginActivity.getcurrentdatetime = objdatabaseadapter.GenCurrentCreatedDate();
            getschedulelist = objdatabaseadapter.GetScheduleDB();
            if(getschedulelist.getCount() >0){
                for(int i=0;i<getschedulelist.getCount();i++) {
                    MenuActivity.getschedulecode = getschedulelist.getString(0);
                }
            }else{
                MenuActivity.getschedulecode = "";
            }
            MenuActivity.getdenominationcount = objdatabaseadapter.GetDenominationCount(MenuActivity.getschedulecode);
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (objdatabaseadapter != null)
                objdatabaseadapter.close();
        }

        //Set Now Date
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
       //Set Curent date
        getexpenselistdate = LoginActivity.getformatdate;
        expenseslistdate.setText(LoginActivity.getcurrentdatetime);

        expenseslistdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String vardate = "";
                        String getmonth="";
                        String getdate="";
                        monthOfYear = monthOfYear + 1;
                        if (dayOfMonth < 10) {
                            vardate = "0" + dayOfMonth;
                            getdate = "0" + dayOfMonth;
                        } else {
                            vardate = String.valueOf(dayOfMonth);
                            getdate = String.valueOf(dayOfMonth);
                        }
                        if (monthOfYear < 10) {
                            vardate = vardate + "-" + "0" + monthOfYear;
                            getmonth = "0" + monthOfYear;;
                        } else {
                            vardate = vardate +"-" + monthOfYear;
                            getmonth = String.valueOf(monthOfYear);;
                        }
                        vardate = vardate + "-" + year;
                        getexpenselistdate = year+ "-"+getmonth+"-"+getdate;
                        expenseslistdate.setText(vardate );
                        GetExpensesList();

                    }
                };
                DatePickerDialog dpDialog = new DatePickerDialog(context, listener, year, month, day);
                dpDialog.show();
            }
        });

        //Swipe menu editior functionality
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "open" item
                SwipeMenuItem openItem = new SwipeMenuItem(
                        getApplicationContext());
                //  openItem.setBackground(ContextCompat.getDrawable(context,R.drawable.noborder));
                openItem.setWidth(130);
                openItem.setIcon(R.drawable.ic_delete_big);
                menu.addMenuItem(openItem);
            }
        };
        listView.setMenuCreator(creator);
        //Click swipemenu action ...delete expense
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        final ArrayList<ExpensesDetails> currentListDatareview = getdata;
                        String listschedulecode1 = currentListDatareview.get(position).getSchedulecode();
                        String listsalescount1 = "";
                        //Get Current date
                        DataBaseAdapter objdatabaseadapter1 = null;
                        try{
                            objdatabaseadapter1 = new DataBaseAdapter(context);
                            objdatabaseadapter1.open();
                            listsalescount1 = objdatabaseadapter1.GetSalesClose(listschedulecode1);
                        }catch (Exception e){
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        }finally {
                            // this gets called even if there is an exception somewhere above
                            if (objdatabaseadapter1 != null)
                                objdatabaseadapter1.close();
                        }
                        String getpaymentflag = "";
                        if(listsalescount1.equals("") || listsalescount1.equals("0") ||
                                listsalescount1.equals("null") ||listsalescount1.equals(null)){
                            getpaymentflag="false";
                        }else{
                            getpaymentflag="true";
                        }
                        if(getpaymentflag.equals("true")){
                            Toast toast = Toast.makeText(getApplicationContext(),"Schedule Closed", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            break ;
                        }
                        if(!MenuActivity. getcashclosecount.equals("0") && !MenuActivity. getcashclosecount.equals("null") &&
                                !MenuActivity. getcashclosecount.equals("") && !MenuActivity. getcashclosecount.equals(null) ){
                            Toast toast = Toast.makeText(getApplicationContext(),"Cash Closed ", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            //Toast.makeText(getApplicationContext(), "Cash Closed ", Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setMessage("Are you sure you want to delete?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        String gettransactionno = currentListDatareview.get(position).getTransactionno();
                                        DataBaseAdapter objdatabaseadapter = null;
                                        try {
                                            //Order item details
                                            objdatabaseadapter = new DataBaseAdapter(context);
                                            objdatabaseadapter.open();
                                            String getresult="";
                                            getresult=objdatabaseadapter.UpdateExpenseFlag(gettransactionno);
                                            if(getresult.equals("success")){
                                                Toast toast = Toast.makeText(getApplicationContext(),"Deleted Successfully", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                //Toast.makeText(getApplicationContext(),"Deleted Successfully",Toast.LENGTH_SHORT).show();
                                                dialog.dismiss();
                                                GetExpensesList();
                                            }
                                            networkstate = isNetworkAvailable();
                                            if (networkstate == true) {
                                                new AsyncCancelExpenseDetails().execute();
                                            }


                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if(objdatabaseadapter!=null)
                                                objdatabaseadapter.close();
                                        }
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                     break;

                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });
        //Open Add Sales Screen
        addexpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!MenuActivity. getcashclosecount.equals("0") && !MenuActivity. getcashclosecount.equals("null") &&
                        !MenuActivity. getcashclosecount.equals("") && !MenuActivity. getcashclosecount.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Cash Closed ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Cash Closed ", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!LoginActivity.getfinanceyrcode.equals("") &&
                        !LoginActivity.getfinanceyrcode.equals("0") &&
                        !LoginActivity.getfinanceyrcode.equals("null")
                        && !(LoginActivity.getfinanceyrcode.equals(null))) {

                    DataBaseAdapter objdatabaseadapter = null;
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();


                    Cursor getschedulelist = objdatabaseadapter.GetScheduleDB();
                    if(getschedulelist.getCount() >0){
                        for(int i=0;i<getschedulelist.getCount();i++) {
                            MenuActivity.getschedulecode = getschedulelist.getString(0);
                        }
                    }else{
                        MenuActivity.getschedulecode = "";
                    }
                    objdatabaseadapter.close();
                    if (!(MenuActivity.getschedulecode.equals(""))
                            && !(MenuActivity.getschedulecode.equals(null))) {
                        try {
                            openExpensesPopup();
                        } catch (Exception e) {
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        }
                    } else {
                        Toast toast = Toast.makeText(getApplicationContext(),"No Schedule for today ", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                       // Toast.makeText(getApplicationContext(), "No Schedule for today ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }else {
                    Toast toast = Toast.makeText(getApplicationContext(),"Please check the financial year ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Please check the financial year ", Toast.LENGTH_SHORT).show();
                    return;
                }

            }
        });
        //Logout process
        expenselogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HomeActivity.logoutprocess = "True";
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
        //Goback process
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack(null);
            }
        });

        //Get expenses details
        GetExpensesList();
    }

    //Open Expenses popup
    public void openExpensesPopup(){
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.addexpenses);
        ImageView closepopup = (ImageView) dialog.findViewById(R.id.closepopup);
        TextView expensedate = (TextView)dialog.findViewById(R.id.expensedate);
        txtexpenseshead = (TextView) dialog.findViewById(R.id.txtexpenseshead);
        txtamount = (TextView) dialog.findViewById(R.id.txtamount);
        txtremarks = (TextView) dialog.findViewById(R.id.txtremarks);
        btnSaveExpenses=(Button)dialog.findViewById(R.id.btnSaveExpenses);
        expensedate.setText(LoginActivity.getcurrentdatetime);
        closepopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        txtexpenseshead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetExpenseHead();
            }
        });
        btnSaveExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtexpenseshead.getText().toString().equals("")
                        || txtexpenseshead.getText().toString().equals(null)){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select expense head", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select expense head",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(getexpenseheadcode.equals("")
                        || getexpenseheadcode.equals(null)){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please select expense head ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please select expense head",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(txtamount.getText().toString().equals("")
                        || txtamount.getText().toString().equals(null) || txtamount.getText().toString().equals(".")){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter amount ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(),"Please enter amount",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(Double.parseDouble(txtamount.getText().toString()) <= 0){
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter valid amount ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                   // Toast.makeText(getApplicationContext(),"Please enter valid amount",Toast.LENGTH_SHORT).show();
                    return;
                }
                DataBaseAdapter objdatabaseadapter = null;
                try {
                    //Order item details
                    objdatabaseadapter = new DataBaseAdapter(context);
                    objdatabaseadapter.open();
                    String getresult="";
                    getresult=objdatabaseadapter.InsertExpensesDetails(getexpenseheadcode,txtamount.getText().toString(),
                            txtremarks.getText().toString());
                    if(getresult.equals("success")){
                        Toast toast = Toast.makeText(getApplicationContext(),"Saved Successfully ", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                      //  Toast.makeText(getApplicationContext(),"Saved Successfully",Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        GetExpensesList();
                    }
                    networkstate = isNetworkAvailable();
                    if (networkstate == true) {
                        new AsyncCancelExpenseDetails().execute();
                        new AsyncExpenseDetails().execute();
                    }

                } catch (Exception e) {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                } finally {
                    if(objdatabaseadapter!=null)
                        objdatabaseadapter.close();
                }
            }
        });
        dialog.show();
    }

    //Checking internet connection
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }
    public  void GetExpensesList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            expenseslist.clear();
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetExpenseListDB(getexpenselistdate);
            String gettripadvance = objdatabaseadapter.GetScheduleTripAdavanceDB(getexpenselistdate);
            if(gettripadvance.equals("")){
                gettripadvance = "0";
            }
            expensestripadvance.setText(String.valueOf(dft.format(Double.parseDouble(gettripadvance))));
            if(Cur.getCount()>0) {
                for(int i=0;i<Cur.getCount();i++){
                    expenseslist.add(new ExpensesDetails(Cur.getString(0),Cur.getString(1),
                            Cur.getString(2),Cur.getString(3),Cur.getString(4),
                            Cur.getString(5),Cur.getString(6),String.valueOf(i+1),Cur.getString(7)));
                    Cur.moveToNext();
                }
                getdata = expenseslist;
                adapter = new ExpensesListBaseAdapter(context, expenseslist);
                listView.setAdapter(adapter);
            }else{
                adapter = new ExpensesListBaseAdapter(context, expenseslist);
                listView.setAdapter(adapter);
                expensestotalamt.setText("\u20B9 0.00");
                expensesremainingamt.setText("\u20B9 0.00");
                Toast toast = Toast.makeText(getApplicationContext(),"No Expenses Available ", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Expenses Available",Toast.LENGTH_SHORT).show();

            }
        }  catch (Exception e){
            Log.i("SalesList", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }
    //Get expense head list
    public  void GetExpenseHead(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetExpenseHeadDB();
            if(Cur.getCount()>0) {
                expenseheadcode = new String[Cur.getCount()];
                expenseheadname = new String[Cur.getCount()];
                expenseheadnametamil = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    expenseheadcode[i] = Cur.getString(0);
                    expenseheadname[i] = Cur.getString(1);
                    expenseheadnametamil[i] = Cur.getString(2);
                    Cur.moveToNext();
                }

                expensedialog = new Dialog(context);
                expensedialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                expensedialog.setContentView(R.layout.expenseheadpopup);
                lv_expenseheadlist = (ListView) expensedialog.findViewById(R.id.lv_expenseheadlist);
                ImageView close = (ImageView) expensedialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        expensedialog.dismiss();
                    }
                });
                ExpenseHeadAdapter adapter = new ExpenseHeadAdapter(context);
                lv_expenseheadlist.setAdapter(adapter);
                expensedialog.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(),"No Expense head Available ", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Toast.makeText(getApplicationContext(),"No Expense head available",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }
    public void goBack(View v) {
        LoginActivity.ismenuopen=true;
        Intent i = new Intent(context, MenuActivity.class);
        startActivity(i);
    }
    @Override
    public void onBackPressed() {
        goBack(null);
    }
    //Set date
    private void showmainDate(int year, int monthOfYear, int dayOfMonth) {
        String vardate = "";
        String getmonth="";
        String getdate="";

        if (dayOfMonth < 10) {
            vardate = "0" + dayOfMonth;
            getdate = "0" + dayOfMonth;
        } else {
            vardate = String.valueOf(dayOfMonth);
            getdate = String.valueOf(dayOfMonth);
        }
        if (monthOfYear < 10) {
            vardate = vardate + "-" + "0" + monthOfYear;
            getmonth = "0" + monthOfYear;;
        } else {
            vardate = vardate +"-" + monthOfYear;
            getmonth = String.valueOf(monthOfYear);;
        }
        vardate = vardate + "-" + year;
        getexpenselistdate = year +"-"+getmonth+"-"+getdate ;
        expenseslistdate.setText(vardate);

    }

    /*********************START BASE ADAPTER ********************/
    //Expense head Adapter
    public class ExpenseHeadAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        ExpenseHeadAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return expenseheadcode.length;
        }

        @Override
        public Object getItem(int position) {
            return expenseheadcode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.expenseheadpopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listexpenseheadname = (TextView) convertView.findViewById(R.id.listexpenseheadname);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                if(!String.valueOf(expenseheadnametamil[position]).equals("") && !String.valueOf(expenseheadnametamil[position]).equals(null)
                        && !String.valueOf(expenseheadnametamil[position]).equals("null")){
                    mHolder.listexpenseheadname.setText(String.valueOf(expenseheadnametamil[position]));
                }else{
                    mHolder.listexpenseheadname.setText(String.valueOf(expenseheadname[position]));
                }
            } catch (Exception e) {
                Log.i("Route", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!String.valueOf(expenseheadnametamil[position]).equals("") && !String.valueOf(expenseheadnametamil[position]).equals(null)
                            && !String.valueOf(expenseheadnametamil[position]).equals("null")){
                        txtexpenseshead.setText(expenseheadnametamil[position]);
                    }else{
                        txtexpenseshead.setText(expenseheadname[position]);
                    }
                    getexpenseheadcode = expenseheadcode[position];
                    expensedialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listexpenseheadname;

        }

    }
    /************* START BASE ADAPTER  ****************/

    /**********Asynchronous Claass***************/

    protected  class AsyncExpenseDetails extends
            AsyncTask<String, JSONObject, ArrayList<ExpenseDetails>> {
        ArrayList<ExpenseDetails> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<ExpenseDetails> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            String result = "";
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetExpensesDetailsDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("transactionno", mCur2.getString(1));
                        obj.put("transactiondate", mCur2.getString(2));
                        obj.put("expensesheadcode", mCur2.getString(3));
                        obj.put("amount", mCur2.getDouble(4));
                        obj.put("remarks", mCur2.getString(5));
                        obj.put("makerid", mCur2.getString(6));
                        obj.put("createdate", mCur2.getString(7));
                        obj.put("schedulecode", mCur2.getString(8));
                        obj.put("financialyearcode", mCur2.getString(9));
                        obj.put("vancode", mCur2.getString(10));
                        obj.put("flag", mCur2.getString(11));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.ExpenseDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseExpenseDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<ExpenseDetails> result) {
            // TODO Auto-generated method stub
            try {
                if (result.size() >= 1) {
                    if (result.get(0).TransactionNo.length > 0) {
                        for (int j = 0; j < result.get(0).TransactionNo.length; j++) {
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateExpenseDetailsFlag(result.get(0).TransactionNo[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
            }catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncScheduleDetails", e.getMessage());
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }

        }
    }


    protected  class AsyncCancelExpenseDetails extends
            AsyncTask<String, JSONObject, ArrayList<ExpenseDetails>> {
        ArrayList<ExpenseDetails> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<ExpenseDetails> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetCancelExpensesDetailsDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("transactionno", mCur2.getString(1));
                        obj.put("transactiondate", mCur2.getString(2));
                        obj.put("expensesheadcode", mCur2.getString(3));
                        obj.put("amount", mCur2.getString(4));
                        obj.put("remarks", mCur2.getString(5));
                        obj.put("makerid", mCur2.getString(6));
                        obj.put("createdate", mCur2.getString(7));
                        obj.put("schedulecode", mCur2.getString(8));
                        obj.put("financialyearcode", mCur2.getString(9));
                        obj.put("vancode", mCur2.getString(10));
                        obj.put("flag", mCur2.getString(11));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.DeleteExpenseDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseExpenseDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<ExpenseDetails> result) {
            // TODO Auto-generated method stub
            try{
            if (result.size() >= 1) {
                if(result.get(0).TransactionNo.length>0){
                    for(int j=0;j<result.get(0).TransactionNo.length;j++){
                        DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                        dataBaseAdapter.open();
                        dataBaseAdapter.DeleteExpenseDetailsFlag(result.get(0).TransactionNo[j]);
                        dataBaseAdapter.close();
                    }
                }

            }
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }

        }
    }
    /**********END Asynchronous Claass***************/
}
