package thanjavurvansales.sss;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.goodiebag.pinview.Pinview;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;

public class SalesListActivity extends AppCompatActivity {
    public static SwipeMenuListView saleslistView;
    public Context context;
    private int year, month, day;
    Button btnSubmitpin;
    private Calendar calendar;
    String getschedulecode="0";
    Pinview pinview;
    TextView salesdate;
    public static TextView totalamtval,cashtotalamt,credittotalamt,txtcompanyname;
    ImageView addsales,saleslistgoback,saleslogout,closesales;
    public static String getsaleslistdate ;
    Dialog pindialog;
    ArrayList<SalesListDetails> saleslist = new ArrayList<SalesListDetails>();
    public static ArrayList<SalesListDetails> getdata;
    Dialog dialogstatus,companydialog;
    boolean networkstate;
    String[] companycode,companyname,shortname;
    ListView lv_CompanyList;
    public static String getsalesreviewtransactionno="",getsalesreviewfinanicialyear="",
            getsalesreviewcompanycode="",getfiltercompanycode="0",getstaticflag="0",getcancelflag="";
    Spinner selectpaymenttype,selectpaymentstatus;
    String[] arrapaymenttype,arrpaymentstatus;
    String getpaymenttype="All Bills";
    String getpaymentstatus="Paid &amp; Not Paid";
    public  boolean issales=false;
    SalesListBaseAdapterList adapter=null;
    boolean deviceFound;
    boolean issalesclose=false;
    private PrintData printData;
    Dialog printpopup;
    ImageView menusyncsales;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_list);

        //declare all variables
        context=this;
        saleslistView = (SwipeMenuListView) findViewById(R.id.saleslistView);
        salesdate = (TextView)findViewById(R.id.salesdate);
        addsales = (ImageView)findViewById(R.id.addsales);
        totalamtval = (TextView)findViewById(R.id.totalamtval);
        credittotalamt = (TextView)findViewById(R.id.credittotalamt);
        cashtotalamt = (TextView)findViewById(R.id.cashtotalamt);
        saleslogout = (ImageView)findViewById(R.id.saleslogout);
        saleslistgoback = (ImageView)findViewById(R.id.saleslistgoback);
        closesales = (ImageView)findViewById(R.id.closesales);
        txtcompanyname = (TextView)findViewById(R.id.txtcompanyname);
        selectpaymenttype = (Spinner)findViewById(R.id.selectpaymenttype);
        selectpaymentstatus = (Spinner)findViewById(R.id.selectpaymentstatus);
        arrapaymenttype = getResources().getStringArray(R.array.paymenttype);
        arrpaymentstatus = getResources().getStringArray(R.array.paymentstatus);
        menusyncsales = (ImageView)findViewById(R.id.menusyncsales);
        getfiltercompanycode="0";

        //Get Current date
        DataBaseAdapter objdatabaseadapter = null;
        Cursor getschedulelist=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            LoginActivity.getformatdate = objdatabaseadapter.GenCreatedDate();
            LoginActivity.getcurrentdatetime = objdatabaseadapter.GenCurrentCreatedDate();
             getschedulelist = objdatabaseadapter.GetScheduleDB();
            if(getschedulelist.getCount() >0){
                for(int i=0;i<getschedulelist.getCount();i++) {
                    MenuActivity.getschedulecode = getschedulelist.getString(0);
                }
            }else{
                MenuActivity.getschedulecode = "";
            }
            //Get Cash close Count
            MenuActivity.getcashclosecount = objdatabaseadapter.GetCashClose(MenuActivity.getschedulecode);
            //Get sales close Count
            MenuActivity.getsalesclosecount = objdatabaseadapter.GetSalesClose(MenuActivity.getschedulecode);
            MenuActivity.getdenominationcount = objdatabaseadapter.GetDenominationCount(MenuActivity.getschedulecode);
        }catch (Exception e){
            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
            mDbErrHelper.open();
            String geterrror = e.toString();
            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            mDbErrHelper.close();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(getschedulelist != null)
                getschedulelist.close();
        }

        if(!MenuActivity. getsalesclosecount.equals("0") && !MenuActivity. getsalesclosecount.equals("null") &&
                !MenuActivity. getsalesclosecount.equals("") && !MenuActivity. getsalesclosecount.equals(null)){
            closesales.setVisibility(View.GONE);
        }else{
            closesales.setVisibility(View.VISIBLE);
        }
        //Sync sales details
        menusyncsales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                networkstate = isNetworkAvailable();
                if(networkstate == true){
                    new AsyncCustomerDetails().execute();
                    new AsyncSalesDetails().execute();
                    new AsyncNilStockDetails().execute();
                    new AsyncSalesCancelDetails().execute();
                    new AsyncSalesStockConversionDetails().execute();
                }else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Please check internet connection", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }
            }
        });

        //open sales screen
        addsales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!MenuActivity. getcashclosecount.equals("0") && !MenuActivity. getcashclosecount.equals("null") &&
                        !MenuActivity. getcashclosecount.equals("") && !MenuActivity. getcashclosecount.equals(null) ){
                    Toast toast = Toast.makeText(getApplicationContext(),"Cash Closed ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Cash Closed ", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!MenuActivity. getsalesclosecount.equals("0") && !MenuActivity. getsalesclosecount.equals("null") &&
                        !MenuActivity. getsalesclosecount.equals("") && !MenuActivity. getsalesclosecount.equals(null)){
                    Toast toast = Toast.makeText(getApplicationContext(),"Sales Closed ", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    //Toast.makeText(getApplicationContext(), "Sales Closed ", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(!LoginActivity.getfinanceyrcode.equals("") &&
                        !LoginActivity.getfinanceyrcode.equals("0") &&
                        !LoginActivity.getfinanceyrcode.equals("null")
                        && !(LoginActivity.getfinanceyrcode.equals(null))) {


                        DataBaseAdapter objdatabaseadapter = null;
                        String getvouchersettingscount = "0";
                        String billtypecode="0";
                        String billcopystatus="";
                        String cashpaidstatus="";
                        String getsalestransactionno="0";
                        String getfinanicialyear="0";
                        String getbookingno = "";
                        String getbillno = "";
                        Cursor getschedulelist1=null;
                        String getgstinno = "";
                        try {
                            //Vocher settings
                            objdatabaseadapter = new DataBaseAdapter(context);
                            objdatabaseadapter.open();
                             getschedulelist1 = objdatabaseadapter.GetScheduleDB();
                            if(getschedulelist1.getCount() >0){
                                for(int i=0;i<getschedulelist1.getCount();i++) {
                                    MenuActivity.getschedulecode = getschedulelist1.getString(0);
                                }
                            }else{
                                MenuActivity.getschedulecode = "";
                            }
                            if (!(MenuActivity.getschedulecode.equals(""))
                                    && !(MenuActivity.getschedulecode.equals(null))) {
                                getvouchersettingscount = objdatabaseadapter.GetSalesVoucherSettingsDB();
                                String getcount = objdatabaseadapter.GetSalesItemStockCount();
                                objdatabaseadapter.DeleteSalesItemCart();
                                if(Double.parseDouble(getcount) > 0 ){
                                if (getvouchersettingscount.equals("0")) {
                                    String getbillcopystatus = objdatabaseadapter.GetBillCopyDB();
                                    if (getbillcopystatus.equals("yes")){
                                        Cursor Cur = objdatabaseadapter.CheckPaymentVoucher();
                                        if(Cur.getCount()>0) {
                                            billtypecode = Cur.getString(0);
                                            billcopystatus = Cur.getString(1);
                                            cashpaidstatus = Cur.getString(2);
                                            getsalestransactionno = Cur.getString(3);
                                            getfinanicialyear = Cur.getString(4);
                                            getbookingno = Cur.getString(5);
                                            getbillno = Cur.getString(6);
                                            getgstinno = Cur.getString(7);

                                            if (cashpaidstatus.equals("")){

                                                //Open Payment Voucher
                                            dialogstatus = new Dialog(context);
                                            dialogstatus.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            dialogstatus.setContentView(R.layout.salesreceipt);
                                            dialogstatus.setCanceledOnTouchOutside(false);
                                            final TextView paymentbookingno = (TextView)dialogstatus.findViewById(R.id.paymentbookingno);
                                            final TextView paymentbillno = (TextView)dialogstatus.findViewById(R.id.paymentbillno);
                                            final CheckBox checkbillcopy = (CheckBox) dialogstatus.findViewById(R.id.checkbillcopy);
                                            final RadioButton radio_paid = (RadioButton) dialogstatus.findViewById(R.id.radio_paid);
                                            RadioButton radio_notpaid = (RadioButton) dialogstatus.findViewById(R.id.radio_notpaid);
                                            Button btnsalessubmit = (Button) dialogstatus.findViewById(R.id.btnsalessubmit);
                                            ImageView closepopup = (ImageView) dialogstatus.findViewById(R.id.closepopup);

                                            paymentbookingno.setText("BK.NO. "+getbookingno);
                                            paymentbillno.setText("Bill No. "+getbillno);
                                            closepopup.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    dialogstatus.dismiss();
                                                }
                                            });
                                            if (billtypecode.equals("2")) {
                                                radio_paid.setChecked(false);
                                                radio_notpaid.setChecked(true);
                                                radio_paid.setEnabled(false);
                                                radio_notpaid.setEnabled(false);
                                                checkbillcopy.setChecked(true);
                                            } else {
                                                radio_paid.setChecked(true);
                                                radio_notpaid.setChecked(false);
                                                radio_paid.setEnabled(true);
                                                radio_notpaid.setEnabled(true);
                                                if(!getgstinno.equals("")) {
                                                    checkbillcopy.setChecked(true);
                                                }else{
                                                    checkbillcopy.setChecked(false);
                                                }
                                            }
                                            closepopup.setVisibility(View.GONE);
                                            final DataBaseAdapter finalObjdatabaseadapter = new DataBaseAdapter(context);
                                            final String finalGetsalestransactionno = getsalestransactionno;
                                            final String finalGetfinanicialyear = getfinanicialyear;
                                            btnsalessubmit.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    String getbillcopy = "";
                                                    String getpaymentstatus = "";
                                                    if (checkbillcopy.isChecked()) {
                                                        getbillcopy = "yes";
                                                    } else {
                                                        getbillcopy = "no";
                                                    }
                                                    if (radio_paid.isChecked()) {
                                                        getpaymentstatus = "yes";
                                                    } else {
                                                        getpaymentstatus = "no";
                                                    }
                                                    try {
                                                        finalObjdatabaseadapter.open();
                                                        String getresult = finalObjdatabaseadapter.UpdateSalesListReceipt(finalGetsalestransactionno,
                                                                finalGetfinanicialyear, getbillcopy, getpaymentstatus);

                                                        if (getresult.equals("success")) {
                                                            dialogstatus.dismiss();
                                                            Toast toast = Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_LONG);
                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                            toast.show();


                                                            if (getpaymentstatus.equals("yes")) {
                                                                /*android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(context);
                                                                String message = "Are you sure you want to print?";
                                                                final String finalGettransano = finalGetsalestransactionno;
                                                                final String financialyearcode = finalGetfinanicialyear;
                                                                builder1.setMessage(message)
                                                                        .setIcon(context.getApplicationInfo().icon)
                                                                        .setCancelable(false)
                                                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                                            @Override
                                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                                dialog1.dismiss();
                                                                                try {
                                                                                    printData = new PrintData(context);
                                                                                    deviceFound = printData.findBT();
                                                                                    if (!deviceFound) {
                                                                                        Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                        toast.show();
                                                                                        //Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                                    } else {
                                                                                        boolean billPrinted = false;
                                                                                        billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano, financialyearcode);
                                                                                        Intent i = new Intent(context, SalesActivity.class);
                                                                                        startActivity(i);
                                                                                        if (!billPrinted) {
                                                                                            Toast toast = Toast.makeText(getApplicationContext(),"Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                            toast.show();
                                                                                            //Toast.makeText(context, "Unable to connect to Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                } catch (Exception e) {
                                                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                    toast.show();
                                                                                   // Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                                    DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                                                    mDbErrHelper2.open();
                                                                                    mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                                                    mDbErrHelper2.close();

                                                                                }
                                                                            }
                                                                        })
                                                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                                            @Override
                                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                                dialog1.cancel();
                                                                                Intent i = new Intent(context, SalesActivity.class);
                                                                                startActivity(i);
                                                                            }
                                                                        }).show();*/

                                                                printpopup = new Dialog(context);
                                                                printpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                                printpopup.setContentView(R.layout.printpopup);

                                                                TextView txtYesAction = (TextView) printpopup.findViewById(R.id.txtYesAction);
                                                                TextView txtNoAction = (TextView) printpopup.findViewById(R.id.txtNoAction);
                                                                txtYesAction.setOnClickListener(new View.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(View v) {
                                                                        final String finalGettransano = finalGetsalestransactionno;
                                                                        final String financialyearcode = finalGetfinanicialyear;
                                                                        try {

                                                                            printData = new PrintData(context);
                                                                            deviceFound = printData.findBT();

                                                                            if (!deviceFound) {
                                                                                Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                printpopup.dismiss();
                                                                                toast.show();
                                                                            } else {

                                                                                boolean billPrinted = false;
                                                                                billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano, financialyearcode);
                                                                                Intent i = new Intent(context, SalesActivity.class);
                                                                                startActivity(i);
                                                                                if (!billPrinted) {
                                                                                    Toast toast = Toast.makeText(getApplicationContext(), "Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                                    printpopup.dismiss();
                                                                                    toast.show();
                                                                                }
                                                                                printpopup.dismiss();
                                                                            }
                                                                        }
                                                                        catch (Exception e){
                                                                            Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                                            toast.show();
                                                                            printpopup.dismiss();
                                                                            DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                                            mDbErrHelper2.open();
                                                                            mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                                            mDbErrHelper2.close();

                                                                        }
                                                                    }
                                                                });

                                                                txtNoAction.setOnClickListener(new View.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(View v) {
                                                                        printpopup.dismiss();
                                                                        Intent i = new Intent(context, SalesActivity.class);
                                                                        startActivity(i);
                                                                    }
                                                                });
                                                                printpopup.setCanceledOnTouchOutside(false);
                                                                printpopup.setCancelable(false);
                                                                printpopup.show();
                                                            }else{
                                                                Intent i = new Intent(context, SalesActivity.class);
                                                                startActivity(i);
                                                            }
                                                            networkstate = isNetworkAvailable();
                                                            if (networkstate == true) {
                                                                new AsyncUpdateSalesReceiptDetails().execute();
                                                            }
                                                        }
                                                    } catch (Exception e) {
                                                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                                        mDbErrHelper.open();
                                                        String geterrror = e.toString();
                                                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                        mDbErrHelper.close();
                                                    } finally {
                                                        if (finalObjdatabaseadapter != null)
                                                            finalObjdatabaseadapter.close();
                                                    }

                                                }
                                            });
                                            dialogstatus.show();
                                        }else{
                                                Intent i = new Intent(context, SalesActivity.class);
                                                startActivity(i);
                                            }
                                        }else {
                                            Intent i = new Intent(context, SalesActivity.class);
                                            startActivity(i);
                                        }
                                    }else {
                                        Intent i = new Intent(context, SalesActivity.class);
                                        startActivity(i);
                                    }
                                } else {
                                    Toast toast = Toast.makeText(getApplicationContext(),"Sales voucher settings not available for this van", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    //Toast.makeText(getApplicationContext(), "Sales voucher settings not available for this van", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                              }else{
                                    Toast toast = Toast.makeText(getApplicationContext(),"Stock not available for this van", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                    //Toast.makeText(getApplicationContext(), "Stock not available for this van", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                            } else {
                                Toast toast = Toast.makeText(getApplicationContext(),"No Schedule for today", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                //Toast.makeText(getApplicationContext(), "No Schedule for today ", Toast.LENGTH_SHORT).show();
                                return;
                            }

                        } catch (Exception e) {
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        } finally {
                            objdatabaseadapter.close();
                            if(getschedulelist1!=null)
                                getschedulelist1.close();
                        }

                }else {
                    Toast toast = Toast.makeText(getApplicationContext(),"Sales voucher settings not available for this van", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                   // Toast.makeText(getApplicationContext(), "Sales voucher settings not available for this van ", Toast.LENGTH_SHORT).show();
                    return;
                }


            }
        });

        //Set Now Date
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        getsaleslistdate =LoginActivity.getformatdate;
        salesdate.setText(LoginActivity.getcurrentdatetime);

        closesales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataBaseAdapter objdatabaseadapter = null;
                objdatabaseadapter = new DataBaseAdapter(context);
                objdatabaseadapter.open();

                String billtypecode="0";
                String billcopystatus="";
                String cashpaidstatus="";
                String getsalestransactionno="0";
                String getfinanicialyear="0";
                String getbookingno = "";
                String getbillno = "";
                Cursor getschedulelist1=null;

                 issalesclose=false;
                String getbillcopystatus = objdatabaseadapter.GetBillCopyDB();
                if (getbillcopystatus.equals("yes")){

                    Cursor Cur = objdatabaseadapter.CheckPaymentVoucher();
                    if(Cur.getCount()>0) {
                        billtypecode = Cur.getString(0);
                        billcopystatus = Cur.getString(1);
                        cashpaidstatus = Cur.getString(2);
                        getsalestransactionno = Cur.getString(3);
                        getfinanicialyear = Cur.getString(4);
                        getbookingno = Cur.getString(5);
                        getbillno = Cur.getString(6);

                        if (cashpaidstatus.equals("")){

                            //Open Payment Voucher
                            dialogstatus = new Dialog(context);
                            dialogstatus.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialogstatus.setContentView(R.layout.salesreceipt);
                            dialogstatus.setCanceledOnTouchOutside(false);
                            final TextView paymentbookingno = (TextView)dialogstatus.findViewById(R.id.paymentbookingno);
                            final TextView paymentbillno = (TextView)dialogstatus.findViewById(R.id.paymentbillno);
                            final CheckBox checkbillcopy = (CheckBox) dialogstatus.findViewById(R.id.checkbillcopy);
                            final RadioButton radio_paid = (RadioButton) dialogstatus.findViewById(R.id.radio_paid);
                            RadioButton radio_notpaid = (RadioButton) dialogstatus.findViewById(R.id.radio_notpaid);
                            Button btnsalessubmit = (Button) dialogstatus.findViewById(R.id.btnsalessubmit);
                            ImageView closepopup = (ImageView) dialogstatus.findViewById(R.id.closepopup);

                            paymentbookingno.setText("BK.NO. "+getbookingno);
                            paymentbillno.setText("Bill No. "+getbillno);
                            closepopup.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    issalesclose=false;
                                    dialogstatus.dismiss();
                                }
                            });
                            if (billtypecode.equals("2")) {
                                radio_paid.setChecked(false);
                                radio_notpaid.setChecked(true);
                                radio_paid.setEnabled(false);
                                radio_notpaid.setEnabled(false);
                                checkbillcopy.setChecked(true);
                            } else {
                                radio_paid.setChecked(true);
                                radio_notpaid.setChecked(false);
                                radio_paid.setEnabled(true);
                                radio_notpaid.setEnabled(true);
                                checkbillcopy.setChecked(false);
                            }
                             DataBaseAdapter finalObjdatabaseadapter1=null;
                            Cursor getsalesreceipt =null;
                            try {
                                finalObjdatabaseadapter1 = new DataBaseAdapter(context);
                                finalObjdatabaseadapter1.open();
                                 getsalesreceipt = finalObjdatabaseadapter1.GetSalesReceiptDB(getsalestransactionno, getfinanicialyear);
                                if (getsalesreceipt.getCount() > 0) {
                                    if (getsalesreceipt.getString(0).equals("yes")) {
                                        checkbillcopy.setChecked(true);
                                    } else {
                                        checkbillcopy.setChecked(false);
                                    }
                                    if (getsalesreceipt.getString(1).equals("yes")) {
                                        radio_paid.setChecked(true);
                                        radio_notpaid.setChecked(false);
                                    } else {
                                        radio_paid.setChecked(true);
                                        radio_notpaid.setChecked(false);
                                    }
                                }
                            }catch (Exception e) {
                                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                mDbErrHelper.open();
                                String geterrror = e.toString();
                                mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                mDbErrHelper.close();
                            } finally {
                                if (finalObjdatabaseadapter1 != null)
                                    finalObjdatabaseadapter1.close();
                                if(getsalesreceipt!=null)
                                    getsalesreceipt.close();
                            }
                            closepopup.setVisibility(View.GONE);
                            final DataBaseAdapter finalObjdatabaseadapter = new DataBaseAdapter(context);
                            final String finalGetsalestransactionno = getsalestransactionno;
                            final String finalGetfinanicialyear = getfinanicialyear;
                            btnsalessubmit.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String getbillcopy = "";
                                    String getpaymentstatus = "";
                                    if (checkbillcopy.isChecked()) {
                                        getbillcopy = "yes";
                                    } else {
                                        getbillcopy = "no";
                                    }
                                    if (radio_paid.isChecked()) {
                                        getpaymentstatus = "yes";
                                    } else {
                                        getpaymentstatus = "no";
                                    }
                                    try {
                                        finalObjdatabaseadapter.open();
                                        String getresult = finalObjdatabaseadapter.UpdateSalesListReceipt(finalGetsalestransactionno,
                                                finalGetfinanicialyear, getbillcopy, getpaymentstatus);

                                        if (getresult.equals("success")) {
                                            issalesclose=true;
                                            dialogstatus.dismiss();
                                            Toast toast = Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_LONG);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.show();



                                            if (getpaymentstatus.equals("yes")) {
                                                /*android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(context);
                                                String message = "Are you sure you want to print?";
                                                final String finalGettransano = finalGetsalestransactionno;
                                                final String financialyearcode = finalGetfinanicialyear;
                                                builder1.setMessage(message)
                                                        .setIcon(context.getApplicationInfo().icon)
                                                        .setCancelable(false)
                                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                dialog1.dismiss();
                                                                try {
                                                                    printData = new PrintData(context);
                                                                    deviceFound = printData.findBT();
                                                                    if (!deviceFound) {
                                                                        issalesclose=true;
                                                                        SalesClose();
                                                                        Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                                        toast.show();
                                                                        //Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                    } else {
                                                                        boolean billPrinted = false;
                                                                        billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano, financialyearcode);
                                                                        issalesclose=true;
                                                                        SalesClose();
                                                                        if (!billPrinted) {
                                                                            Toast toast = Toast.makeText(getApplicationContext(),"Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                                            toast.show();

                                                                        }
                                                                    }
                                                                } catch (Exception e) {
                                                                    issalesclose=true;
                                                                    SalesClose();
                                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                    toast.show();
                                                                    // Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                    DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                                    mDbErrHelper2.open();
                                                                    mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                                    mDbErrHelper2.close();

                                                                }
                                                            }
                                                        })
                                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                issalesclose=true;
                                                                SalesClose();
                                                                dialog1.cancel();
                                                            }
                                                        }).show();*/

                                                printpopup = new Dialog(context);
                                                printpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                printpopup.setContentView(R.layout.printpopup);

                                                TextView txtYesAction = (TextView) printpopup.findViewById(R.id.txtYesAction);
                                                TextView txtNoAction = (TextView) printpopup.findViewById(R.id.txtNoAction);
                                                txtYesAction.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        final String finalGettransano = finalGetsalestransactionno;
                                                        final String financialyearcode = finalGetfinanicialyear;
                                                        try {

                                                            printData = new PrintData(context);
                                                            deviceFound = printData.findBT();

                                                            if (!deviceFound) {
                                                                issalesclose=true;
                                                                SalesClose();
                                                                Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                printpopup.dismiss();
                                                                toast.show();
                                                            } else {

                                                                boolean billPrinted = false;
                                                                billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano, financialyearcode);
                                                                issalesclose=true;
                                                                SalesClose();
                                                                if (!billPrinted) {
                                                                    Toast toast = Toast.makeText(getApplicationContext(), "Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                    printpopup.dismiss();
                                                                    toast.show();
                                                                }
                                                                printpopup.dismiss();
                                                            }
                                                        }
                                                        catch (Exception e){
                                                            Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                            toast.show();
                                                            issalesclose=true;
                                                            SalesClose();
                                                            printpopup.dismiss();
                                                            DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                            mDbErrHelper2.open();
                                                            mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                            mDbErrHelper2.close();

                                                        }
                                                    }
                                                });

                                                txtNoAction.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        issalesclose=true;
                                                        SalesClose();
                                                        printpopup.dismiss();
                                                    }
                                                });
                                                printpopup.setCanceledOnTouchOutside(false);
                                                printpopup.setCancelable(false);
                                                printpopup.show();
                                            }
                                            networkstate = isNetworkAvailable();
                                            if (networkstate == true) {
                                                new AsyncUpdateSalesReceiptDetails().execute();
                                            }
                                        }
                                    } catch (Exception e) {
                                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                        mDbErrHelper.open();
                                        String geterrror = e.toString();
                                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                        mDbErrHelper.close();
                                    } finally {
                                        if (finalObjdatabaseadapter != null)
                                            finalObjdatabaseadapter.close();
                                    }

                                }
                            });
                            dialogstatus.show();
                        }else{
                            issalesclose=true;
                            SalesClose();
                        }
                    } else{
                        issalesclose=true;
                        SalesClose();
                    }
                }else{
                    issalesclose=true;
                    SalesClose();
                }
                objdatabaseadapter.close();


            }
        });




        salesdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String vardate = "";
                        String getmonth="";
                        String getdate="";
                        monthOfYear = monthOfYear + 1;
                        if (dayOfMonth < 10) {
                            vardate = "0" + dayOfMonth;
                            getdate = "0" + dayOfMonth;
                        } else {
                            vardate = String.valueOf(dayOfMonth);
                            getdate = String.valueOf(dayOfMonth);
                        }
                        if (monthOfYear < 10) {
                            vardate = vardate + "-" + "0" + monthOfYear;
                            getmonth = "0" + monthOfYear;;
                        } else {
                            vardate = vardate +"-" + monthOfYear;
                            getmonth = String.valueOf(monthOfYear);;
                        }
                        vardate = vardate + "-" + year;
                        getsaleslistdate = year+ "-"+getmonth+"-"+getdate;
                        salesdate.setText(vardate );
                        GetSalesList();

                    }
                };
                DatePickerDialog dpDialog = new DatePickerDialog(context, listener, year, month, day);
                dpDialog.show();
            }
        });

        //Swipe menu editior functionality
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create Edit Bill copy item
                SwipeMenuItem cancelItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item width
                cancelItem.setWidth(130);
                // set a icon
                cancelItem.setIcon(R.drawable.ic_mode_edit);
                // add to menu
                menu.addMenuItem(cancelItem);

                // create "open" item
                SwipeMenuItem openItem = new SwipeMenuItem(
                        getApplicationContext());
              //  openItem.setBackground(ContextCompat.getDrawable(context,R.drawable.noborder));
                openItem.setWidth(130);
                openItem.setIcon(R.drawable.ic_view);
                menu.addMenuItem(openItem);


            }
        };

        saleslistView.setMenuCreator(creator);

        //Click swipemenu action ...Edit sales receipt and then print
        saleslistView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        ArrayList<SalesListDetails> currentListData = getdata;
                        final String getsalestransactionno = currentListData.get(position).getTransactionno();
                        final String getfinanicialyear = currentListData.get(position).getFinancialyearcode();
                        final String getflag = currentListData.get(position).getFlag();
                        final String getbilltype = currentListData.get(position).getPaymenttype();
                        final String listschedulecode1 = currentListData.get(position).getSchedulecode();
                        String listsalescount1 = "";
                        String listcashcount = "";
                        //Get Current date
                        DataBaseAdapter objdatabaseadapter1 = null;
                        try{
                            objdatabaseadapter1 = new DataBaseAdapter(context);
                            objdatabaseadapter1.open();
                            listsalescount1 = objdatabaseadapter1.GetSalesClose(listschedulecode1);
                            listcashcount = objdatabaseadapter1.GetCountCashClose(listschedulecode1);
                        }catch (Exception e){
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        }finally {
                            // this gets called even if there is an exception somewhere above
                            if (objdatabaseadapter1 != null)
                                objdatabaseadapter1.close();
                        }
                        String getpaymentflag = "";
                        if(listsalescount1.equals("") || listsalescount1.equals("0") ||
                                listsalescount1.equals("null") ||listsalescount1.equals(null)){
                            getpaymentflag="false";
                        }else{
                            getpaymentflag="true";
                        }

                        String getcloseflag = "";
                        if(listcashcount.equals("") || listcashcount.equals("0") ||
                                listcashcount.equals("null") ||listcashcount.equals(null)){
                            getcloseflag="false";
                        }else{
                            getcloseflag="true";
                        }
                        if(getpaymentflag.equals("true") && getcloseflag.equals("true")){
                            Toast toast = Toast.makeText(getApplicationContext(),"Schedule Closed", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            break ;
                        }


                        if(!MenuActivity. getcashclosecount.equals("0") && !MenuActivity. getcashclosecount.equals("null") &&
                            !MenuActivity. getcashclosecount.equals("") && !MenuActivity. getcashclosecount.equals(null)  ){
                        Toast toast = Toast.makeText(getApplicationContext(),"Cash Closed ", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        //Toast.makeText(getApplicationContext(), "Cash Closed ", Toast.LENGTH_SHORT).show();
                            break;
                         }

                        final DataBaseAdapter finalObjdatabaseadapter = new DataBaseAdapter(context);
                        finalObjdatabaseadapter.open();
                        Cursor Cur = finalObjdatabaseadapter.SalesListPaymentVoucher(getsalestransactionno,getfinanicialyear);
                        String getbookingno = "";
                        String getbillno = "";
                        if(Cur.getCount()>0) {
                            getbookingno = Cur.getString(5);
                            getbillno = Cur.getString(6);
                        }if(Cur != null){
                            Cur.close();
                        }

                       // if (getbilltype.equals("1")){
                            if (!getflag.equals("3") && !getflag.equals("6")) {
                                dialogstatus = new Dialog(context);
                                dialogstatus.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialogstatus.setContentView(R.layout.salesreceipt);
                                dialogstatus.setCanceledOnTouchOutside(false);
                                final CheckBox checkbillcopy = (CheckBox) dialogstatus.findViewById(R.id.checkbillcopy);
                                final RadioButton radio_paid = (RadioButton) dialogstatus.findViewById(R.id.radio_paid);
                                RadioButton radio_notpaid = (RadioButton) dialogstatus.findViewById(R.id.radio_notpaid);
                                Button btnsalessubmit = (Button) dialogstatus.findViewById(R.id.btnsalessubmit);
                                ImageView closepopup = (ImageView) dialogstatus.findViewById(R.id.closepopup);

                                final TextView paymentbookingno = (TextView)dialogstatus.findViewById(R.id.paymentbookingno);
                                final TextView paymentbillno = (TextView)dialogstatus.findViewById(R.id.paymentbillno);

                                paymentbookingno.setText("BK.NO. "+getbookingno);
                                paymentbillno.setText("Bill No. "+getbillno);
                                closepopup.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialogstatus.dismiss();
                                    }
                                });

                                if (getbilltype.equals("2")) {
                                    radio_paid.setChecked(false);
                                    radio_notpaid.setChecked(true);
                                    radio_paid.setEnabled(false);
                                    radio_notpaid.setEnabled(false);
                                    checkbillcopy.setChecked(true);
                                    checkbillcopy.setEnabled(false);
                                } else {
                                    radio_paid.setChecked(true);
                                    radio_notpaid.setChecked(false);
                                    radio_paid.setEnabled(true);
                                    radio_notpaid.setEnabled(true);
                                    checkbillcopy.setChecked(false);
                                    checkbillcopy.setEnabled(true);
                                }


                                Cursor getsalesreceipt = finalObjdatabaseadapter.GetSalesReceiptDB(getsalestransactionno, getfinanicialyear);
                                if (getsalesreceipt.getCount() > 0) {
                                    if (getsalesreceipt.getString(0).equals("yes")) {
                                        checkbillcopy.setChecked(true);
                                    } else {
                                        checkbillcopy.setChecked(false);
                                    }
                                    if (getsalesreceipt.getString(1).equals("yes")) {
                                        radio_paid.setChecked(true);
                                        radio_notpaid.setChecked(false);
                                    } else {
                                        radio_paid.setChecked(false);
                                        radio_notpaid.setChecked(true);
                                    }
                                }
                                btnsalessubmit.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        String getbillcopy = "";
                                        String getpaymentstatus = "";
                                        if (checkbillcopy.isChecked()) {
                                            getbillcopy = "yes";
                                        } else {
                                            getbillcopy = "no";
                                        }
                                        if (radio_paid.isChecked()) {
                                            getpaymentstatus = "yes";
                                        } else {
                                            getpaymentstatus = "no";
                                        }
                                        try {
                                            String getresult = finalObjdatabaseadapter.UpdateSalesListReceipt(getsalestransactionno, getfinanicialyear, getbillcopy, getpaymentstatus);

                                            if (getresult.equals("success")) {
                                                dialogstatus.dismiss();
                                                Toast toast = Toast.makeText(getApplicationContext(),"Updated Successfully", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                //Toast.makeText(getApplicationContext(), "Updated Successfully", Toast.LENGTH_SHORT).show();
                                            }
                                            if(getpaymentstatus.equals("yes")){
                                                /*android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(context);
                                                String message = "Are you sure you want to print?";
                                                final String finalGettransano = getsalestransactionno;
                                                final  String financialyearcode = getfinanicialyear;
                                                builder1.setMessage(message)
                                                        .setIcon(context.getApplicationInfo().icon)
                                                        .setCancelable(false)
                                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                dialog1.dismiss();
                                                                try {
                                                                    printData = new PrintData(context);
                                                                    deviceFound = printData.findBT();
                                                                    if (!deviceFound) {
                                                                        Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                        toast.setGravity(Gravity.CENTER, 0, 0);
                                                                        toast.show();
                                                                        //Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                    } else {
                                                                        boolean billPrinted = false;
                                                                        billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano,financialyearcode);
                                                                        if (!billPrinted) {
                                                                            Toast toast = Toast.makeText(getApplicationContext(),"Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                                            toast.show();
                                                                           // Toast.makeText(context, "Unable to connect to Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                            return;
                                                                        }
                                                                    }
                                                                }
                                                                catch (Exception e){
                                                                    Toast toast = Toast.makeText(getApplicationContext(),"Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                    toast.show();
                                                                   // Toast.makeText(context, "Please connect to the Bluetooth Printer!", Toast.LENGTH_SHORT).show();
                                                                    DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                                    mDbErrHelper2.open();
                                                                    mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                                    mDbErrHelper2.close();

                                                                }
                                                            }
                                                        })
                                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog1, int which) {
                                                                dialog1.cancel();;
                                                            }
                                                        }).show();*/

                                                printpopup = new Dialog(context);
                                                printpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                                printpopup.setContentView(R.layout.printpopup);

                                                TextView txtYesAction = (TextView) printpopup.findViewById(R.id.txtYesAction);
                                                TextView txtNoAction = (TextView) printpopup.findViewById(R.id.txtNoAction);
                                                txtYesAction.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        final String finalGettransano = getsalestransactionno;
                                                        final  String financialyearcode = getfinanicialyear;
                                                        try {

                                                            printData = new PrintData(context);
                                                            deviceFound = printData.findBT();

                                                            if (!deviceFound) {
                                                                Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                                printpopup.dismiss();
                                                                toast.show();
                                                            } else {

                                                                boolean billPrinted = false;
                                                                billPrinted = (boolean) printData.GetSalesReceipt(finalGettransano,financialyearcode);
                                                                if (!billPrinted) {
                                                                    Toast toast = Toast.makeText(getApplicationContext(), "Unable to connect to Bluetooth Printer!", Toast.LENGTH_LONG);
                                                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                                                    printpopup.dismiss();
                                                                    toast.show();
                                                                }
                                                                printpopup.dismiss();
                                                            }
                                                        }
                                                        catch (Exception e){
                                                            Toast toast = Toast.makeText(getApplicationContext(), "Please connect to the Bluetooth Printer!", Toast.LENGTH_LONG);
                                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                                            toast.show();
                                                            printpopup.dismiss();
                                                            DataBaseAdapter mDbErrHelper2 = new DataBaseAdapter(context);
                                                            mDbErrHelper2.open();
                                                            mDbErrHelper2.insertErrorLog(e.toString(), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                                            mDbErrHelper2.close();

                                                        }
                                                    }
                                                });

                                                txtNoAction.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        printpopup.dismiss();
                                                    }
                                                });
                                                printpopup.setCanceledOnTouchOutside(false);
                                                printpopup.setCancelable(false);
                                                printpopup.show();
                                            }
                                            //GetSale List
                                            GetSalesList();
                                            networkstate = isNetworkAvailable();
                                            if (networkstate == true) {
                                                new AsyncUpdateSalesReceiptDetails().execute();
                                            }

                                        } catch (Exception e) {
                                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                            mDbErrHelper.open();
                                            String geterrror = e.toString();
                                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                            mDbErrHelper.close();
                                        } finally {
                                            if (finalObjdatabaseadapter != null)
                                                finalObjdatabaseadapter.close();
                                        }

                                    }
                                });
                                dialogstatus.show();
                            } else {
                                Toast toast = Toast.makeText(getApplicationContext(),"Cancelled bill can't be edited", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                //Toast.makeText(getApplicationContext(), "Cancelled bill can't be edited", Toast.LENGTH_SHORT).show();
                                break;
                            }
                        /*}else{
                            Toast toast = Toast.makeText(getApplicationContext(),"Credit bill can't be edited", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            //Toast.makeText(getApplicationContext(), "Credit bill can't be edited", Toast.LENGTH_SHORT).show();
                            break;
                        }*/
                        break;
                    case 1:
                        ArrayList<SalesListDetails> currentListDatareview = getdata;
                        getsalesreviewtransactionno = currentListDatareview.get(position).getTransactionno();
                        getsalesreviewfinanicialyear = currentListDatareview.get(position).getFinancialyearcode();
                        getsalesreviewcompanycode = currentListDatareview.get(position).getCompanycode();
                         getstaticflag = currentListDatareview.get(position).getFlag();
                        final String listschedulecode = currentListDatareview.get(position).getSchedulecode();
                        String listsalescount = "";
                        //Get Current date
                        DataBaseAdapter objdatabaseadapter = null;
                        try{
                            objdatabaseadapter = new DataBaseAdapter(context);
                            objdatabaseadapter.open();
                            listsalescount = objdatabaseadapter.GetSalesClose(listschedulecode);
                        }catch (Exception e){
                            DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                            mDbErrHelper.open();
                            String geterrror = e.toString();
                            mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                            mDbErrHelper.close();
                        }finally {
                            // this gets called even if there is an exception somewhere above
                            if (objdatabaseadapter != null)
                                objdatabaseadapter.close();
                        }
                        if(listsalescount.equals("") || listsalescount.equals("0") ||
                                listsalescount.equals("null") ||listsalescount.equals(null)){
                            getcancelflag="false";
                         }else{
                            getcancelflag="true";
                        }


                        //Call saels view page
                        Intent i = new Intent(context,SalesViewActivity.class);
                        startActivity(i);

                        break;
                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });

        //Logout process
        saleslogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // HomeActivity.logoutprocess = "True";
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmation");
                builder.setMessage("Are you sure you want to logout?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(context, LoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
        //Goback process
        saleslistgoback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack(null);
            }
        });

      /*  //GetSale List
        GetSalesList();*/

        //company name
        txtcompanyname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetCompanyName();
            }
        });

        selectpaymenttype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                int index = parentView.getSelectedItemPosition();
                getpaymenttype = arrapaymenttype[index];
                GetSalesList();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        selectpaymentstatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                int index = parentView.getSelectedItemPosition();
                getpaymentstatus = arrpaymentstatus[index];
                if(issales) {
                    GetSalesList();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });
    }

    /**********Asynchronous Claass***************/
    protected  class AsyncCustomerDetails extends
            AsyncTask<String, JSONObject, ArrayList<CustomerDatas>> {
        ArrayList<CustomerDatas> List = null;
        JSONObject jsonObj = null;
        ProgressDialog loading;
        @Override
        protected  ArrayList<CustomerDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetWholeCustomerDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("customercode", mCur2.getString(1));
                        obj.put("refno", mCur2.getString(2));
                        obj.put("customername", mCur2.getString(3));
                        obj.put("customernametamil", mCur2.getString(4));
                        obj.put("address", mCur2.getString(5));
                        obj.put("areacode", mCur2.getString(6));
                        obj.put("emailid", mCur2.getString(7));
                        obj.put("mobileno", mCur2.getString(8));
                        obj.put("telephoneno", mCur2.getString(9));
                        obj.put("aadharno", mCur2.getString(10));
                        obj.put("gstin", mCur2.getString(11));
                        obj.put("status", mCur2.getString(12));
                        obj.put("makerid", mCur2.getString(13));
                        obj.put("createddate", mCur2.getString(14));
                        obj.put("updateddate", mCur2.getString(15));
                        obj.put("latitude", mCur2.getString(16));
                        obj.put("longitude", mCur2.getString(17));
                        obj.put("flag", mCur2.getString(18));
                        obj.put("schemeapplicable", mCur2.getString(19));
                        obj.put("uploaddocument", mCur2.getString(20));
                        obj.put("business_type", mCur2.getString(23));

                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }
                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.CustomerDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseCustomerDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("Customer", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected void onPostExecute(ArrayList<CustomerDatas> result) {
            // TODO Auto-generated method stub
            try {
                if (result.size() >= 1) {
                    if (result.get(0).CustomerCode.length > 0) {
                        for (int j = 0; j < result.get(0).CustomerCode.length; j++) {
                            DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            dataBaseAdapter.UpdateCustomerFlag(result.get(0).CustomerCode[j]);
                            dataBaseAdapter.close();
                        }
                    }

                }
                loading.dismiss();
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }

        }
    }


    protected  class AsyncSalesDetails extends
            AsyncTask<String, JSONObject, ArrayList<SalesSyncDatas>> {
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        ProgressDialog loading;
        @Override
        protected  ArrayList<SalesSyncDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            String result = "";
            try {
                JSONObject js_obj = new JSONObject();
                JSONObject js_salesobj = new JSONObject();
                JSONObject js_salesitemobj = new JSONObject();
                JSONObject js_stockobj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();

                    Cursor mCursales = dbadapter.GetWholeSalesDatasDB();
                    Cursor mCursalesitems = dbadapter.GetWholeSalesItemDatasDB();
                    Cursor mCurStock = dbadapter.GetSalesStockTransactionDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    JSONArray js_array3 = new JSONArray();
                    JSONArray js_array4 = new JSONArray();
                    JSONArray js_stockarray = new JSONArray();

                    for (int i = 0; i < mCursales.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCursales.getString(0));
                        obj.put("companycode", mCursales.getString(1));
                        obj.put("vancode", mCursales.getString(2));
                        obj.put("transactionno", mCursales.getString(3));
                        obj.put("billno", mCursales.getString(4));
                        obj.put("refno", mCursales.getString(5));
                        obj.put("prefix", mCursales.getString(6));
                        obj.put("suffix", mCursales.getString(7));
                        obj.put("billdate", mCursales.getString(8));
                        obj.put("customercode", mCursales.getString(9));
                        obj.put("billtypecode", mCursales.getString(10));
                        obj.put("gstin", mCursales.getString(11));
                        obj.put("schedulecode", mCursales.getString(12));
                        obj.put("subtotal", mCursales.getDouble(13));
                        obj.put("discount", mCursales.getDouble(14));
                        obj.put("totaltaxamount", mCursales.getDouble(15));
                        obj.put("grandtotal", mCursales.getDouble(16));
                        obj.put("billcopystatus", mCursales.getString(17));
                        obj.put("cashpaidstatus", mCursales.getString(18));
                        obj.put("flag", mCursales.getString(19));
                        obj.put("makerid", mCursales.getString(20));
                        obj.put("createddate", mCursales.getString(21));
                        obj.put("updateddate", mCursales.getString(22));
                        obj.put("bitmapimage", mCursales.getString(23));
                        obj.put("financialyearcode", mCursales.getString(24));
                        obj.put("remarks", mCursales.getString(25));
                        obj.put("bookingno", mCursales.getString(26));
                        obj.put("salestime", mCursales.getString(29));
                        obj.put("beforeroundoff", mCursales.getString(30));
                        js_array2.put(obj);
                        mCursales.moveToNext();
                    }
                    for (int i = 0; i < mCursalesitems.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCursalesitems.getString(0));
                        obj.put("transactionno", mCursalesitems.getString(1));
                        obj.put("companycode", mCursalesitems.getString(2));
                        obj.put("itemcode", mCursalesitems.getString(3));
                        obj.put("qty", mCursalesitems.getString(4));
                        obj.put("weight", mCursalesitems.getString(5));
                        obj.put("price", mCursalesitems.getString(6));
                        obj.put("discount", mCursalesitems.getDouble(7));
                        obj.put("amount", mCursalesitems.getDouble(8));
                        obj.put("cgst", mCursalesitems.getDouble(9));
                        obj.put("sgst", mCursalesitems.getDouble(10));
                        obj.put("igst", mCursalesitems.getDouble(11));
                        obj.put("cgstamt", mCursalesitems.getDouble(12));
                        obj.put("sgstamt", mCursalesitems.getDouble(13));
                        obj.put("igstamt", mCursalesitems.getDouble(14));
                        obj.put("freeitemstatus", mCursalesitems.getString(15));
                        obj.put("makerid", mCursalesitems.getString(16));
                        obj.put("createddate", mCursalesitems.getString(17));
                        obj.put("updateddate", mCursalesitems.getString(18));
                        obj.put("bookingno", mCursalesitems.getString(19));
                        obj.put("financialyearcode", mCursalesitems.getString(20));
                        obj.put("vancode", mCursalesitems.getString(21));
                        obj.put("flag", mCursalesitems.getString(22));

                        js_array3.put(obj);
                        mCursalesitems.moveToNext();
                    }


                    js_obj.put("JSonObject", js_array4);
                    js_salesobj.put("JSonObject", js_array2);
                    js_salesitemobj.put("JSonObject", js_array3);
                    js_stockobj.put("JSonObject",js_stockarray);

                    jsonObj =  api.allSalesDetails(js_salesobj.toString(),js_salesitemobj.toString());
                    /*//Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseSalesDataList(jsonObj);*/
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected void onPostExecute(ArrayList<SalesSyncDatas> List) {
            // TODO Auto-generated method stub
          /*  DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
            try {
                objdatabaseadapter.open();
                if (List.size() >= 1) {
                    if (List.get(0).TransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                            objdatabaseadapter.UpdateSalesFlag(List.get(0).TransactionNo[j]);
                        }
                    }
                    if (List.get(0).SalesItemTransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).SalesItemTransactionNo.length; j++) {
                            objdatabaseadapter.UpdateSalesItemFlag(List.get(0).SalesItemTransactionNo[j]);
                        }
                    }
                    if (List.get(0).StockTransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                            String[] getArr = List.get(0).StockTransactionNo[j].split("~");
                            objdatabaseadapter.UpdateSalesStockTransactionFlag(getArr[0],getArr[1]);
                        }
                    }
                }

            }catch (Exception e) {
                // TODO Auto-generated catch block
                loading.dismiss();
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            } finally {
                if(objdatabaseadapter!=null)
                    objdatabaseadapter.close();
            }*/
            loading.dismiss();

        }
    }


    //cancel sales
    protected  class AsyncSalesStockConversionDetails extends
            AsyncTask<String, JSONObject, ArrayList<SalesSyncDatas>> {
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        ProgressDialog loading;
        @Override
        protected  ArrayList<SalesSyncDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_salesobj = new JSONObject();
                JSONObject js_salesitemobj = new JSONObject();
                JSONObject js_stockobj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCurStock = dbadapter.GetWholeStockConversionDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    JSONArray js_array3 = new JSONArray();
                    JSONArray js_stockarray = new JSONArray();
                    for (int i = 0; i < mCurStock.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("transactionno", mCurStock.getString(0));
                        obj.put("transactiondate", mCurStock.getString(1));
                        obj.put("vancode", mCurStock.getString(2));
                        obj.put("itemcode", mCurStock.getString(3));
                        obj.put("inward", mCurStock.getString(4));
                        obj.put("outward", mCurStock.getString(5));
                        obj.put("type", mCurStock.getString(6));
                        obj.put("refno", mCurStock.getString(7));
                        obj.put("createddate", mCurStock.getString(8));
                        obj.put("flag", mCurStock.getString(9));
                        obj.put("companycode", mCurStock.getString(10));
                        obj.put("financialyearcode", mCurStock.getString(12));
                        obj.put("autonum", mCurStock.getString(13));
                        js_stockarray.put(obj);
                        mCurStock.moveToNext();
                    }
                    js_salesobj.put("JSonObject", js_array2);
                    js_salesitemobj.put("JSonObject", js_array3);
                    js_stockobj.put("JSonObject",js_stockarray);

                    jsonObj =  api.allSalesStockConversionDetails(  js_stockobj.toString());
                    //Call Json parser functionality
                   /* JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseSalesCancelDataList(jsonObj);*/
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected void onPostExecute(ArrayList<SalesSyncDatas> List) {
            // TODO Auto-generated method stub
            loading.dismiss(); //Backupdb
            DataBaseAdapter mDbHelper1 = new DataBaseAdapter(context);
            mDbHelper1.open();
            String filepath = mDbHelper1.udfnBackupdb(context);
            mDbHelper1.close();
        }
    }


    //cancel sales
    protected  class AsyncSalesCancelDetails extends
            AsyncTask<String, JSONObject, ArrayList<SalesSyncDatas>> {
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        ProgressDialog loading;
        @Override
        protected  ArrayList<SalesSyncDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_salesobj = new JSONObject();
                JSONObject js_salesitemobj = new JSONObject();
                JSONObject js_stockobj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCursales = dbadapter.GetWholeSalesCancelDatasDB();
                    // Cursor mCursalesitems = dbadapter.GetWholeSalesCancelItemDatasDB();
                    Cursor mCurStock = dbadapter.GetWholeCancelStockTransactionDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    JSONArray js_array3 = new JSONArray();
                    JSONArray js_stockarray = new JSONArray();
                    for (int i = 0; i < mCursales.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCursales.getString(0));
                        obj.put("companycode", mCursales.getString(1));
                        obj.put("vancode", mCursales.getString(2));
                        obj.put("transactionno", mCursales.getString(3));
                        obj.put("billno", mCursales.getString(4));
                        obj.put("refno", mCursales.getString(5));
                        obj.put("prefix", mCursales.getString(6));
                        obj.put("suffix", mCursales.getString(7));
                        obj.put("billdate", mCursales.getString(8));
                        obj.put("customercode", mCursales.getString(9));
                        obj.put("billtypecode", mCursales.getString(10));
                        obj.put("gstin", mCursales.getString(11));
                        obj.put("schedulecode", mCursales.getString(12));
                        obj.put("subtotal", mCursales.getString(13));
                        obj.put("discount", mCursales.getString(14));
                        obj.put("totaltaxamount", mCursales.getString(15));
                        obj.put("grandtotal", mCursales.getString(16));
                        obj.put("billcopystatus", mCursales.getString(17));
                        obj.put("cashpaidstatus", mCursales.getString(18));
                        obj.put("flag", mCursales.getString(19));
                        obj.put("makerid", mCursales.getString(20));
                        obj.put("createddate", mCursales.getString(21));
                        obj.put("updateddate", mCursales.getString(22));
                        obj.put("bitmapimage", mCursales.getString(23));
                        obj.put("financialyearcode", mCursales.getString(24));
                        obj.put("remarks", mCursales.getString(25));
                        obj.put("bookingno", mCursales.getString(26));

                        js_array2.put(obj);
                        mCursales.moveToNext();
                    }



                    for (int i = 0; i < mCurStock.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("transactionno", mCurStock.getString(0));
                        obj.put("transactiondate", mCurStock.getString(1));
                        obj.put("vancode", mCurStock.getString(2));
                        obj.put("itemcode", mCurStock.getString(3));
                        obj.put("inward", mCurStock.getString(4));
                        obj.put("outward", mCurStock.getString(5));
                        obj.put("type", mCurStock.getString(6));
                        obj.put("refno", mCurStock.getString(7));
                        obj.put("createddate", mCurStock.getString(8));
                        obj.put("flag", mCurStock.getString(9));
                        obj.put("companycode", mCurStock.getString(10));
                        obj.put("financialyearcode", mCurStock.getString(12));
                        obj.put("autonum", mCurStock.getString(13));
                        js_stockarray.put(obj);
                        mCurStock.moveToNext();
                    }
                    js_salesobj.put("JSonObject", js_array2);
                    js_salesitemobj.put("JSonObject", js_array3);
                    js_stockobj.put("JSonObject",js_stockarray);

                    jsonObj =  api.allSalesCancelDetails(js_salesobj.toString(), js_stockobj.toString());
                    //Call Json parser functionality
                   /* JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseSalesCancelDataList(jsonObj);*/
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected void onPostExecute(ArrayList<SalesSyncDatas> List) {
            // TODO Auto-generated method stub
            loading.dismiss();
           /* DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
            try {
                objdatabaseadapter.open();
                if (List.size() >= 1) {
                    if (List.get(0).TransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                            objdatabaseadapter.UpdateCancelSalesFlag(List.get(0).TransactionNo[j]);
                        }
                    }

                    if (List.get(0).StockTransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).StockTransactionNo.length; j++) {
                            objdatabaseadapter.UpdateCancelSalesStockTransactionFlag(List.get(0).StockTransactionNo[j]);
                        }
                    }
                }
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            } finally {
                if(objdatabaseadapter!=null)
                    objdatabaseadapter.close();
            }*/

        }
    }


    protected  class AsyncNilStockDetails extends
            AsyncTask<String, JSONObject, ArrayList<ScheduleDatas>> {
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        ProgressDialog loading;
        @Override
        protected  ArrayList<ScheduleDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetWholeNilStockDetailsDB();

                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("vancode", mCur2.getString(1));
                        obj.put("schedulecode", mCur2.getString(2));
                        obj.put("salestransactionno", mCur2.getString(3));
                        obj.put("salesbookingno", mCur2.getString(4));
                        obj.put("salesfinacialyearcode", mCur2.getString(5));
                        obj.put("salescustomercode", mCur2.getString(6));
                        obj.put("salesitemcode", mCur2.getString(7));
                        obj.put("createddate", mCur2.getString(8));
                        obj.put("flag", mCur2.getString(9));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }

                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.NilStockDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseNilStockReport(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(context, "Loading", "Please wait...", true);
            loading.setCancelable(false);
            loading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected void onPostExecute(ArrayList<ScheduleDatas> result) {
            // TODO Auto-generated method stub
            DataBaseAdapter dataBaseAdapter = null;
            try {
                if (result.size() >= 1) {
                    if (result.get(0).ScheduleCode.length > 0) {
                        for (int j = 0; j < result.get(0).ScheduleCode.length; j++) {
                              dataBaseAdapter = new DataBaseAdapter(context);
                            dataBaseAdapter.open();
                            if (result.get(0).ScheduleCode[j] != "" && !result.get(0).ScheduleCode[j].equals("")) {
                                String getsplitval[] = result.get(0).ScheduleCode[j].split("~");
                                dataBaseAdapter.UpdateNilStockFlag(getsplitval[0], getsplitval[1]);
                            }
                            dataBaseAdapter.close();
                        }
                    }

                }
                loading.dismiss();
            }catch (Exception e) {
                // TODO Auto-generated catch block
                loading.dismiss();
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            } finally {
                if(dataBaseAdapter!=null)
                    dataBaseAdapter.close();
            }

        }
    }

    /**********END Asynchronous Claass***************/


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //preventing default implementation previous to android.os.Build.VERSION_CODES.ECLAIR
            if(printpopup!=null){
                if(printpopup.isShowing()){
//                Toast.makeText(getApplicationContext(), "back press",
//                        Toast.LENGTH_LONG).show();
                    return true;
                }
            }

        }
        return super.onKeyDown(keyCode, event);
    }
    public void SalesClose(){
        if(issalesclose) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Confirmation");
            // builder.setIcon(R.mipmap.ic_vanlauncher);

            builder.setMessage("Do you want to close sales?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            pindialog = new Dialog(context);
                            pindialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            pindialog.setContentView(R.layout.validatepinumber);
                            btnSubmitpin = (Button) pindialog.findViewById(R.id.btnSubmitpin);
                            pinview = (Pinview) pindialog.findViewById(R.id.pinview);
                            ImageView closepopup = (ImageView) pindialog.findViewById(R.id.closepopup);
                            closepopup.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    pindialog.dismiss();
                                }
                            });
                            btnSubmitpin.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    DataBaseAdapter finalObjdatabaseadapter1 = null;
                                    finalObjdatabaseadapter1 = new DataBaseAdapter(context);
                                    finalObjdatabaseadapter1.open();
                                    try {

                                        String getEncryptedPIN = null;
                                        try {
                                            getEncryptedPIN = sha256(pinview.getValue());
                                        } catch (NoSuchAlgorithmException e) {
                                            e.printStackTrace();
                                        }
                                        if (getEncryptedPIN.equals(LoginActivity.getpin)) {

                                            String getresult = "0";
                                            getschedulecode = finalObjdatabaseadapter1.GetScheduleCode();
                                            //SAles close details
                                            getresult = finalObjdatabaseadapter1.InsertSalesClose(getschedulecode);
                                            if (getresult.equals("success")) {
                                                pindialog.dismiss();
                                                Toast toast = Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                closeKeyboard();
                                                //Toast.makeText(getApplicationContext(), "Saved Successfully", Toast.LENGTH_SHORT).show();
                                                networkstate = isNetworkAvailable();
                                                if (networkstate == true) {
                                                    new AsyncCloseSalesDetails().execute();
                                                }
                                                Intent i = new Intent(context, OrderFormActivity.class);
                                                startActivity(i);
                                            } else {
                                                Toast toast = Toast.makeText(getApplicationContext(), "Error in saving", Toast.LENGTH_LONG);
                                                toast.setGravity(Gravity.CENTER, 0, 0);
                                                toast.show();
                                                //Toast.makeText(getApplicationContext(), "Error in saving", Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast toast = Toast.makeText(getApplicationContext(), "Please enter correct pin", Toast.LENGTH_LONG);
                                            toast.setGravity(Gravity.CENTER, 0, 0);
                                            toast.show();
                                            // Toast.makeText(getApplicationContext(),"Please enter correct pin",Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                    } catch (Exception e) {
                                        DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                                        mDbErrHelper.open();
                                        String geterrror = e.toString();
                                        mDbErrHelper.insertErrorLog(geterrror.replace("'", " "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                                        mDbErrHelper.close();
                                    } finally {
                                        if (finalObjdatabaseadapter1 != null)
                                            finalObjdatabaseadapter1.close();
                                    }
                                }
                            });
                            pindialog.show();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();

                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
    /*******FILTER FUNCTIONALITY********/
    public  void GetCompanyName(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetCompanyDB();
            if(Cur.getCount()>0) {
                companycode = new String[Cur.getCount()];
                companyname = new String[Cur.getCount()];
                shortname = new String[Cur.getCount()];
                for(int i=0;i<Cur.getCount();i++){
                    companycode[i] = Cur.getString(0);
                    companyname[i] = Cur.getString(1);
                    shortname[i] = Cur.getString(2);
                    Cur.moveToNext();
                }

                companydialog = new Dialog(context);
                companydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                companydialog.setContentView(R.layout.companypopup);
                lv_CompanyList = (ListView) companydialog.findViewById(R.id.lv_CompanyList);
                ImageView close = (ImageView) companydialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        companydialog.dismiss();
                    }
                });
                CompanyAdapter adapter = new CompanyAdapter(context);
                lv_CompanyList.setAdapter(adapter);
                companydialog.show();
            }else{
                Toast.makeText(getApplicationContext(),"No Area in this route",Toast.LENGTH_SHORT).show();
            }
        }  catch (Exception e){
            Log.i("GetArea", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }
    //Checking internet connection
    public boolean isNetworkAvailable() {
        /*ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();*/
        int code;
        Boolean result=false;
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            URL siteURL = new URL(RestAPI.urlString);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();
            code = connection.getResponseCode();
            if (code == 200) {
                result=true;
            }
            connection.disconnect();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("AsyncSync", e.getMessage());
            result=false;

        }
        return result;
    }
    //Sales List
    public  void GetSalesList(){
        DataBaseAdapter objdatabaseadapter = null;
        Cursor Cur=null;
        try{
            saleslist.clear();
            objdatabaseadapter = new DataBaseAdapter(context);
            objdatabaseadapter.open();
            Cur = objdatabaseadapter.GetSalesListDB(getsaleslistdate,getfiltercompanycode,
                    getpaymenttype,getpaymentstatus);
            if(Cur.getCount()>0) {
                issales=true;
                for(int i=0;i<Cur.getCount();i++){
                    saleslist.add(new SalesListDetails(Cur.getString(3),Cur.getString(7),
                            Cur.getString(8),Cur.getString(20),
                            Cur.getString(21),Cur.getString(9),Cur.getString(14),
                            String.valueOf(Cur.getCount()-i),Cur.getString(11),Cur.getString(23),Cur.getString(19),
                            Cur.getString(22),Cur.getString(10),
                            Cur.getString(18),Cur.getString(24),Cur.getString(15)
                            ,Cur.getString(16),Cur.getString(2),Cur.getString(17),
                            Cur.getString(0)));
                    Cur.moveToNext();
                }
                getdata = saleslist;
                adapter = new SalesListBaseAdapterList(context,saleslist);
                saleslistView.setAdapter(adapter);
            }else{
                adapter = new SalesListBaseAdapterList(context,saleslist);
                saleslistView.setAdapter(adapter);
                SalesListActivity.totalamtval.setText("\u20B9 0.00");
                SalesListActivity.cashtotalamt.setText("\u20B9 0.00" );
                SalesListActivity.credittotalamt.setText("\u20B9 0.00" );
                Toast.makeText(getApplicationContext(),"No Sales Available",Toast.LENGTH_SHORT).show();

            }
        }  catch (Exception e){
            Log.i("SalesList", e.toString());
        }
        finally {
            // this gets called even if there is an exception somewhere above
            if(objdatabaseadapter != null)
                objdatabaseadapter.close();
            if(Cur != null)
                Cur.close();
        }
    }



    /**********Asynchronous Claass***************/

    protected  class AsyncCloseSalesDetails extends
            AsyncTask<String, JSONObject, ArrayList<ScheduleDatas>> {
        ArrayList<ScheduleDatas> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<ScheduleDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_obj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCur2 = dbadapter.GetCloseSalesitemDatasDB();

                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCur2.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCur2.getString(0));
                        obj.put("closedate", mCur2.getString(1));
                        obj.put("vancode", mCur2.getString(2));
                        obj.put("schedulecode", mCur2.getString(3));
                        obj.put("makerid", mCur2.getString(4));
                        obj.put("createddate", mCur2.getString(5));
                        js_array2.put(obj);
                        mCur2.moveToNext();
                    }

                    js_obj.put("JSonObject", js_array2);

                    jsonObj =  api.SalesCloseDetails(js_obj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseCashReport(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncScheduleDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<ScheduleDatas> result) {
            // TODO Auto-generated method stub
            if (result.size() >= 1) {
                if(result.get(0).ScheduleCode.length>0){
                    for(int j=0;j<result.get(0).ScheduleCode.length;j++){
                        DataBaseAdapter dataBaseAdapter = new DataBaseAdapter(context);
                        dataBaseAdapter.open();
                        dataBaseAdapter.UpdateSalesCloseFlag(result.get(0).ScheduleCode[j]);
                        dataBaseAdapter.close();
                    }
                }

            }

        }
    }

    protected  class AsyncUpdateSalesReceiptDetails extends
            AsyncTask<String, JSONObject, ArrayList<SalesSyncDatas>> {
        ArrayList<SalesSyncDatas> List = null;
        JSONObject jsonObj = null;
        @Override
        protected  ArrayList<SalesSyncDatas> doInBackground(String... params) {
            RestAPI api = new RestAPI();
            try {
                JSONObject js_salesobj = new JSONObject();
                try {
                    DataBaseAdapter dbadapter = new DataBaseAdapter(context);
                    dbadapter.open();
                    Cursor mCursales = dbadapter.GetSalesReceiptDatasDB();
                    JSONArray js_array2 = new JSONArray();
                    for (int i = 0; i < mCursales.getCount(); i++) {
                        JSONObject obj = new JSONObject();
                        obj.put("autonum", mCursales.getString(0));
                        obj.put("companycode", mCursales.getString(1));
                        obj.put("vancode", mCursales.getString(2));
                        obj.put("transactionno", mCursales.getString(3));
                        obj.put("billno", mCursales.getString(4));
                        obj.put("refno", mCursales.getString(5));
                        obj.put("prefix", mCursales.getString(6));
                        obj.put("suffix", mCursales.getString(7));
                        obj.put("billdate", mCursales.getString(8));
                        obj.put("customercode", mCursales.getString(9));
                        obj.put("billtypecode", mCursales.getString(10));
                        obj.put("gstin", mCursales.getString(11));
                        obj.put("schedulecode", mCursales.getString(12));
                        obj.put("subtotal", mCursales.getString(13));
                        obj.put("discount", mCursales.getString(14));
                        obj.put("totaltaxamount", mCursales.getString(15));
                        obj.put("grandtotal", mCursales.getString(16));
                        obj.put("billcopystatus", mCursales.getString(17));
                        obj.put("cashpaidstatus", mCursales.getString(18));
                        obj.put("flag", mCursales.getString(19));
                        obj.put("makerid", mCursales.getString(20));
                        obj.put("createddate", mCursales.getString(21));
                        obj.put("updateddate", mCursales.getString(22));
                        obj.put("bitmapimage", mCursales.getString(23));
                        obj.put("financialyearcode", mCursales.getString(24));
                        obj.put("remarks", mCursales.getString(25));
                        obj.put("bookingno", mCursales.getString(26));

                        js_array2.put(obj);
                        mCursales.moveToNext();
                    }

                    js_salesobj.put("JSonObject", js_array2);

                    jsonObj =  api.SalesReceiptDetails(js_salesobj.toString());
                    //Call Json parser functionality
                    JSONParser parser = new JSONParser();
                    //parse the json object to boolean
                    List = parser.parseSalesReceiptDataList(jsonObj);
                    dbadapter.close();
                }
                catch (Exception e)
                {
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            return List;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<SalesSyncDatas> List) {
            // TODO Auto-generated method stub
            DataBaseAdapter objdatabaseadapter = new DataBaseAdapter(context);
            try {
                objdatabaseadapter.open();
                if (List.size() >= 1) {
                    if (List.get(0).TransactionNo.length > 0) {
                        for (int j = 0; j < List.get(0).TransactionNo.length; j++) {
                            //objdatabaseadapter.UpdateSalesRecieptFlag(List.get(0).TransactionNo[j]);
                        }
                    }
                }
            }catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncSalesDetails", e.getMessage());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            } finally {
                if(objdatabaseadapter!=null)
                    objdatabaseadapter.close();
            }

        }
    }

    /**********END Asynchronous Claass***************/

    /************BASE ADAPTER*************/
    //Company Adapter
    public class CompanyAdapter extends BaseAdapter {

        private Context context;
        private LayoutInflater layoutInflater;

        CompanyAdapter(Context c) {
            context = c;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return companycode.length;
        }

        @Override
        public Object getItem(int position) {
            return companycode[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return getCount();
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @SuppressLint("InflateParams")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder mHolder;

            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.companypopuplist, parent, false);
                mHolder = new ViewHolder();
                try {
                    mHolder.listcompanyname = (TextView) convertView.findViewById(R.id.listcompanyname);
                } catch (Exception e) {
                    Log.i("Route", e.toString());
                    DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                    mDbErrHelper.open();
                    String geterrror = e.toString();
                    mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    mDbErrHelper.close();
                }
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }
            try {
                mHolder.listcompanyname.setText(String.valueOf(shortname[position]));
            } catch (Exception e) {
                Log.i("Route value", e.toString());
                DataBaseAdapter mDbErrHelper = new DataBaseAdapter(context);
                mDbErrHelper.open();
                String geterrror = e.toString();
                mDbErrHelper.insertErrorLog(geterrror.replace("'"," "), this.getClass().getSimpleName(), String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                mDbErrHelper.close();
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    txtcompanyname.setText(String.valueOf(shortname[position]));
                    getfiltercompanycode = companycode[position];
                    GetSalesList();
                    companydialog.dismiss();
                }
            });
            return convertView;
        }

        private class ViewHolder {
            private TextView listcompanyname;

        }

    }
    /************END BASE ADAPTER*************/
    //Set date
    private void showmainDate(int year, int monthOfYear, int dayOfMonth) {
        String vardate = "";
        String getmonth="";
        String getdate="";

        if (dayOfMonth < 10) {
            vardate = "0" + dayOfMonth;
            getdate = "0" + dayOfMonth;
        } else {
            vardate = String.valueOf(dayOfMonth);
            getdate = String.valueOf(dayOfMonth);
        }
        if (monthOfYear < 10) {
            vardate = vardate + "-" + "0" + monthOfYear;
            getmonth = "0" + monthOfYear;;
        } else {
            vardate = vardate +"-" + monthOfYear;
            getmonth = String.valueOf(monthOfYear);;
        }
        vardate = vardate + "-" + year;
        getsaleslistdate = year +"-"+getmonth+"-"+getdate ;
        salesdate.setText(vardate);

    }
    //Sha Encrypt
    static String sha256(String input) throws NoSuchAlgorithmException {
        MessageDigest mDigest = MessageDigest.getInstance("SHA256");
        byte[] result = mDigest.digest(input.getBytes());
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < result.length; i++) {
            sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
        }
        return sb.toString();
    }
    //Close Keyboard
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    public void goBack(View v) {
        LoginActivity.ismenuopen=true;
        Intent i = new Intent(context, MenuActivity.class);
        startActivity(i);
    }
    @Override
    public void onBackPressed() {
        goBack(null);
    }

}
